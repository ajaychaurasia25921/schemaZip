
    create table FES_LANGUAGE_HISTORY (
	
		history_id varchar(36) not null,
        language_id varchar(36) not null,
        active_flag varchar(1) not null,
        active_from date not null,
        active_till date not null,
        created_by varchar(120) not null,
        created_on datetime not null,
        last_updated_by varchar(120),
        last_updated_on datetime,
        version_number decimal(18,0),
        icon_image_file varchar(240),
        installed_flag varchar(1) not null,
        language_code varchar(3) not null,
        language_iso_code varchar(3) not null,
        language_name varchar(80) not null,
        language_native_name varchar(100) not null,
        system_flag varchar(1),
        primary key (history_id)
    );
	