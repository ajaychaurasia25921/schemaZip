create table fes_bank_contact_hist(
history_id varchar(36) not null,
contact_id varchar(36) not null,
bank_id varchar(36) not null,
contact_type_id varchar(36) not null,
default_flag varchar(1) not null,
contact_person varchar(100) not null,
contact_phone varchar(20) ,
contact_mobile varchar(15),
contact_email varchar(80) not null,
active_flag varchar(1) not null,
active_from date not null,
active_till date not null,
system_flag varchar(1) not null,
version_number decimal not null,
created_by varchar(36) not null,
created_on datetime not null,
last_updated_by varchar(36) not null,
last_updated_on datetime not null,
primary key(history_id)
);	
alter table fes_bank_contact_hist 
        add constraint FES_BANK_CONTACT_HIST_UK1  unique (bank_id);