create table FES_APP_PROPERTY_VALUE(
property_value_id varchar(36),
property_id varchar(36),
value_string varchar(240),
value_flag varchar(1),
value_date date,
value_number int(10),
value_decimal decimal(18,4),
active_flag varchar(1) not null,
active_from date not null,
active_till date not null,
system_flag varchar(1) not null,
version_number decimal(18,0) not null,
created_by varchar(36) not null,
created_on datetime not null,
last_updated_by varchar(36) not null,
last_updated_on datetime not null,
primary key(property_value_id)
);	


	