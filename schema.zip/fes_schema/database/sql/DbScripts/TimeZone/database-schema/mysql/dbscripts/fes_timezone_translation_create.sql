
    create table FES_TIMEZONE_TL (
        translation_id varchar(36) not null,
		parent_id varchar(36) not null,
		language_id varchar(36) not null,
		entity_name varchar(80) not null,
		entity_desc varchar(240),
		version_number decimal(18,0) not null,
		created_by varchar(36) not null,
        created_on datetime not null,
		last_updated_by varchar(36) not null,
        last_updated_on datetime not null,
		primary key (translation_id)
    );
	alter table FES_TIMEZONE_TL 
        add constraint FES_TIMEZONE_TL_UK1 unique (parent_id,language_id);

    
 

   