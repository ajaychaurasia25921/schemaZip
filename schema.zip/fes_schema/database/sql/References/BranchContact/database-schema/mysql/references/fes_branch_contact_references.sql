 
 // must be checked
 alter table FES_BRANCH_CONTACT
        add constraint FES_BRANCH_CONTACT_FK1
        foreign key (branch_id) 
        references FES_BRANCH(branch_id);
alter table FES_BRANCH_CONTACT_HIST
        add constraint FES_BRANCH_CONTACT_HIST_FK1
        foreign key (contact_id) 
        references FES_BRANCH_CONTACT (contact_id);
alter table FES_BRANCH_CONTACT_HIST
        add constraint FES_BRANCH_CONTACT_HIST_FK2
        foreign key (branch_id) 
        references FES_BRANCH (branch_id);
				
		