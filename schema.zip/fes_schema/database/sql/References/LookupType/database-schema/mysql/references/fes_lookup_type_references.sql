 alter table FES_LOOKUP_TYPE
        add constraint FES_LOOKUP_TYPE_FK1 
        foreign key (bank_id) 
        references FES_BANK (bank_id);
		
		
alter table FES_LOOKUP_TYPE_TL 
        add constraint FES_LOOKUP_TYPE_TL_FK1
        foreign key (parent_id) 
        references FES_LOOKUP_TYPE (lookup_type_id);
alter table FES_LOOKUP_TYPE_TL 
        add constraint FES_LOOKUP_TYPE_TL_FK2
        foreign key (language_id) 
        references FES_LANGUAGE (language_id);
		
		
		
alter table FES_LOOKUP_TYPE_HIST 
        add constraint FES_LOOKUP_TYPE_HIST_FK1 
        foreign key (lookup_type_id) 
        references FES_LOOKUP_TYPE (lookup_type_id);
alter table FES_LOOKUP_TYPE_HIST 
        add constraint FES_LOOKUP_TYPE_HIST_FK2
        foreign key (bank_id) 
        references FES_BANK (bank_id);
		
alter table FES_LOOKUP_VALUE
        add constraint FES_LOOKUP_VALUE_FK1  
        foreign key (lookup_type_id) 
        references FES_LOOKUP_VALUE (lookup_type_id);
		
		
alter table FES_LOOKUP_VALUE_TL
        add constraint FES_LOOKUP_VALUE_FK1  
        foreign key (parent_id) 
        references FES_LOOKUP_VALUE (lookup_value_id);
alter table FES_LOOKUP_VALUE_TL
        add constraint FES_LOOKUP_VALUE_FK2  
        foreign key (language_id) 
        references FES_LANGUAGE (language_id);
		
		
alter table FES_LOOKUP_VALUE_HIST 
        add constraint FES_LOOKUP_VALUE_HIST_FK1 
        foreign key (lookup_value_id) 
        references FES_LOOKUP_VALUE (lookup_value_id);
alter table FES_LOOKUP_VALUE_HIST 
        add constraint FES_LOOKUP_VALUE_HIST_FK2
        foreign key (lookup_type_id) 
        references FES_LOOKUP_VALUE (lookup_type_id);
		
		
alter table FES_LOOKUP_CATEGORY
        add constraint FES_LOOKUP_CATEGORY_FK1 
        foreign key (bank_id) 
        references FES_BANK (bank_id);
		
		
alter table FES_LOOKUP_CATEGORY_TL 
        add constraint FES_LOOKUP_CATEGORY_TL_FK2 
        foreign key (parent_id) 
        references FES_LOOKUP_CATEGORY (lookup_type_id);
alter table FES_LOOKUP_CATEGORY_TL 
        add constraint FES_LOOKUP_CATEGORY_TL_FK2
        foreign key (language_id) 
        references FES_LANGUAGE (language_id);
		
		
alter table FES_LOOKUP_CATEGORY_HIST 
        add constraint FES_LOOKUP_CATEGORY_HIST_FK1  
        foreign key (lookup_type_id) 
        references FES_LOOKUP_TYPE (lookup_category_id);
alter table FES_LOOKUP_CATEGORY_HIST 
        add constraint FES_LOOKUP_CATEGORY_HIST_FK2
        foreign key (bank_id) 
        references FES_BANK (bank_id);