 alter table FES_TIMEZONE_TL
        add constraint FES_TIMEZONE_TL_FK1  
        foreign key (parent_id) 
        references FES_TIMEZONE (timezone_id);
alter table FES_TIMEZONE_TL
        add constraint FES_TIMEZONE_TL_FK2 
        foreign key (language_id) 
        references FES_LANGUAGE (language_id);
		
		
alter table FES_TIMEZONE_HIST
        add constraint FES_TIMEZONE_HIST_FK1  
        foreign key (timezone_id) 
        references FES_TIMEZONE(timezone_id);