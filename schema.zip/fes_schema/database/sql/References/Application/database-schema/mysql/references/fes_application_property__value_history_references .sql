 alter table FES_APP_PROPERTY_VALUE_HIST
        add constraint FES_APP_PROPERTY_VALUE_HIST_FK1  
        foreign key (property_value_id) 
        references FES_APP_PROPERTY_VALUE (property_value_id);
alter table FES_APP_PROPERTY_VALUE_HIST
        add constraint FES_APP_PROPERTY_VALUE_HIST_FK2  
        foreign key (property_id) 
        references FES_APP_PROPERTY (property_id);		