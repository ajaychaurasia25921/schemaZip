 alter table FES_APPLICATION_HIST
        add constraint FES_APPLICATION_HIST_FK1
        foreign key (application_id) 
        references FES_APPLICATION (application_id);