create index FES_BANK_CONTACT_IX1  on FES_BANK_CONTACT (active_flag);
