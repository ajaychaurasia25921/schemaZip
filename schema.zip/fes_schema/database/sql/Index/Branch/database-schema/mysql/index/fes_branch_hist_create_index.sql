 create index FES_BRANCH_HIST_IX1   on FES_BRANCH_HIST (active_flag);
 