 create index FES_BRANCH_PROPERTY_IX1 on FES_BRANCH_PROPERTY (active_flag);
