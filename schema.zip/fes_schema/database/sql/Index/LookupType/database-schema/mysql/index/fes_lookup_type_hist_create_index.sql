 create index FES_LOOKUP_TYPE_HIST_IX1   on FES_LOOKUP_TYPE_HIST (active_flag);
 