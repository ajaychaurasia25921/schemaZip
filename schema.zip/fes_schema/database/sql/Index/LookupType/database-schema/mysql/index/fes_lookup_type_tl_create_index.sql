 create index FES_LOOKUP_TYPE_TL_IX1  on FES_LOOKUP_TYPE_TL (parent_id);
  create index FES_LOOKUP_TYPE_TL_IX2  on FES_LOOKUP_TYPE_TL (language_id);