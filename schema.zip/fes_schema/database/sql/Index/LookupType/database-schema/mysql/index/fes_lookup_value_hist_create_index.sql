 create index FES_LOOKUP_VALUE_HIST_IX1 on FES_LOOKUP_VALUE_HIST (active_flag);
 