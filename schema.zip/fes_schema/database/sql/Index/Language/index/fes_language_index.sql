create index FES_LANGUAGE_IX1 on FES_LANGUAGE (active_flag);
create index FES_LANGUAGE_IX2 on FES_LANGUAGE (installed_flag);
