create index FES_APP_PROPERTY_VALUE_IX1  on FES_APP_PROPERTY_VALUE (active_flag);
