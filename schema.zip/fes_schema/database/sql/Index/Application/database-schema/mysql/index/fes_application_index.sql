create index FES_APPLICATION_IX1 on FES_APPLICATION (active_flag);
