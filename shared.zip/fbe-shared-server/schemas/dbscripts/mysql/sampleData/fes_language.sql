CREATE DATABASE  IF NOT EXISTS `testdb1` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `testdb1`;
-- MySQL dump 10.13  Distrib 5.7.25, for Win64 (x86_64)
--
-- Host: BLRCSWFBEIP0002    Database: testdb1
-- ------------------------------------------------------
-- Server version	5.7.25-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fes_language`
--

DROP TABLE IF EXISTS `fes_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fes_language` (
  `language_id` varchar(36) NOT NULL,
  `created_by` varchar(36) NOT NULL,
  `created_on` datetime NOT NULL,
  `last_updated_by` varchar(36) NOT NULL,
  `last_updated_on` datetime DEFAULT NULL,
  `active_flag` varchar(1) NOT NULL,
  `active_from` datetime DEFAULT NULL,
  `active_till` datetime DEFAULT NULL,
  `system_flag` varchar(1) NOT NULL,
  `default_language_flag` varchar(1) DEFAULT NULL,
  `icon_image_file` varchar(240) DEFAULT NULL,
  `installed_flag` varchar(1) DEFAULT NULL,
  `language_code` varchar(255) NOT NULL,
  `language_iso_code` varchar(255) NOT NULL,
  `language_name` varchar(80) NOT NULL,
  `version_number` bigint(20) DEFAULT NULL,
  `language_native_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`language_id`),
  UNIQUE KEY `UK_jj5gykfyxfn360llurwbgjws6` (`language_code`),
  UNIQUE KEY `UK_159tjwo23tva1a3gdrh7gla60` (`language_iso_code`),
  UNIQUE KEY `UK_r8vukrmvk7syejyojw1hklpe2` (`language_name`),
  KEY `FES_LANGUAGE_IX2` (`installed_flag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fes_language`
--

LOCK TABLES `fes_language` WRITE;
/*!40000 ALTER TABLE `fes_language` DISABLE KEYS */;
INSERT INTO `fes_language` VALUES ('0c72dbca-ac3f-49ca-ba24-1b0f8a193750','admin','2019-04-05 11:44:03','admin','2019-04-05 11:44:03','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y','N',NULL,'Y','ir','ga','Irish',1,'Gaeilge'),('2ee7c126-82f7-401d-a8de-0241a1c64357','admin','2019-04-05 11:44:48','admin','2019-04-05 11:44:48','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y','N',NULL,'Y','gu','gu','Gujurati',1,'ગુજરાતી'),('444f8a61-675d-499a-9dd8-628ae2039ef3','admin','2019-04-05 11:47:36','admin','2019-04-05 11:48:32','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y','N',NULL,'Y','ch','zh','Chinese',3,'中文'),('4abdd532-a878-4250-a274-93ca08c0f74e','admin','2019-04-05 11:29:20','admin','2019-04-05 11:29:20','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y','N',NULL,'Y','la','lt','Latin',1,'Lingua latīna'),('731f55b3-67ec-4fd9-b37b-c464418dc73c','admin','2019-04-08 09:59:40','admin','2019-04-08 10:42:21','Y','2019-04-05 17:29:51','2069-04-05 17:29:51','Y','N',NULL,'Y','sp','es','Spanish',3,'español'),('78b609cc-af4a-44e1-9218-c565d7c86408','admin','2019-04-05 11:26:11','admin','2019-04-05 11:26:11','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y','N',NULL,'Y','ma','ml','Malayalam',1,'മലയാളം'),('98d134f1-233e-4715-b397-3dcec7420a01','admin','2019-04-05 16:29:36','admin','2019-04-05 16:29:45','Y','2019-04-05 16:24:03','2069-04-05 16:24:03','Y','N','','Y','hi','hi','Hindi',3,'हिन्दी'),('ae0de202-9bef-40e8-ad1a-756c2a153464','admin','2019-04-05 11:30:03','admin','2019-04-05 11:30:03','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y','N',NULL,'Y','fr','fr','French',1,'français'),('af52fcf7-162b-4b1b-b191-d2951f78fb49','admin','2019-04-05 11:45:59','admin','2019-04-05 11:45:59','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y','N',NULL,'Y','te','te','Telugu',1,'తెలుగు'),('b0397c8f-301a-4491-a728-e882a047aaea','admin','2019-04-05 11:30:50','admin','2019-04-05 11:30:50','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y','N',NULL,'Y','ge','de','German',1,'Deutsch'),('d662ddee-c24f-4de4-8c02-d72c36485462','admin','2019-04-05 11:28:23','admin','2019-04-05 11:28:23','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y','Y',NULL,'Y','en','en','English',1,'English'),('f03ce799-a684-45c5-9577-a270b8b7ec04','admin','2019-04-08 09:58:12','admin','2019-04-08 09:58:12','Y','2019-04-05 17:29:51','2069-04-05 17:29:51','Y','N',NULL,'Y','sa','sa','Sanskrit',1,'संस्कृतम्');
/*!40000 ALTER TABLE `fes_language` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-08 10:48:45
