CREATE DATABASE  IF NOT EXISTS `testdb1` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `testdb1`;
-- MySQL dump 10.13  Distrib 5.7.25, for Win64 (x86_64)
--
-- Host: BLRCSWFBEIP0002    Database: testdb1
-- ------------------------------------------------------
-- Server version	5.7.25-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fes_language_history`
--

DROP TABLE IF EXISTS `fes_language_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fes_language_history` (
  `history_id` varchar(36) NOT NULL,
  `created_by` varchar(36) NOT NULL,
  `created_on` datetime NOT NULL,
  `last_updated_by` varchar(36) NOT NULL,
  `last_updated_on` datetime DEFAULT NULL,
  `active_flag` varchar(1) NOT NULL,
  `active_from` datetime DEFAULT NULL,
  `active_till` datetime DEFAULT NULL,
  `system_flag` varchar(1) NOT NULL,
  `icon_image_file` varchar(240) DEFAULT NULL,
  `installed_flag` varchar(1) DEFAULT NULL,
  `language_code` varchar(255) NOT NULL,
  `language_id` varchar(36) NOT NULL,
  `language_iso_code` varchar(255) NOT NULL,
  `language_name` varchar(80) NOT NULL,
  `language_native_name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `version_number` bigint(20) DEFAULT NULL,
  `default_language_flag` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`history_id`),
  KEY `FES_LANGUAGE_HIST_IX2` (`installed_flag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fes_language_history`
--

LOCK TABLES `fes_language_history` WRITE;
/*!40000 ALTER TABLE `fes_language_history` DISABLE KEYS */;
INSERT INTO `fes_language_history` VALUES ('17a48b99-cf76-4f93-b7fe-7c1090644e84','admin','2019-04-05 11:44:48','admin','2019-04-05 11:44:48','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','gu','2ee7c126-82f7-401d-a8de-0241a1c64357','gu','Gujurati','ગુજરાતી',1,'N'),('18786e6e-40cf-46ad-86b2-e8781ad33cee','admin','2019-04-05 11:28:23','admin','2019-04-05 11:28:23','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','en','d662ddee-c24f-4de4-8c02-d72c36485462','en','English','English',1,'N'),('1de02cdb-0eec-472d-a772-7e861838f3f4','admin','2019-04-05 11:29:20','admin','2019-04-05 11:29:20','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','la','4abdd532-a878-4250-a274-93ca08c0f74e','lt','Latin','Lingua latīna',1,'N'),('33d40376-4026-424a-88b4-c2ad064bbc6c','admin','2019-04-05 11:47:36','admin','2019-04-05 11:47:36','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','ch','444f8a61-675d-499a-9dd8-628ae2039ef3','zh','Chinese','中文',1,'N'),('51860083-b599-4570-b3ce-3228e1a1edf5','admin','2019-04-05 14:33:29','admin','2019-04-05 14:33:29','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y','','Y','ha','98d134f1-233e-4715-b397-3dcec7420a01','hi','Hindi','हिन्दी',2,'N'),('5b167bd8-4845-417f-af19-814c998ea674','admin','2019-04-05 11:48:32','admin','2019-04-05 11:48:32','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','ch','444f8a61-675d-499a-9dd8-628ae2039ef3','zh','Chinese','中文',3,'N'),('70ac5863-23c1-4779-a799-3ccf6dfe8e2d','admin','2019-04-08 09:58:12','admin','2019-04-08 09:58:12','Y','2019-04-05 17:29:51','2069-04-05 17:29:51','Y',NULL,'Y','sa','f03ce799-a684-45c5-9577-a270b8b7ec04','sa','Sanskrit','संस्कृतम्',1,'N'),('72ca6d0e-92f3-4eb5-b6c3-feeabe86067e','admin','2019-04-05 11:48:25','admin','2019-04-05 11:48:25','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','ch','444f8a61-675d-499a-9dd8-628ae2039ef3','zh','Chines','中文',2,'N'),('8a10ede3-c745-42a4-9c11-3b78530a1047','admin','2019-04-05 11:26:11','admin','2019-04-05 11:26:11','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','ma','78b609cc-af4a-44e1-9218-c565d7c86408','ml','Malayalam','മലയാളം',1,'N'),('8a4cb4e6-82ee-4cc1-81c0-1d7973760152','admin','2019-04-05 16:29:45','admin','2019-04-05 16:29:45','Y','2019-04-05 16:24:03','2069-04-05 16:24:03','Y','','Y','hi','98d134f1-233e-4715-b397-3dcec7420a01','hi','Hindi','हिन्दी',3,'N'),('92ef4f3d-cbcc-4a86-bccf-68bab9554650','admin','2019-04-08 10:42:21','admin','2019-04-08 10:42:21','Y','2019-04-05 17:29:51','2069-04-05 17:29:51','Y',NULL,'Y','sp','731f55b3-67ec-4fd9-b37b-c464418dc73c','es','Spanish','español',3,'N'),('99c1d5a9-69d8-4617-95ba-c256f7c7fc40','admin','2019-04-05 11:45:18','admin','2019-04-05 11:45:18','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','hi','98d134f1-233e-4715-b397-3dcec7420a01','hi','Hindi','हिन्दी',1,'N'),('a153d542-7ede-45d0-a80a-ad40597e7b5a','admin','2019-04-08 09:59:40','admin','2019-04-08 09:59:40','Y','2019-04-05 17:29:51','2069-04-05 17:29:51','Y',NULL,'Y','sp','731f55b3-67ec-4fd9-b37b-c464418dc73c','es','Spanish','español',1,'N'),('b2b20bd9-78d3-44ff-ac52-c69f1b065a3a','admin','2019-04-05 11:30:03','admin','2019-04-05 11:30:03','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','fr','ae0de202-9bef-40e8-ad1a-756c2a153464','fr','French','français',1,'N'),('c8d3b07b-982d-4430-9c45-9d7066a3a975','admin','2019-04-08 10:42:16','admin','2019-04-08 10:42:16','Y','2019-04-05 17:29:51','2069-04-05 17:29:51','Y',NULL,'Y','sp','731f55b3-67ec-4fd9-b37b-c464418dc73c','es','Spanis','español',2,'N'),('e5531376-9880-44d5-b933-cef02c3755e5','admin','2019-04-05 11:44:03','admin','2019-04-05 11:44:03','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','ir','0c72dbca-ac3f-49ca-ba24-1b0f8a193750','ga','Irish','Gaeilge',1,'N'),('ea59bf28-1a8e-4856-a2be-8aa69227ae03','admin','2019-04-05 11:30:50','admin','2019-04-05 11:30:50','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','ge','b0397c8f-301a-4491-a728-e882a047aaea','de','German','Deutsch',1,'N'),('f1ca7a75-420c-4d35-bb55-99dd3279bdca','admin','2019-04-05 11:45:59','admin','2019-04-05 11:45:59','Y','2019-04-05 11:24:51','2069-04-05 11:24:51','Y',NULL,'Y','te','af52fcf7-162b-4b1b-b191-d2951f78fb49','te','Telugu','తెలుగు',1,'N');
/*!40000 ALTER TABLE `fes_language_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-08 10:48:41
