
    create table FES_CURR_DENOMINATION_HIST (
	
		history_id varchar(36) not null,
		denomination_id varchar(36) not null,
        bank_id varchar(36) not null,
		currency_id varchar(36) not null,
		denomination_code varchar(30) not null,
		denomination_value int,
		denomination_type_id varchar(36) ,
        active_flag varchar(1) not null,
        active_from date not null,
        active_till date not null,
		system_flag varchar(1) not null,
		version_number decimal(18,0) not null,
        application_identifier integer,
        created_by varchar(36) not null,
        created_on datetime not null,
        last_updated_by varchar(36),
        last_updated_on datetime not null,
		primary key (denomination_id)
    );
	