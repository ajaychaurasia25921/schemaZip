
    create table FES_CURRENCY_TL (
        translation_id varchar(36) not null,
		parent_id varchar(36) not null,
		language_id varchar(36) not null,
		entity_name varchar(80) not null,
		entity_desc varchar(240),
		version_number decimal(18,0),
		created_by varchar(120) not null,
        created_on datetime not null,
		last_updated_by varchar(120),
        last_updated_on datetime,
        active_flag varchar(1) not null,
        active_from date not null,
        active_till date not null,
		system_flag varchar(1),
		primary key (translation_id)
    );
	alter table FES_CURRENCY_TL 
        add constraint FES_CURRENCY_UK1 unique (parent_id,language_id);

    
 

   