
    create table FES_COUNTRY_HIST (
		history_id varchar(36) not null,
        country_id varchar(36) not null,
		country_code varchar(4) not null,
        country_iso_code varchar(4) not null,
		country_numeric_code decimal(3,0) not null,
		country_alternative_code varchar(10),
		country_isd_code decimal(3,0) not null,
		currency_id varchar(36) not null,
		timezone_id varchar(36) not null,
		language_id varchar(36) not null,
		iban_mandatory_flag varchar(1) not null,
		eu_member_flag varchar(1) not null,
		icon_image_file varchar(240),
        active_flag varchar(1) not null,
        active_from date not null,
        active_till date not null,
		system_flag varchar(1),
		version_number decimal(18,0),
        application_identifier integer,
        created_by varchar(36) not null,
        created_on datetime not null,
        last_updated_by varchar(36),
        last_updated_on datetime not null,
		primary key (history_id)
        );
		