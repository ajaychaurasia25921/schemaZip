create table fes_branch(
branch_id varchar(36) not null,
bank_id	varchar(36) not null,
branch_code varchar(20) not null,
branch_name varchar(120) not null,
branch_short_name varchar(20) not null,
registered_date datetime not null,
registered_country_id varchar(36) not null,
icon_image_file varchar(240),
active_flag varchar(1) not null,
active_from date not null,
active_till date not null,
system_flag varchar(1) not null,
version_number decimal(18,0) not null,
created_by varchar(36) not null,
created_on datetime not null,
last_updated_by varchar(36) not null,
last_updated_on datetime not null,
primary key(branch_id)
)	;
alter table fes_branch
        add constraint FES_BRANCH_UK1   unique (bank_id);

alter table fes_branch
        add constraint FES_BRANCH_UK2    unique (branch_code);

alter table fes_branch
        add constraint FES_BRANCH_UK3   unique (branch_name);