create index FES_BANK_HIST_IX1 on FES_BANK_HIST (active_flag);
