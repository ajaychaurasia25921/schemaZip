create index FES_BANK_IX1 on FES_BANK (active_flag);
