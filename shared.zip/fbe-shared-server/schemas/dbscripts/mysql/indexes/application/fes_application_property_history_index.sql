create index FES_APP_PROPERTY_HIST_IX1 on FES_APP_PROPERTY_HIST (active_flag);
