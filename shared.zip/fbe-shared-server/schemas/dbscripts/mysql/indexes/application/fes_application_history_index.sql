create index FES_APPLICATION_HIST_IX1 on FES_APPLICATION_HIST (active_flag);
