create index FES_APP_PROPERTY_IX1 on FES_APP_PROPERTY (active_flag);
