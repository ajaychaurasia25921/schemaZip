create index FES_BANK_PROPERTY_IX1 on FES_BANK_PROPERTY(active_flag);
