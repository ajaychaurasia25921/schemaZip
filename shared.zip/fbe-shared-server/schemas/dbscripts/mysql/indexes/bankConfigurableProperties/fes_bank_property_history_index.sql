create index FES_BANK_PROPERTY_HIST_IX1 on FES_BANK_PROPERTY_HIST (active_flag);
