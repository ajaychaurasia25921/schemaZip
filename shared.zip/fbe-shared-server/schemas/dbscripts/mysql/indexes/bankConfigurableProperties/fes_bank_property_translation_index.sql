 create index FES_BANK_PROPERTY_TL_IX1 on FES_BANK_PROPERTY_TL (parent_id);
  create index FES_BANK_PROPERTY_TL_IX2 on FES_BANK_PROPERTY_TL (language_id);