create index FES_LANGUAGE_HIST_IX1 on FES_LANGUAGE_HISTORY (active_flag);
create index FES_LANGUAGE_HIST_IX2 on FES_LANGUAGE_HISTORY (installed_flag);
