 create index FES_LOOKUP_VALUE_IX1 on FES_LOOKUP_VALUE (active_flag);
 