 create index FES_LOOKUP_VALUE_TL_IX1  on FES_LOOKUP_VALUE_TL (parent_id);
  create index FES_LOOKUP_VALUE_TL_IX2  on FES_LOOKUP_VALUE_TL (language_id);