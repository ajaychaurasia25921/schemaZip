create index FES_BANK_CONTACT_HIST_IX1  on FES_BANK_CONTACT_HIST (active_flag);
