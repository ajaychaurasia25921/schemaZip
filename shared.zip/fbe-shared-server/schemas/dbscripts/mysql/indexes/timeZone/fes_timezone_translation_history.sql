 create index FES_TIMEZONE_HIST_IX1  on FES_TIMEZONE_HIST (active_flag);
