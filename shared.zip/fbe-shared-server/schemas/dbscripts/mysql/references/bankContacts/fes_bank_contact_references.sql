 alter table FES_BANK_CONTACT
        add constraint FES_BANK_CONTACT_FK1
        foreign key (bank_id) 
        references FES_BANK(bank_id);
alter table FES_BANK_CONTACT_HIST
        add constraint FES_BANK_CONTACT_HIST_FK1
        foreign key (contact_id) 
        references FES_BANK_CONTACT (contact_id);
alter table FES_BANK_CONTACT_HIST
        add constraint FES_BANK_CONTACT_HIST_FK2
        foreign key (bank_id) 
        references FES_BANK (bank_id);
				
		