 alter table FES_BRANCH
        add constraint FES_BRANCH_FK1  
        foreign key (bank_id) 
        references FES_BANK (bank_id);
		
alter table FES_BRANCH 
        add constraint FES_BRANCH_FK2 
        foreign key (branch_id) 
        references FES_COUNTRY (country_id);
		
		
		
alter table FES_BRANCH_HIST 
        add constraint FES_BRANCH_HIST_FK1
        foreign key (branch_id) 
        references FES_BRANCH (branch_id);
alter table FES_BRANCH_HIST 
        add constraint FES_BRANCH_HIST_FK2 
        foreign key (bank_id) 
        references FES_BANK (bank_id);
		
		
		
		
alter table FES_BRANCH_PROPERTY 
        add constraint FES_BRANCH_PROPERTY_FK1 
        foreign key (branch_id) 
        references FES_BRANCH (branch_id);
		
		
		
		
alter table FES_BRANCH_PROPERTY_TL
        add constraint FES_BRANCH_PROPERTY_TL_FK1   
        foreign key (parent_id) 
        references FES_BRANCH_PROPERTY (branch_id);
		
alter table FES_BRANCH_PROPERTY_TL
        add constraint FES_BRANCH_PROPERTY_TL_FK2   
        foreign key (language_id) 
        references FES_LANGUAGE (language_id);
		
		
		
alter table FES_BRANCH_PROPERTY_HIST 
        add constraint FES_BRANCH_PROPERTY_HIST_FK1  
        foreign key (property_id) 
        references FES_BRANCH_PROPERTY (property_id);
alter table FES_BRANCH_PROPERTY_HIST 
        add constraint FES_BRANCH_PROPERTY_HIST_FK2 
        foreign key (bank_id) 
        references FES_BANK (bank_id);
		
		
		
alter table FES_BRANCH_PROPERTY_VALUE
        add constraint FES_BRANCH_PROPERTY_VALUE  
        foreign key (property_id) 
        references FES_BRANCH_PROPERTY (property_id);
		
		
		
		
alter table FES_BRANCH_PROPERTY_VALUE_HIST 
        add constraint FES_BRANCH_PROPERTY_VALUE_HIST_FK1  
        foreign key (property_value_id) 
        references FES_BRANCH_PROPERTY_VALUE (property_value_id);
alter table FES_BRANCH_PROPERTY_VALUE_HIST 
        add constraint FES_BRANCH_PROPERTY_VALUE_HIST_FK2
        foreign key (property_id) 
        references FES_BRANCH_PROPERTY (property_id);