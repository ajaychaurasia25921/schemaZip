 // must be checked
 
 
 alter table FES_CURR_DENOMINATION
        add constraint 	FES_CURR_DENOMINATION_FK1 
        foreign key (bank_id) 
        references FES_BANK (bank_id);
alter table FES_CURR_DENOMINATION
        add constraint FES_CURR_DENOMINATION_FK2 
        foreign key (currency_id) 
        references FES_CURRENCY (currency_id);
		
		
alter table FES_CURR_DENOMINATION_TL
        add constraint FES_CURR_DENOMINATION_TL_FK1 
        foreign key (denomination_id) 
        references FES_CURR_DENOMINATION (denomination_id);
		
alter table FES_CURR_DENOMINATION_TL
        add constraint FES_CURR_DENOMINATION_HIST_FK1 
        foreign key (denomination_id) 
        references FES_CURR_DENOMINATION (denomination_id);