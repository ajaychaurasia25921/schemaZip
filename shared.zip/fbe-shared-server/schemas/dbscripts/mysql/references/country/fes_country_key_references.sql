 
 alter table FES_COUNTRY
        add constraint FES_COUNTRY_FK1 
        foreign key (currency_id) 
        references FES_CURRENCY (currency_id);
 alter table FES_COUNTRY
        add constraint FES_COUNTRY_FK2
        foreign key (language_id) 
        references FES_LANGUAGE (language_id);
 alter table FES_COUNTRY
        add constraint FES_COUNTRY_FK3 
        foreign key (timezone_id) 
        references FES_TIMEZONE (timezone_id);
		
		
 alter table FES_COUNTRY_TL
        add constraint FES_COUNTRY_TL_FK1 
        foreign key (parent_id) 
        references FES_COUNTRY (country_id);
alter table FES_COUNTRY_TL
        add constraint FES_COUNTRY_TL_FK2 
        foreign key (language_id) 
        references FES_LANGUAGE (language_id);
		
alter table FES_COUNTRY_HIST
        add constraint FES_COUNTRY_HIST_FK1 
        foreign key (country_id) 
        references FES_COUNTRY (country_id);