 alter table FES_APP_PROPERTY
        add constraint FES_APP_PROPERTY_FK1 
        foreign key (application_id) 
        references FES_APPLICATION (application_id);