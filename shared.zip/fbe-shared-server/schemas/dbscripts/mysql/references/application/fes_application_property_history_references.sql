 alter table FES_APP_PROPERTY_HIST
        add constraint FES_APP_PROPERTY_HIST_FK1 
        foreign key (property_id) 
        references FES_APP_PROPERTY (property_id);
 alter table FES_APP_PROPERTY_HIST
        add constraint FES_APP_PROPERTY_HIST_FK2 
        foreign key (application_id) 
        references FES_APPLICATION (application_id);		