/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */


package com.finastra.essence.shared.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.finastra.essence.common.exception.ErrorDetails;
import com.finastra.essence.common.exception.UserDefinedException;
import com.finastra.essence.common.util.ElasticSearchRestClient;
import com.finastra.essence.shared.common.FBESharedServicesConstants;
import com.finastra.essence.shared.common.ISearchFactory;
import com.finastra.essence.shared.repository.LanguageRepository;
import com.finastra.essence.shared.service.dto.LanguageDTO;
import com.finastra.essence.shared.service.mapper.LanguageMapper;
import com.hazelcast.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.ResourceAccessException;

import java.lang.reflect.Method;
import java.util.*;

@Service
@Transactional
@RefreshScope
public class ElasticSearchFilterImpl implements ISearchFactory {

    private String searchParameters = "languageCode,languageIsoCode,languageName,activeFlag_B";

    private final ErrorDetails errorDetails = new ErrorDetails();

    private final Logger log = LoggerFactory.getLogger(ElasticSearchFilterImpl.class);

    private static String theUrl = null;

    public static void ElasticSearchFilterData(String elasticSearchServiceUrl){
        theUrl = elasticSearchServiceUrl;
    }

    @Override
    public Page<LanguageDTO> search(LanguageDTO filter, Pageable page, LanguageRepository languageRepository, LanguageMapper languageMapper) {
        List<LanguageDTO> languageList = new ArrayList<LanguageDTO>();
        ObjectMapper mapper = new ObjectMapper();
        try {
            String query = "{\"query\" : {\"bool\" : {\"must\" :";
            List<String> searchKeyword = new ArrayList<String>();
            List<String> searchParametersList = Arrays.asList(searchParameters.split(","));
            for (String searchField : searchParametersList) {
                String getterMethod =String.valueOf(searchField.charAt(0)).toUpperCase() + searchField.substring(1);
                if(searchField.contains("_")) {
                    searchField = searchField.split("_")[0];
                    getterMethod = "is"+getterMethod.substring(0, getterMethod.indexOf("_"));
                    Method searchMethod = filter.getClass().getMethod(getterMethod);
                    if(searchMethod.invoke(filter) != null) {
                        searchKeyword.add("{\"match\":{\""+ searchField + "\" : "+ searchMethod.invoke(filter) + "}}");
                    }
                }else {
                    getterMethod = "get"+getterMethod;
                    Method searchMethod = filter.getClass().getMethod(getterMethod);
                    if(searchMethod.invoke(filter) != null && !StringUtil.isNullOrEmpty(searchMethod.invoke(filter).toString())) {
                        searchKeyword.add("{\"query_string\":{\"query\":\""+ searchField +  ":" + searchMethod.invoke(filter).toString() + "\"}}");
                    }
                }
            }
            query = query + searchKeyword.toString() + "}}}";
            log.info("[query]:{}",query);
            log.debug(" [ElasticSearch Url] : {} ",theUrl);
            String responseEntity = ElasticSearchRestClient.get(theUrl, query);
            JsonNode node = mapper.readTree(responseEntity);
            JsonNode hitsnode = node.get("hits").get("hits");
            Iterator<JsonNode> childNodes = hitsnode.iterator();
            while (childNodes.hasNext()) {
                LanguageDTO language = new LanguageDTO();
                JsonNode htNode = childNodes.next();
                JsonNode rootNodebase = htNode.get("_source");
                language.setLanguageId(rootNodebase.findPath("languageId").asText());
                language.setLanguageCode(rootNodebase.findPath("languageCode").asText());
                language.setLanguageIsoCode(rootNodebase.findPath("languageIsoCode").asText());
                language.setLanguageName(rootNodebase.findPath("languageName").asText());
                language.setLanguageNativeName(rootNodebase.findPath("languageNativeName").asText());
                language.setIconImageFile(rootNodebase.findPath("iconImageFile").asText());
                language.setSystemFlag(rootNodebase.findPath("systemFlag").asBoolean());
                language.setInstalledFlag(rootNodebase.findPath("installedFlag").asBoolean());
                language.setActiveFlag(rootNodebase.findPath("activeFlag").asBoolean());
                language.setCreatedBy(rootNodebase.findPath("createdBy").asText());
                language.setLastModifiedBy(rootNodebase.findPath("lastModifiedBy").asText());
                language.setDefaultLanguageFlag(rootNodebase.findPath("defaultLanguageFlag").asBoolean());
                languageList.add(language);
            }
        }catch (ResourceAccessException e) {
            errorDetails.setDetail(FBESharedServicesConstants.ELST_SEARCH_DOWN);
            throw new UserDefinedException(errorDetails);
        } catch (Exception e) {
            errorDetails.setDetail(FBESharedServicesConstants.LANG_NOT_EXIST);
            throw new UserDefinedException(errorDetails);
        }
        Page<LanguageDTO> pages = new PageImpl<LanguageDTO>(languageList,page,languageList.size());
        return pages;
    }
}