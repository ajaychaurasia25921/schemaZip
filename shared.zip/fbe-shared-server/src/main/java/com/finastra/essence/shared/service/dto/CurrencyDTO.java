/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.shared.service.dto;

import com.finastra.essence.common.dto.AbstractEffectiveEntityDTO;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A DTO for the Currency entity.
 */
@Component
@ConfigurationProperties("messages")
public class CurrencyDTO extends AbstractEffectiveEntityDTO implements Serializable {

	private static final long serialVersionUID = 1L;


    @Size(max = 36)
    private String currencyId;

    @NotNull(message = "{currencyCode.notempty}")
    @Pattern(regexp = "^[[\\s]*[a-zA-Z][\\s]*]{2,5}$", message = "{currencyCode.pattern}")
    private String currencyCode;

    @NotNull(message = "{currencyIsoCode.notempty}")
    @Pattern(regexp = "^[[\\s]*[a-zA-Z][\\s]*]{3}$", message = "{currencyIsoCode.pattern}" )
    private String currencyIsoCode;

    @NotNull(message = "{currencyNumericCode.notempty}")
    @Pattern(regexp = "^[0-9]{1,4}$", message = "{currencyNumericCode.pattern}")
    private String currencyNumericCode;

    @NotNull(message = "{currencyAlternativeCode.notempty}")
    @Size(max=10 , message = "{currencyAlternativeCode.size}")
    private String currencyAlternativeCode;

    @Size(max=240 , message = "{iconImageFile.size}")
    private String iconImageFile;

    Set<CurrencyTranslationDTO> currencyTranslations = new HashSet<>();

    public String getCurrencyId() {
        return currencyId;
    }

    public void setCurrencyId(String currencyId) {
        this.currencyId = currencyId;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getCurrencyIsoCode() {
        return currencyIsoCode;
    }

    public void setCurrencyIsoCode(String currencyIsoCode) {
        this.currencyIsoCode = currencyIsoCode;
    }

    public String getCurrencyNumericCode() {
        return currencyNumericCode;
    }

    public void setCurrencyNumericCode(String currencyNumericCode) {
        this.currencyNumericCode = currencyNumericCode;
    }

    public String getCurrencyAlternativeCode() {
        return currencyAlternativeCode;
    }

    public void setCurrencyAlternativeCode(String currencyAlternativeCode) {
        this.currencyAlternativeCode = currencyAlternativeCode;
    }

    /**
     * This is a getter which gets the list of currency translations from currency.
     *
     * @return the list of currency translations.
     *
     */
    public Set<CurrencyTranslationDTO> getCurrencyTranslations() {
        return currencyTranslations;
    }

    public CurrencyDTO CurrencyTranslations(Set<CurrencyTranslationDTO> currencyTranslations) {
        this.currencyTranslations = currencyTranslations;
        return this;
    }


    public CurrencyDTO addCurrencyTranslation(CurrencyTranslationDTO currencyTranslation) {
        this.currencyTranslations.add(currencyTranslation);
        return this;
    }

    /**
     * This is a setter which sets the list of currency translations.
     *
     * @param currencyTranslations the list of currency translations to be set in currency.
     *
     */
    public void setCurrencyTranslations(Set<CurrencyTranslationDTO> currencyTranslations) {
        this.currencyTranslations = currencyTranslations;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CurrencyDTO currencyDTO = (CurrencyDTO) o;
        if (currencyDTO.getCurrencyId() == null || getCurrencyId() == null) {
            return false;
        }
        return Objects.equals(getCurrencyId(), currencyDTO.getCurrencyId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getCurrencyId());
    }

    @Override
    public String toString() {
        return "CurrencyDTO{"
                + ", currencyId='" + getCurrencyId() + "'"
                + ", currencyCode='" + getCurrencyCode() + "'"
                + ", currencyIsoCode='" + getCurrencyIsoCode() + "'"
                + ", currencyNumericCode=" + getCurrencyNumericCode()
                + ", currencyAlternativeCode='" + getCurrencyAlternativeCode() + "'"
                + ", systemFlag='" + isSystemFlag() + "'"
                + ", currencyTranslations=" + getCurrencyTranslations() + "'"
                + "}";
    }

    public String getIconImageFile() {
        return iconImageFile;
    }

    public void setIconImageFile(String iconImageFile) {
        this.iconImageFile = iconImageFile;
    }
}
