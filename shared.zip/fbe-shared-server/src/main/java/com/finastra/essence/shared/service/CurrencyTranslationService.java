/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.finastra.essence.shared.service;

import com.finastra.essence.shared.service.dto.CurrencyTranslationDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Service Interface for managing CurrencyTranslation.
 */
public interface CurrencyTranslationService {

    /**
     * Stores the currency translation entity after validating attributes of currency translation.
     * The currencyTranslationDTO argument should be given during post operations.
     *
     * @param currencyTranslationDTO the currencytranslation entity to be stored.
     * @return the persisted currency translation entity.
     */
    CurrencyTranslationDTO save(CurrencyTranslationDTO currencyTranslationDTO);

    /**
     * Retrieves all the currency translations
     * from currency translation database.
     *
     * @param pageable the pagination information.
     * @return the list of currency translations.
     */
    Page<CurrencyTranslationDTO> findAll(Pageable pageable);

    /**
     * Retrieves the currency translation whose translationId is specified
     * in argument, from currency translations database.
     *
     * @param translationId the translationId of
     *        the currency translation entity to be retrieved.
     * @return the currency translation entity
     *         of specified translationId.
     */
    Optional<CurrencyTranslationDTO> findOne(String translationId);

    /**
     * Delete the currency translation whose translationId is specified
     * in argument.
     *
     * @param translationId the translationId of the currency translation
     *        entity to be deleted.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    void delete(String translationId) throws URISyntaxException;
    /**
     * Amends the currency translation entity after validating attributes of currency translation.
     * The currencyTranslationDTO argument should be given during put operations.
     *
     * @param currencyTranslation the currency translation entity to be amended.
     * @return the persisted currency translation entity.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    CurrencyTranslationDTO update(CurrencyTranslationDTO currencyTranslation) throws URISyntaxException;
    /**
     * Synchronizing currency translation entities between
     * the currency translation database and  elasticsearch.
     *
     * @return the list of currency translations.
     */
    void syncData();
}
