/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.shared.service.impl;

import com.finastra.essence.common.domain.Elastic;
import com.finastra.essence.common.domain.KafkaMessage;
import com.finastra.essence.common.exception.ErrorDetails;
import com.finastra.essence.common.exception.UserDefinedException;
import com.finastra.essence.common.util.ElasticSearchRestClient;
import com.finastra.essence.shared.common.FBESharedServicesConstants;
import com.finastra.essence.shared.common.KafkaHandler;
import com.finastra.essence.shared.service.CurrencyTranslationService;
import com.finastra.essence.shared.domain.Currency;
import com.finastra.essence.shared.domain.CurrencyTranslation;
import com.finastra.essence.shared.repository.CurrencyTranslationRepository;
import com.finastra.essence.shared.service.dto.CurrencyTranslationDTO;
import com.finastra.essence.shared.service.mapper.CurrencyTranslationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.KafkaException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.ResourceAccessException;
import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing CurrencyTranslation.
 */
@Service
@Transactional
@RefreshScope
public class CurrencyTranslationServiceImpl implements CurrencyTranslationService {

    @Value("${elasticSearchServiceUrl}")
    private String elasticSearchServiceUrl;

    @Value("${broker}")
    private String broker;

    @Value("${currencyTranslationTopic}")
    private String currencyTranslationTopic;

    @Value("${docUrl}")
    private String docUrl;

    @Value("${searchServiceUrl}")
    private String searchServiceUrl;

    private final ErrorDetails errorDetails = new ErrorDetails();

    private final String ENTITY_NAME = "fes_currency_translation";

    private final Logger log = LoggerFactory.getLogger(CurrencyTranslationServiceImpl.class);

    private final CurrencyTranslationRepository currencyTranslationRepository;

    private final CurrencyTranslationMapper currencyTranslationMapper;

    /**
     * Class constructor initializes currencyTranslationRepository and currencyTranslationMapper objects.
     * @param currencyTranslationMapper the object of CurrencyTranslationRepository to be initialized.
     * @param currencyTranslationMapper the object of CurrencyTranslationMapper to be initialized.
     */
    public CurrencyTranslationServiceImpl(CurrencyTranslationRepository currencyTranslationRepository, CurrencyTranslationMapper currencyTranslationMapper) {
        this.currencyTranslationRepository = currencyTranslationRepository;
        this.currencyTranslationMapper = currencyTranslationMapper;
    }

    /**
     * Stores the currency translation entity after validating attributes of currency translation.
     * The currencyTranslationDTO argument should be given during post operations.
     * If the none of the currency translation's attribute violates the constraints then
     * the currency translation gets stored, otherwise relative message
     * of violation should be displayed.
     *
     * @param currencyTranslationDTO the currencytranslation entity to be stored.
     * @return the persisted currency translation entity.
     */
    @Override
    public CurrencyTranslationDTO save(CurrencyTranslationDTO currencyTranslationDTO) {
        log.debug("Request to save CurrencyTranslation : {}", currencyTranslationDTO);
        validatePostCurrencyTranslation(currencyTranslationDTO);
        CurrencyTranslation currencyTranslation=null;
        try {
            currencyTranslation = currencyTranslationMapper.toEntity(currencyTranslationDTO);
            currencyTranslation = currencyTranslationRepository.saveAndFlush(currencyTranslation);
            
        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(FBESharedServicesConstants.CURRTL_INVL);
            throw new UserDefinedException(errorDetails);
        }

            KafkaHandler.produce(new KafkaMessage().createMessage(FBESharedServicesConstants.CURRTL_ENTITY, currencyTranslation.getTranslationId(),FBESharedServicesConstants.CREATED,String.valueOf(currencyTranslation)), broker, currencyTranslationTopic);

        	ElasticSearchRestClient.post(currencyTranslation, currencyTranslation.getTranslationId(), elasticSearchServiceUrl + ENTITY_NAME + docUrl);

        return currencyTranslationMapper.toDto(currencyTranslation);
    }

    /**
     * Amends the currency translation entity after validating attributes of currency translation.
     * The currencyTranslationDTO argument should be given during put operations.
     * If the none of the currency translation's attribute violates the constraints then
     * the respective currency translation gets updated, otherwise relative message
     * of violation should be displayed.
     *
     * @param currencyTranslationDTO the currency translation entity to be amended.
     * @return the persisted currency translation entity.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @Override
    public CurrencyTranslationDTO update(CurrencyTranslationDTO currencyTranslationDTO) throws URISyntaxException {
        log.debug("REST request to update CurrencyTranslation : {}", currencyTranslationDTO);
        validatePutCurrencyTranslation(currencyTranslationDTO);
        try {
            CurrencyTranslation currencyTranslation=null;
            Optional<CurrencyTranslation> currencyExist = currencyTranslationRepository.findById(currencyTranslationDTO.getTranslationId());
            if (!currencyExist.isPresent()) {
                throw new DataIntegrityViolationException(FBESharedServicesConstants.CURRTL_NOT_EXIST);
            } else {
            	CurrencyTranslation currencyTranslationTOUpdate = currencyTranslationMapper.toEntity(currencyTranslationDTO);
                if  (!currencyExist.get().equals(currencyTranslationTOUpdate)) { 

                            currencyTranslation = new CurrencyTranslation().setUpdate(currencyTranslationDTO,currencyExist.get());
                            KafkaHandler.produce(new KafkaMessage().createMessage(FBESharedServicesConstants.CURRTL_ENTITY,currencyTranslation.getTranslationId(),FBESharedServicesConstants.UPDATED,String.valueOf(currencyTranslation)), broker, currencyTranslationTopic);

                        	 ElasticSearchRestClient.put(currencyTranslation, currencyTranslation.getTranslationId(),elasticSearchServiceUrl + ENTITY_NAME + docUrl);
                    }
               else {
                        throw new DataIntegrityViolationException(FBESharedServicesConstants.EN_NO_CHNG_FOUND);
                    }

                    return currencyTranslationMapper.toDto(currencyTranslation);
                }
            } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * Retrieves all the currency translations
     * from currency translation database.
     *
     * @param pageable the pagination information.
     * @return the list of currency translations.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<CurrencyTranslationDTO> findAll(Pageable pageable) {
        log.debug("Request to get all CurrencyTls");
        return currencyTranslationRepository.findAll(pageable)
            .map(currencyTranslationMapper::toDto);
    }

    /**
     * Retrieves the currency translation whose translationId is specified
     * in argument, from currency translations database.
     *
     * @param translationId the translationId of
     *        the currency translation entity to be retrieved.
     * @return the currency translation entity
     *         of specified translationId.
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<CurrencyTranslationDTO> findOne(String translationId) {
        log.debug("Request to get CurrencyTranslation : {}", translationId);
        return currencyTranslationRepository.findById(translationId)
            .map(currencyTranslationMapper::toDto);
    }

    /**
     * Validates the "translationId" of currency translation entity
     *  during post operations.
     * @param currencyTranslation the currencyTranslation entity
     *        whose translationId to be validated.
     */
    private void validateTranslationId(CurrencyTranslationDTO currencyTranslation) {
        if (currencyTranslation.getTranslationId() != null && !currencyTranslation.getTranslationId().trim().equals("")) {
            errorDetails.setDetail(FBESharedServicesConstants.CURRTL_ID_AUTOGEN);
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * Validates the "translationId" of currency translation entity
     * during put operations.
     * @param currencyTranslation the currencyTranslation entity
     *        whose translationId to be validated.
     */
    private void validatePutTranslationId(CurrencyTranslationDTO currencyTranslation) {
        if (currencyTranslation.getTranslationId() == null) {
            errorDetails.setDetail(FBESharedServicesConstants.CURRTL_ID_NULL);
            throw new UserDefinedException(errorDetails);
        }
    }


    private void formatEntityName(CurrencyTranslationDTO currencyTranslation) {
        String entityName = currencyTranslation.getEntityName().trim();
        entityName = Character.toUpperCase(entityName.charAt(0)) + entityName.substring(1);
        currencyTranslation.setEntityName(entityName);
    }

    /**
     * Validates the "entityDesc" of currency translation entity
     * during both post and put operations.
     * @param currencyTranslation the currencyTranslation entity
     *        whose entityDesc to be validated.
     */
    private void validateEntityDesc(CurrencyTranslationDTO currencyTranslation) {
        String entityDesc = currencyTranslation.getEntityDesc();
        if (!currencyTranslation.getEntityDesc().equals(null)) {

            entityDesc = currencyTranslation.getEntityDesc().trim();

        }
        currencyTranslation.setEntityDesc(entityDesc);
    }


    /**
     * Validates all the attributes of currency translation before storing into
     * database and elasticsearch.
     *
     * @param currencyTranslationDTO the currencyTranslationDTO entity to be validated.
     */
    public void validatePostCurrencyTranslation(CurrencyTranslationDTO currencyTranslationDTO) {
        validateTranslationId(currencyTranslationDTO);
        formatEntityName(currencyTranslationDTO);
        validateEntityDesc(currencyTranslationDTO);
    }

    /**
     * Validates all the attributes of currency translation before amending into
     * database and elasticsearch.
     *
     * @param currencyTranslationDTO the currencyTranslationDTO entity to be validated.
     */
    public void validatePutCurrencyTranslation(CurrencyTranslationDTO currencyTranslationDTO) {
        validatePutTranslationId(currencyTranslationDTO);
        formatEntityName(currencyTranslationDTO);
        validateEntityDesc(currencyTranslationDTO);
    }

    /**
     * Delete the currency translation whose translationId is specified
     * in argument.
     *
     * @param translationId the translationId of the currency translation
     *        entity to be deleted.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @Override
    public void delete(String translationId) throws URISyntaxException {
        log.debug("Request to delete CurrencyTl : {}", translationId);
        currencyTranslationRepository.deleteById(translationId);
        KafkaHandler.produce(new KafkaMessage().createMessage(FBESharedServicesConstants.CURRTL_ENTITY,translationId,FBESharedServicesConstants.DELETED,String.valueOf(translationId)), broker, currencyTranslationTopic);
        ElasticSearchRestClient.delete(translationId, elasticSearchServiceUrl + ENTITY_NAME + docUrl);
    }

    /**
     * Synchronizing currency translation entities between
     * the currency translation database and  elasticsearch.
     *
     * @return the list of currency translations.
     */
    @Override
    public void syncData() {
    	 ResponseEntity<Elastic> responseEntity=null;
        try {
            List<CurrencyTranslation> getAllCurrency=currencyTranslationRepository.findAll();
            for (CurrencyTranslation currencyTranslation: getAllCurrency) {
            	responseEntity = ElasticSearchRestClient.post(currencyTranslation, currencyTranslation.getTranslationId(),elasticSearchServiceUrl + ENTITY_NAME + docUrl);  
			}
            if (!(responseEntity.getStatusCode().toString().equalsIgnoreCase("200")) && !(responseEntity.getStatusCode().toString().equalsIgnoreCase("201"))) {
                throw new Exception(FBESharedServicesConstants.ELST_SEARCH_DOWN);
            }
        } catch(Exception e) {
            errorDetails.setDetail(FBESharedServicesConstants.ELST_SEARCH_DOWN);
            throw new UserDefinedException(errorDetails);
        }
    }
   
}
