/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.shared.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.finastra.essence.common.domain.AbstractEffectiveEntity;
import com.finastra.essence.shared.service.dto.CurrencyDTO;
import org.hibernate.annotations.GenericGenerator;

/**
 * Currency is a class extends {@link AbstractEffectiveEntity} and hold
 * definitions for currency_id, currency_code, currency_iso_code,
 * currency_numeric_code, currency_alternative_code and icon_image_file.
 * One to Many relationship association using a foreign key mapping,
 * with Currency Translation.
 *
 * @since 1.0
 */

@Entity
@Table(name = "FES_CURRENCY")
public class Currency extends AbstractEffectiveEntity implements Serializable {

	/**
	 * Serialization version identifier
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Attribute holding the value of unique identifier assigned to a currency,
	 * which is auto-generated.
	 */
	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Size(max = 36)
	@Column(name = "currency_id", length = 36)
	private String currencyId;
	/**
	 * Attribute holding the value of unique code assigned to a currency.
	 */
	@NotNull
	@Column(unique = true, name = "currency_code", nullable = false)
	private String currencyCode;
	/**
	 * Attribute holding the value of ISO code (3 letters) associated with a
	 * currency.
	 */
	@NotNull
	@Column(unique = true, name = "currency_iso_code", nullable = false)
	private String currencyIsoCode;
	/**
	 * Attribute holding the image filename associated with a currency.
	 */
	@Size(max = 240)
	@Column(name = "icon_image_file", length = 240)
	private String iconImageFile;
	/**
	 * Attribute holding the value of three-digit unique code number assigned to a
	 * currency as per ISO 3166-1 numeric codes.
	 */
	@NotNull
	@Column(unique = true, name = "currency_numeric_code", nullable = false)
	private String currencyNumericCode;
	/**
	 * Attribute holding the value of alternative code assigned to a currency.
	 */
	@NotNull
	@Size(max = 10)
	@Column(name = "currency_alternative_code", length = 10, nullable = false)
	private String currencyAlternativeCode;

	/**
	 * One to Many relationship with Currency Translation.
	 */
	@OneToMany(cascade = CascadeType.MERGE, orphanRemoval = true, fetch = FetchType.LAZY)
	@JoinColumn(name = "parent_id", nullable = false)
	Set<CurrencyTranslation> currencyTranslations = new HashSet<>();



	/**
	 * This is a getter which gets unique identifier assigned to the currency.
	 * @return the string value holding unique identifier assigned to a currency.
	 */
	public String getCurrencyId() {
		return currencyId;
	}

	/**
	 * Attribute holding version number of the currency.
	 */
	@Version
	@Column(name = "version_number", columnDefinition = "BIGINT(20)")
	@JsonIgnore
	private Long versionNumber=1L;

	/**
	 * This is a setter which sets version number assigned to the currency.
	 * @param versionNumber the string value holding version number assigned to a currency.
	 */
	public void setVersionNumber(Long versionNumber) {
		this.versionNumber = versionNumber;
	}

	/**
	 * This is a getter which gets version number assigned to the currency.
	 * @return the string value holding version number assigned to a currency.
	 */
	public Long getVersionNumber() {
		return versionNumber;
	}
	
	public Currency versionNumber(long versionNumber) {
		this.versionNumber = versionNumber;
		return this;
	}
	
	public Currency currencyId(String currencyId) {
		this.currencyId = currencyId;
		return this;
	}

	/**
	 * This is a setter which sets unique identifier to the currency.
	 * @param currencyId the unique identifier assigned to a currency.
	 */
	public void setCurrencyId(String currencyId) {
		this.currencyId = currencyId;
	}

	/**
	 * This is a getter which gets unique code of currency.
	 * @return currencyCode the string value holding the unique code assigned to a currency.
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	public Currency currencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
		return this;
	}

	/**
	 * This is a setter which sets unique code of currency.
	 *
	 * @param currencyCode the unique code assigned to a currency.
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * This is a getter which gets ISO code of currency.
	 *
	 * @return the string value holding the ISO code associated with a currency.
	 */
	public String getCurrencyIsoCode() {
		return currencyIsoCode;
	}

	public Currency currencyIsoCode(String currencyIsoCode) {
		this.currencyIsoCode = currencyIsoCode;
		return this;
	}

	/**
	 * This is a setter which sets ISO code of currency.
	 *
	 * @param currencyIsoCode the ISO code (3 letters) associated with a
	 * 	      currency.
	 */
	public void setCurrencyIsoCode(String currencyIsoCode) {
		this.currencyIsoCode = currencyIsoCode;
	}

	/**
	 * This is a getter which gets three-digit Numeric code number of currency.
	 *
	 * @return the string value holding the three-digit unique Numeric code number assigned
	 *         to a currency.
	 */
	public String getCurrencyNumericCode() {
		return currencyNumericCode;
	}

	public Currency currencyNumericCode(String currencyNumericCode) {
		this.currencyNumericCode = currencyNumericCode;
		return this;
	}

	/**
	 * This is a setter which sets three-digit Numeric code number of currency.
	 *
	 * @param currencyNumericCode the three-digit unique Numeric code number assigned to a
	 * 	      currency as per ISO 3166-1 numeric codes.
	 */
	public void setCurrencyNumericCode(String currencyNumericCode) {
		this.currencyNumericCode = currencyNumericCode;
	}

	/**
	 * This is a getter which gets alternative code assigned to a currency.
	 *
	 * @return the string value holding the alternative code assigned to a currency.
	 */
	public String getCurrencyAlternativeCode() {
		return currencyAlternativeCode;
	}

	public Currency currencyAlternativeCode(String currencyAlternativeCode) {
		this.currencyAlternativeCode = currencyAlternativeCode;
		return this;
	}

	/**
	 * This is a setter which sets alternative code of a currency.
	 *
	 * @param currencyAlternativeCode the alternative code assigned to a currency.
	 */
	public void setCurrencyAlternativeCode(String currencyAlternativeCode) {
		this.currencyAlternativeCode = currencyAlternativeCode;
	}

	/**
	 * This is a getter which gets the image filename associated with a currency.
	 *
	 * @return the string value holding the image filename associated with a
	 *         currency.
	 */
	public String getIconImageFile() {
		return iconImageFile;
	}
	
	public Currency currencyIconImageFile(String iconImageFile) {
		this.iconImageFile = iconImageFile;
		return this;
	}

	/**
	 * This is a setter which sets the image filename associated with a currency.
	 *
	 * @param iconImageFile he image filename associated with a
	 *        currency.
	 */
	public void setIconImageFile(String iconImageFile) {
		this.iconImageFile = iconImageFile;
	}



	/**
	 * This is a getter which gets the list of currency translations from currency.
	 *
	 * @return the list of currency translations.
	 *
	 */
	public Set<CurrencyTranslation> getCurrencyTranslations() {
		return currencyTranslations;
	}

	public Currency CurrencyTranslations(Set<CurrencyTranslation> currencyTranslations) {
		this.currencyTranslations = currencyTranslations;
		return this;
	}


	public Currency addCurrencyTranslation(CurrencyTranslation currencyTranslation) {
		this.currencyTranslations.add(currencyTranslation);
		return this;
	}

	/**
	 * This is a setter which sets the list of currency translations.
	 *
	 * @param currencyTranslations the list of currency translations to be set in currency.
	 *
	 */
	public void setCurrencyTranslations(Set<CurrencyTranslation> currencyTranslations) {
		this.currencyTranslations.clear();
		this.currencyTranslations.addAll(currencyTranslations);
		//this.currencyTranslations = currencyTranslations;
	}


	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		Currency currency = (Currency) o;
		return Objects.equals(currencyId, currency.currencyId) && Objects.equals(currencyCode, currency.currencyCode)
				&& Objects.equals(currencyIsoCode, currency.currencyIsoCode)
				&& Objects.equals(iconImageFile, currency.iconImageFile)
				&& Objects.equals(currencyNumericCode, currency.currencyNumericCode)
				&& Objects.equals(currencyAlternativeCode, currency.currencyAlternativeCode)
				&& Objects.equals(currencyTranslations, currency.currencyTranslations)
				&& isActiveFlag() == currency.isActiveFlag()
				&& isSystemFlag() == currency.isSystemFlag();
	}

	@Override
	public int hashCode() {
		return Objects.hash(currencyId, currencyCode, currencyIsoCode, iconImageFile, currencyNumericCode,
				currencyAlternativeCode, currencyTranslations);
	}

	@Override
	public String toString() {
		return "{" + ", currencyId:'" + getCurrencyId() + "'" + "," + "currencyCode:'" + getCurrencyCode() + "'"
				+ ", currencyIsoCode:'" + getCurrencyIsoCode() + "'" + ", " + "currencyNumericCode:"
				+ getCurrencyNumericCode() + "," + "currencyAlternativeCode:'" + getCurrencyAlternativeCode() + "'"
				+ ", iconImageFile:'" + getIconImageFile() + "'"
				+ ", version_number=" + versionNumber + "'"
				+ ", currencyTranslations=" + getCurrencyTranslations()+ "'" +"}";
	}

	public Currency setUpdate(CurrencyDTO object, Currency currency) {
		currency.setCurrencyId(object.getCurrencyId());
		currency.setCurrencyCode(object.getCurrencyCode());
		currency.setCurrencyIsoCode(object.getCurrencyIsoCode());
		currency.setIconImageFile(object.getIconImageFile());
		currency.setSystemFlag(object.isSystemFlag());
		currency.setCurrencyNumericCode(object.getCurrencyNumericCode());
		currency.setCurrencyAlternativeCode(object.getCurrencyAlternativeCode());
		currency.setActiveFlag(object.isActiveFlag());
		currency.setVersionNumber(currency.getVersionNumber()+1);
		currency.setCreatedBy(object.getCreatedBy());
		currency.setCreatedOn(object.getCreatedOn());
		currency.setActiveFrom(object.getActiveFrom());
		currency.setActiveTill(object.getActiveTill());
		currency.setLastModifiedBy(object.getLastModifiedBy());
		currency.setLastModifiedOn(object.getLastModifiedOn());
		return currency;
	}
}
