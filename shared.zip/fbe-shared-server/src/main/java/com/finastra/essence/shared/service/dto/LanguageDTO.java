/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.shared.service.dto;

import com.finastra.essence.common.dto.AbstractEffectiveEntityDTO;
import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import javax.persistence.Column;
import com.finastra.essence.common.util.BooleanToStringConverter;
import com.finastra.essence.shared.domain.Language;
import javax.validation.constraints.Pattern;
import javax.persistence.Convert;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Language entity.
 */
public class LanguageDTO extends AbstractEffectiveEntityDTO implements Serializable {
	
    @Size(max = 36)
    private String languageId;

    @NotNull(message = "{languageCode.notempty}")
    @Pattern(regexp = "^[[\\s]*[a-zA-Z][\\s]*]{2,3}$", message = "{languageCode.pattern}")
    private String languageCode;

    @NotNull(message = "{languageIsoCode.notempty}")
    @Pattern(regexp = "^[[\\s]*[a-zA-Z][\\s]*]{2}$",message = "{languageIsoCode.pattern}")
    private String languageIsoCode;

    @NotNull(message = "{languageName.notempty}")
    @Pattern(regexp = "^[[\\s]*[a-zA-Z][\\s]*]{5,81}$",message = "{languageName.pattern}")
    private String languageName;

    @NotNull(message = "{languageNativeName.notempty}")
    private String languageNativeName;

    @Size(max = 240,message = "{iconImageFile.size}")
    private String iconImageFile;
	
    private boolean installedFlag;
	
    private Boolean defaultLanguageFlag;

	public Boolean getDefaultLanguageFlag() {
        return defaultLanguageFlag;   
    }

    public void setDefaultLanguageFlag(Boolean defaultLanguageFlag) {
        this.defaultLanguageFlag = defaultLanguageFlag;
    }

    public String getLanguageId() {
        return languageId;
    }

    public void setLanguageId(String languageId) {
        this.languageId = languageId;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }

    public String getLanguageIsoCode() {
        return languageIsoCode;
    }

    public void setLanguageIsoCode(String languageIsoCode) {
        this.languageIsoCode = languageIsoCode;
    }

    public String getLanguageName() {
        return languageName;
    }

    public void setLanguageName(String languageName) {
        this.languageName = languageName;
    }

    public String getLanguageNativeName() {
        return languageNativeName;
    }

    public void setLanguageNativeName(String languageNativeName) {
        this.languageNativeName = languageNativeName;
    }

    public String getIconImageFile() {
        return iconImageFile;
    }

    public void setIconImageFile(String iconImageFile) {
        this.iconImageFile = iconImageFile;
    }

	public boolean getInstalledFlag() {
		return installedFlag;
	}
	
	public void setInstalledFlag(boolean installedFlag) {
		this.installedFlag = installedFlag;
	}
	
	public void setInstalledFlag(Boolean installedFlag) {
		this.installedFlag = installedFlag;
	}

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        LanguageDTO languageDTO = (LanguageDTO) o;
        if (languageDTO.getLanguageId() == null || getLanguageId() == null) {
            return false;
        }
        return Objects.equals(getLanguageId(), languageDTO.getLanguageId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getLanguageId());
    }

    @Override
    public String toString() {
        return "{"
                + " languageId='" + getLanguageId() + "'"
                + ", languageCode='" + getLanguageCode() + "'"
                + ", languageIsoCode='" + getLanguageIsoCode() + "'"
                + ", languageName='" + getLanguageName() + "'"
                + ", languageNativeName='" + getLanguageNativeName() + "'"
                + ", iconImageFile='" + getIconImageFile() + "'"
                + ", systemFlag='" + isSystemFlag() + "'"
                + ", installedFlag='" + getInstalledFlag() + "'"
                + ", activeFlag='" + isActiveFlag() + "'"
                + "}";
    }
}
