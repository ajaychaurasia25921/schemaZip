/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */


package com.finastra.essence.shared.common;

/**
 * This class contains the constraint violation constants.
 * Created by bnandima on 3/13/2019.
 */
public interface FBESharedServicesConstants {
    //Generic constraint violation.
    String EN_EXIST = "Entity already exist";
    String EN_NOT_EXIST = "Entity does not exist";
    String EN_NO_CHNG_FOUND = "No Change Found";
    String INVALID_DATE = "Unable to parse Date";
    String NO_DATA_FOUND = "No data found ";
    String INVAL_UPDATE = "May lead to deletion of record";
    //Currency entity constraint violation.
    String CURR_EXIST = "Currency already exist";
    String CURR_NOT_EXIST = "Currency does not exist";
    String CURR_ID_AUTOGEN = "Currency ID should not be passed which is to be auto generated";
    String INVAL_ID = "Invalid ID";
    String INVAL_CURR_CODE = "Currency Code must contain only alphabets with minimum of 2 characters and maximum of 4 characters.";
    String INVAL_CURR_ISO_CODE = "Currency Iso Code must contain only alphabets of exactly 3 characters";
    String INVAL_CURR_NUM_CODE = " Currency Numeric Code must be exactly of 3 characters";
    String INVAL_EN_CODE = "Invalid code";
    String CURR_ID_NULL = "Currency ID is null";
    //Language entity constraint violation.
    String LANG_EXIST = "Language already exist";
    String LANG_NOT_EXIST = "Language does not exist";
    String LANG_ID_AUTOGEN = "Language ID should not be passed which is to be auto generated";
    String INVAL_LANG_CODE = "Language Code must contain only alphabets with minimum of 2 characters and maximum of 3 characters";
    String INVAL_LANG_ISO_CODE = "Language Iso Code must contain only alphabets of exactly 2 characters ";
    String INVAL_LANG_NAME = "Please enter valid Language Name";
    String LANG_ID_NULL = "Language ID is null";
    //Elastic Search entity constraint violation.
    String ELST_SEARCH_DOWN = "Unable to connect ElasticSearch Server";
    //CurrencyTranslation entity constraint violation.
    String CURRTL_ID_AUTOGEN = "Translation ID should not be passed which is to be auto generated";
    String CURRTL_INVL = "ParentID or/and LanguageID invalid or existing.";
    String CURRTL_NOT_EXIST = "Currency Translation does not exist";
    String INVAL_TRANS_EN_NAME = "Invalid Entity Name";
	String CURRTL_ID_NULL = "Currency Translation ID is null";
    //Kafka constraint violation.
    String CURR_ENTITY = "Currency";
    String CURRTL_ENTITY = "Currency Translation";
    String LANG_ENTITY = "Language";
    String CREATED = "CREATED";
    String UPDATED = "UPDATED";
    String DELETED = "DELETED";
    String DEACTIVATED = "DEACTIVATED";
}
