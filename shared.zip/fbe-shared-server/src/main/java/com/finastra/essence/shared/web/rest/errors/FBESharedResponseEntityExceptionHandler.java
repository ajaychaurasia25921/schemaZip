package com.finastra.essence.shared.web.rest.errors;

import com.finastra.essence.common.exception.CustomResponseEntityExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * This class handles all the exceptions in FBE-Shared Microservice application
 * Created by bnandima on 3/13/2019.
 */
@RestControllerAdvice
public class FBESharedResponseEntityExceptionHandler extends CustomResponseEntityExceptionHandler{
}
