/**
 * Spring Security configuration.
 */
package com.finastra.essence.shared.security;
