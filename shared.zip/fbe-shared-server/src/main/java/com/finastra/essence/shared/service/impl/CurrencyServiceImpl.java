/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.shared.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.finastra.essence.common.domain.Elastic;
import com.finastra.essence.common.domain.KafkaMessage;
import com.finastra.essence.common.exception.ErrorDetails;
import com.finastra.essence.common.exception.UserDefinedException;
import com.finastra.essence.common.util.ElasticSearchRestClient;
import com.finastra.essence.shared.common.KafkaHandler;
import com.finastra.essence.shared.common.FBESharedServicesConstants;
import com.finastra.essence.shared.domain.CurrencyHistory;
import com.finastra.essence.shared.domain.CurrencyTranslation;
import com.finastra.essence.shared.service.CurrencyHistoryService;
import com.finastra.essence.shared.service.CurrencyService;
import com.finastra.essence.shared.domain.Currency;
import com.finastra.essence.shared.repository.CurrencyRepository;
import com.finastra.essence.shared.service.CurrencyTranslationService;
import com.finastra.essence.shared.service.dto.CurrencyDTO;
import com.finastra.essence.shared.service.dto.CurrencyTranslationDTO;
import com.finastra.essence.shared.service.mapper.CurrencyMapper;
import com.finastra.essence.shared.service.mapper.CurrencyTranslationMapper;
import com.hazelcast.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.KafkaException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.ResourceAccessException;
import java.lang.reflect.Method;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Service Implementation for managing Currency.
 */
@Service
@Transactional
@RefreshScope
public class CurrencyServiceImpl implements CurrencyService {

    @Value("${elasticSearchServiceUrl}")
    private String elasticSearchServiceUrl;

    @Value("${broker}")
    private String broker;

    @Value("${currencyTopic}")
    private String currencyTopic;

    @Value("${docUrl}")
    private String docUrl;

    @Value("${searchServiceUrl}")
    private String searchServiceUrl;

    @Autowired
    private CurrencyHistoryService currencyHistoryService;

    @Autowired
    private CurrencyTranslationService currencyTranslationService;

    private final ErrorDetails errorDetails = new ErrorDetails();

    private final String entityName = "fes_currency";
    
    private String searchParameters = "currencyCode,currencyIsoCode,currencyNumericCode,activeFlag_B";

    private final Logger log = LoggerFactory.getLogger(CurrencyServiceImpl.class);

    private final CurrencyRepository currencyRepository;

    private LocalDateTime date = LocalDateTime.now();

    private final CurrencyMapper currencyMapper;

    private final CurrencyTranslationMapper currencyTranslationMapper;

    /**
     * Class constructor initializes currencyRepository and currencyMapper objects.
     * @param currencyRepository the object of CurrencyRepository to be initialized.
     * @param currencyMapper the object of CurrencyMapper to be initialized.
     */
    public CurrencyServiceImpl(CurrencyRepository currencyRepository, CurrencyMapper currencyMapper,CurrencyTranslationMapper currencyTranslationMapper ) {
        this.currencyRepository = currencyRepository;
        this.currencyMapper = currencyMapper;
        this.currencyTranslationMapper = currencyTranslationMapper;
    }

    /**
     * Stores the currency entity after validating attributes of currency.
     * The currencyDTO argument should be given during post operations.
     * If the none of the currency's attribute violates the constraints then
     * the currency gets stored, otherwise relative message
     * of violation should be displayed.
     *
     * @param currencyDTO the currency entity to be stored.
     * @return the persisted currency entity.
     */
    @Override
    public CurrencyDTO save(CurrencyDTO currencyDTO) {
        log.debug("Request to save Currency : {}", currencyDTO);
        validatePostCurrency(currencyDTO);
        Currency currency = null;
        try {
            currency = currencyMapper.toEntity(currencyDTO);
            currency = currencyRepository.saveAndFlush(currency);
            currencyHistoryService.save(new CurrencyHistory().copyObject(currency));
        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(FBESharedServicesConstants.CURR_EXIST);
            throw new UserDefinedException(errorDetails);
        }

       KafkaHandler.produce(new KafkaMessage().createMessage(FBESharedServicesConstants.CURR_ENTITY, currency.getCurrencyId(),FBESharedServicesConstants.CREATED,String.valueOf(currency)), broker, currencyTopic);

        ElasticSearchRestClient.post(currency, currency.getCurrencyId(), elasticSearchServiceUrl + entityName + docUrl);

        return currencyMapper.toDto(currency);
    }

    /**
     * Amends the currency entity after validating attributes of currency.
     * The currencyDTO argument should be given during put operations.
     * If the none of the currency's attribute violates the constraints then
     * the respective currency gets updated, otherwise relative message
     * of violation should be displayed.
     *
     * @param currencyDTO the currency entity to be amended.
     * @return the persisted currency entity.
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @Override
    public CurrencyDTO update(CurrencyDTO currencyDTO) throws URISyntaxException {
        log.debug("Request to update Currency : {}", currencyDTO);
        validatePutCurrency(currencyDTO);
        try {
            Currency currency = null;
            Optional<Currency> currencyExist = currencyRepository.findById(currencyDTO.getCurrencyId());
            if (!currencyExist.isPresent()) {
                throw new DataIntegrityViolationException(FBESharedServicesConstants.CURR_NOT_EXIST);
            } else {  
              Currency currencyToUpdate = currencyMapper.toEntity(currencyDTO);
            	 if (!currencyToUpdate.equals(currencyExist.get())) {
                        currency = new Currency().setUpdate(currencyDTO,currencyExist.get());
                        currencyHistoryService.save(new CurrencyHistory().copyObject(currency));
                       KafkaHandler.produce(new KafkaMessage().createMessage(FBESharedServicesConstants.CURR_ENTITY,currency.getCurrencyId(),FBESharedServicesConstants.UPDATED,String.valueOf(currency)), broker, currencyTopic);
                        	ElasticSearchRestClient.put(currency, currency.getCurrencyId(),elasticSearchServiceUrl + entityName + docUrl);
                } else {
                    throw new DataIntegrityViolationException(FBESharedServicesConstants.EN_NO_CHNG_FOUND);
                }

                return currencyMapper.toDto(currency);
            }
        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * Validates all the attributes of currency before storing into
     * database and elasticsearch.
     *
     * @param currencyDTO the currency entity to be validated.
     */
    public void validatePostCurrency(CurrencyDTO currencyDTO) {
        validateCurrencyId(currencyDTO);
        currencyDTO.setCurrencyCode(currencyDTO.getCurrencyCode().trim().toUpperCase());
        currencyDTO.setCurrencyIsoCode(currencyDTO.getCurrencyIsoCode().trim().toUpperCase());
        formatCurrencyNumericCode(currencyDTO);
        setPostActiveDate(currencyDTO);
    }
    /**
     * Validates all the attributes of currency before amending into
     * database and elasticsearch.
     *
     * @param currencyDTO the currency entity to be validated.
     */
    public void validatePutCurrency(CurrencyDTO currencyDTO) {
        validatePutCurrencyId(currencyDTO);
        currencyDTO.setCurrencyCode(currencyDTO.getCurrencyCode().trim().toUpperCase());
        currencyDTO.setCurrencyIsoCode(currencyDTO.getCurrencyIsoCode().trim().toUpperCase());
        formatCurrencyNumericCode(currencyDTO);
        setPutActiveDate(currencyDTO);
    }

    /**
     * Retrieves all the currencies from currency database.
     *
     * @param pageable the pagination information
     * @return the list of currencies
     */
    @Override
    @Transactional(readOnly = true)
    public Page<CurrencyDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Currencies");
        return currencyRepository.findAll(pageable)
                .map(currencyMapper::toDto);
    }


    /**
     * Retrieves the currency whose currencyId is specified
     * in argument, from currency database.
     *
     * @param currencyId the currencyId of the currency entity to be retrieved.
     * @return the currency entity of specified currencyId.
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<CurrencyDTO> findOne(String currencyId) {
        log.debug("Request to get Currency : {}", currencyId);
        return currencyRepository.findById(currencyId)
                .map(currencyMapper::toDto);
    }

    /**
     * Inactive the currency whose currencyId is specified
     * in argument.
     *
     * @param currencyId the currencyId of the currency
     *        entity to be deleted.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @Override
    public void delete(String currencyId) throws URISyntaxException {
        log.debug("Request to delete Currency : {}", currencyId);
        Optional<Currency> currency = currencyRepository.findById(currencyId);
        currency.get().setActiveFlag(false);
        currency.get().setActiveTill(date);
        currencyHistoryService.save(new CurrencyHistory().copyObject(currency.get()));
        KafkaHandler.produce(new KafkaMessage().createMessage(FBESharedServicesConstants.CURR_ENTITY,currencyId,FBESharedServicesConstants.DEACTIVATED,String.valueOf(currency.get())), broker, currencyTopic);
        ElasticSearchRestClient.put(currency.get(), currencyId, elasticSearchServiceUrl + entityName + docUrl);
    }
    /**
     * Retrieves the currency whose currencyIsoCode is specified
     * in argument, from currency database.
     *
     * @param currencyIsoCode the currencyIsoCode of the currency entity to be retrieved.
     * @return the currency entity of specified currencyIsoCode.
     */
    @Override
    public Optional<CurrencyDTO> findCode(String currencyIsoCode) {
        log.debug("Request to get Currency : {}", currencyIsoCode);
        return currencyRepository.findCode(currencyIsoCode).map(currencyMapper::toDto);
    }

    /**
     * Validates the "currencyId" of currency entity
     *  during post operations.
     * @param currency the currency entity
     *        whose currencyId to be validated.
     */
    private void validateCurrencyId(CurrencyDTO currency) {
        if (currency.getCurrencyId() != null && !currency.getCurrencyId().trim().equals("")) {
            errorDetails.setDetail(FBESharedServicesConstants.CURR_ID_AUTOGEN);
            throw new UserDefinedException(errorDetails);
        }
    }
    /**
     * Validates the "currencyId" of currency entity
     * during put operations.
     * @param currency the currency entity
     *        whose currencyId to be validated.
     */
    private void validatePutCurrencyId(CurrencyDTO currency) {

        if (currency.getCurrencyId() == null) {
            errorDetails.setDetail(FBESharedServicesConstants.CURR_ID_NULL);
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * Formats the "currencyNumericCode" of currency entity
     * during both post and put operations.
     * @param currency the currency entity
     *         whose currencyNumericCode to be formatted.
     */
    private void formatCurrencyNumericCode(CurrencyDTO currency) {
               switch(currency.getCurrencyNumericCode().length()) {
               case 1: currency.setCurrencyNumericCode("00"+currency.getCurrencyNumericCode());
                    break;
               case 2: currency.setCurrencyNumericCode("0"+currency.getCurrencyNumericCode());
                    break;
               default: currency.setCurrencyNumericCode(currency.getCurrencyNumericCode());
               }
     }

    /**
     * The activeTill and activeFrom are getting set based on
     * the value of activeFlag of currency during put operation.
     * @param currency the currency entity whose
     *        activeTill stores the date till when the entity is set to be active,
     *        and activeFrom stores the date when the entity is set to be active.
     */
    private void setPutActiveDate(CurrencyDTO currency) {
        if (!currency.isActiveFlag()) {
            currency.setActiveTill(date);
            log.debug("EffectiveTo field contains " + currency.getActiveTill()); }
        else {
            setTrueActiveFlagDate(currency);
        }
    }

    /**
     * The activeTill and activeFrom are getting set based on
     * the value of activeFlag of currency during post operation.
     * @param currency the currency entity whose
     *        activeTill stores the date till when the entity is set to be active,
     *        and activeFrom stores the date when the entity is set to be active.
     */
    private void setPostActiveDate(CurrencyDTO currency){
        if (!currency.isActiveFlag()) {
            LocalDateTime previousDate = date.minusDays(1);
            currency.setActiveFrom(previousDate);
            log.debug("effectiveFrom field is " + currency.getActiveFrom());
            currency.setActiveTill(previousDate);
            log.debug("effectiveTo field is " + currency.getActiveTill());
        } else {
            setTrueActiveFlagDate(currency);
        }
    }
    /**
     * The activeTill and activeFrom are getting set when
     * the value of activeFlag of currency is true.
     * @param currency the currency entity whose
     *        activeTill stores the date till when the entity is set to be active,
     *        and activeFrom stores the date when the entity is set to be active.
     */
    private void setTrueActiveFlagDate(CurrencyDTO currency) {
        log.debug("effectiveFrom field is "  + date);
        currency.setActiveFrom(date);
        LocalDateTime dateTrue = date.plusYears(50);
        log.debug("effectiveTo field is " + dateTrue);
        currency.setActiveTill(dateTrue);
    }

    /**
     * Synchronizing currency entities between
     * the currency database and  elasticsearch.
     *
     * @return the list of currencies.
     */
    @Override
    public void syncData() {
    	 ResponseEntity<Elastic> responseEntity=null;
        try {
            List<Currency> getAllCurrency = currencyRepository.findAll();
            for (Currency currency: getAllCurrency) {

            	responseEntity = ElasticSearchRestClient.post(currency, currency.getCurrencyId(),elasticSearchServiceUrl + entityName + docUrl );
            }
            if (!(responseEntity.getStatusCode().toString().equalsIgnoreCase("200")) && !(responseEntity.getStatusCode().toString().equalsIgnoreCase("201"))) {
                throw new Exception(FBESharedServicesConstants.ELST_SEARCH_DOWN);
            }
        } catch(Exception e) {
            errorDetails.setDetail(FBESharedServicesConstants.ELST_SEARCH_DOWN);
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * Retrieves all the currencies from elasticsearch.
     *
     * @param filter the string to be searched.
     * @return  the list of currencies.
     */
    @Override
    public ResponseEntity<List<CurrencyDTO>>findCurrencyByFilter(CurrencyDTO filter) {
		List<CurrencyDTO> currencyList = new ArrayList<CurrencyDTO>();
		ObjectMapper mapper = new ObjectMapper(); 
		try{
			String query = "{\"query\" : {\"bool\" : {\"must\" :";
			List<String> searchKeyword = new ArrayList<String>();
			List<String> searchParametersList = Arrays.asList(searchParameters.split(","));  
			for (String searchField : searchParametersList) {
				String getterMethod =String.valueOf(searchField.charAt(0)).toUpperCase() + searchField.substring(1);
				if(searchField.contains("_")) {
					searchField = searchField.split("_")[0];
					getterMethod = "is"+getterMethod.substring(0, getterMethod.indexOf("_"));
					Method searchMethod = filter.getClass().getMethod(getterMethod); 
					if(searchMethod.invoke(filter) != null) {
						searchKeyword.add("{\"match\":{\""+ searchField + "\" : "+ searchMethod.invoke(filter) + "}}");
					}
				}else {
					getterMethod = "get"+getterMethod;
					Method searchMethod = filter.getClass().getMethod(getterMethod); 
					if(searchMethod.invoke(filter) != null && !StringUtil.isNullOrEmpty(searchMethod.invoke(filter).toString())) {
						searchKeyword.add("{\"query_string\":{\"query\":\""+ searchField +  ":" + searchMethod.invoke(filter).toString() + "\"}}");
					}
				}
			}
			query = query + searchKeyword.toString() + "}}}";
			String responseEntity = ElasticSearchRestClient.get(elasticSearchServiceUrl + entityName + searchServiceUrl , query);
			JsonNode node = mapper.readTree(responseEntity);
			JsonNode hitsnode = node.get("hits").get("hits");
			Iterator<JsonNode> childNodes = hitsnode.iterator();
			while (childNodes.hasNext()) {
				CurrencyDTO currency = new CurrencyDTO();
				JsonNode htNode = childNodes.next();
				JsonNode nodeCurrency = htNode.get("_source");
				currency.setCurrencyId(nodeCurrency.findPath("currencyId").asText());
				currency.setCurrencyCode(nodeCurrency.findPath("currencyCode").asText());
				currency.setCurrencyIsoCode(nodeCurrency.findPath("currencyIsoCode").asText());
				currency.setCurrencyNumericCode(nodeCurrency.findPath("currencyNumericCode").asText());
				currency.setSystemFlag(nodeCurrency.findPath("systemFlag").asBoolean());
				currency.setIconImageFile(nodeCurrency.findPath("iconImageFile").asText());
				currency.setActiveFlag(nodeCurrency.findPath("activeFlag").asBoolean());
				currency.setCreatedBy(nodeCurrency.findPath("createdBy").asText());
				currency.setLastModifiedBy(nodeCurrency.findPath("lastModifiedBy").asText());
				currency.setCurrencyAlternativeCode(nodeCurrency.findPath("currencyAlternativeCode").asText());
				JsonNode currencyTLNode = nodeCurrency.get("currencyTranslations");
				if(currencyTLNode!=null) {
					Set<CurrencyTranslationDTO> currencyTranslationList = new HashSet<>();
					Iterator<JsonNode> currencyChildNode = currencyTLNode.iterator();
					while(currencyChildNode.hasNext()) {
						JsonNode nodeCurrencyTranslation = currencyChildNode.next();
						CurrencyTranslationDTO currencyTranslation = new CurrencyTranslationDTO();
						currencyTranslation.setCreatedBy(nodeCurrencyTranslation.findPath("createdBy").asText());
						currencyTranslation.setEntityName(nodeCurrencyTranslation.findPath("entityName").asText());
						currencyTranslation.setEntityDesc(nodeCurrencyTranslation.findPath("entityDesc").asText());
						currencyTranslation.setTranslationId(nodeCurrencyTranslation.findPath("translationId").asText());
						//currencyTranslation.setParentId(nodeCurrencyTranslation.findPath("parentId").asText());
						currencyTranslation.setLanguageId(nodeCurrencyTranslation.findPath("languageId").asText());
						currencyTranslationList.add(currencyTranslation);
					}
					currency.setCurrencyTranslations(currencyTranslationList);
				}
				currencyList.add(currency);
			}
		}catch (ResourceAccessException e){
	            errorDetails.setDetail(FBESharedServicesConstants.ELST_SEARCH_DOWN);
	            throw new UserDefinedException(errorDetails);
	    } catch (Exception e) {
            errorDetails.setDetail(FBESharedServicesConstants.CURR_NOT_EXIST);
            throw new UserDefinedException(errorDetails);
        }
		return new ResponseEntity<List<CurrencyDTO>>(currencyList, HttpStatus.OK);
    }
}

