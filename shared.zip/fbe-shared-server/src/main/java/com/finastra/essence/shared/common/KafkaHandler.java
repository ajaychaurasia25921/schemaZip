/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */


package com.finastra.essence.shared.common;

import com.finastra.essence.common.configurations.KafkaConfigurationHandler;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Import;
import org.springframework.kafka.KafkaException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.concurrent.CompletableFuture;

/**
 * This class produces and listens the host messages for Kafka server.
 */
@Service
@Transactional
@Import({KafkaConfigurationHandler.class})
@RefreshScope
public class KafkaHandler {

    private final static Logger log = LoggerFactory.getLogger(KafkaHandler.class);

	/**
     * Consume messages from broker related to Language application.
     * @param message the message consumed from broker.
     */
    @KafkaListener(topics = "${languageTopic}", groupId = "${group_id}")
    public void consumerLanguage(String message) {
        log.debug("Consumed Language message: {} ", message);
    }

	/**
     * Consume messages from broker related to Currency application.
     * @param message the message consumed from broker.
     */
    @KafkaListener(topics = "${currencyTopic}", groupId = "${group_id}")
    public void consumerCurrency(String message) {
        log.debug("Consumed Currency message: {} ", message);
    }

	/**
     * Consume messages from broker related to Currency Translation application.
     * @param message the message consumed from broker.
     */
   @KafkaListener(topics = "${currencyTranslationTopic}", groupId = "${group_id}")
    public void consumerCurrencyTranslation(String message) {
        log.debug("Consumed CurrencyTranslation message: {} ", message);
    }

	 /**
     * Produces messages specific to one of the shared application and send it to broker.
     * @param message the messages specific to one of the shared application.
     * @param broker the broker which should recieve the message.
     * @param topic the specific shared application.
     * @throws KafkaException if the Kafka server is down.
     */
    public static void produce(String message, String broker, String topic) {
        CompletableFuture.runAsync(()->{
            try{
                KafkaProducer<String, String> producer = KafkaConfigurationHandler.kafkaProducerMessage(broker);
                ProducerRecord<String, String> data = new ProducerRecord<String, String>(topic, message);
                log.debug("Message before sending to kafka: {}", message, " Message Topic : {}", topic);
                producer.send(data);
                producer.close();
            }catch (KafkaException ke){
                log.error("Error occurred in producing message:"+message);
                log.error(ke.getMessage());
            }
        });

    }
}
