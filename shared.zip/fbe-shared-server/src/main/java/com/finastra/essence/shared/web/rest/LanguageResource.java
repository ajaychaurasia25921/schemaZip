/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.finastra.essence.shared.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.finastra.essence.shared.service.LanguageService;
import com.finastra.essence.shared.web.rest.util.HeaderUtil;
import com.finastra.essence.shared.web.rest.util.PaginationUtil;
import com.finastra.essence.shared.service.dto.LanguageDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Language.
 */
@RestController
@RequestMapping("/api")
public class LanguageResource {

    private final Logger log = LoggerFactory.getLogger(LanguageResource.class);

    private static final String ENTITY_NAME = "fbeSharedLanguage";

    private final LanguageService languageService;

    public LanguageResource(LanguageService languageService) {
        this.languageService = languageService;
    }

    /**
     * POST  /language : Create a new language.
     *
     * @param languageDTO the languageDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new languageDTO, or with status 400 (Bad Request) if the language has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/language")
    @Timed
    public ResponseEntity<LanguageDTO> createLanguage(@Valid @RequestBody LanguageDTO languageDTO) throws URISyntaxException {
        log.debug("REST request to save Language : {}", languageDTO);
        LanguageDTO result = languageService.save(languageDTO);
        return ResponseEntity.created(new URI("/api/languages/" + result.getLanguageId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getLanguageId()))
            .body(result);
    }

    /**
     * PUT  /language : Updates an existing language.
     *
     * @param languageDTO the languageDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated languageDTO,
     * or with status 400 (Bad Request) if the languageDTO is not valid,
     * or with status 500 (Internal Server Error) if the languageDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/language")
    @Timed
    public ResponseEntity<LanguageDTO> updateLanguage(@Valid @RequestBody LanguageDTO languageDTO) throws URISyntaxException {
        log.debug("REST request to update Language : {}", languageDTO);

        LanguageDTO result = languageService.update(languageDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, languageDTO.getLanguageId()))
            .body(result);
    }

    /**
     * GET  /language : get all the languages.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of languages in body
     */
    @GetMapping("/language")
    @Timed
    public ResponseEntity<List<LanguageDTO>> getAllLanguages(Pageable pageable) {
        log.debug("REST request to get a page of Languages");
        Page<LanguageDTO> page = languageService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/language");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }
    /**
     * GET /language/code/:languageCode : get the "languageCode" language.
     *
     * @param languageCode the id of the language to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the language,
     *         or with status 404 (Not Found)
     */
    @GetMapping("/language/code/{languageCode}")
    @Timed
    public ResponseEntity<LanguageDTO> getLanguageByCode(@PathVariable String languageCode) {
        log.debug("REST request to get Language : {}", languageCode);
        Optional<LanguageDTO> language = languageService.findCode(languageCode);
        return ResponseUtil.wrapOrNotFound(language);
    }

    /**
     * GET  /language/:id : get the "id" language.
     *
     * @param id the id of the languageDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the languageDTO, or with status 404 (Not Found)
     */
    @GetMapping("/language/{id}")
    @Timed
    public ResponseEntity<LanguageDTO> getLanguage(@PathVariable String id) {
        log.debug("REST request to get Language : {}", id);
        Optional<LanguageDTO> languageDTO = languageService.findOne(id);
        return ResponseUtil.wrapOrNotFound(languageDTO);
    }

    /**
     * Post /language/elastic/syncData : elastic search will sync with database when server is up.
     *
     * @return list of language entities to elastic search
     */
    @PostMapping("/language/elastic/syncData")
    @Timed
    public ResponseEntity<Void> LanguageSync() {
        log.debug("REST request to get Sync with Elastic Search : ");
        languageService.syncData();
        return ResponseEntity.ok().headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME,null)).build();
    }

    /**
     * Post /language/search : get all language entities from elastic search.
     *
     *  @return the ResponseEntity with status 200 (OK) and list of language entities in body
     */
    @PostMapping("/language/search")
    @Timed
    public ResponseEntity<List<LanguageDTO>>  LanguageSearch(@RequestBody LanguageDTO filter,String filterSource, Pageable pageable) {
        log.debug("REST request to get Search with Filter Search : {}");
        Page<LanguageDTO> page = languageService.findLanguagesByFilter(filter,filterSource,pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/language");
        return new ResponseEntity<List<LanguageDTO>>(page.getContent(),headers,HttpStatus.OK);
    }

    /**
     * DELETE  /languages/:id : delete the "languageId" language.
     *
     * @param id the id of the languageDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/language/{id}")
    @Timed
    public ResponseEntity<Void> deleteLanguage(@PathVariable String id) throws URISyntaxException {
        log.debug("REST request to delete Language : {}", id);
        languageService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
