/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.finastra.essence.shared.service;

import com.finastra.essence.shared.service.dto.CurrencyDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing Currency.
 */
public interface CurrencyService {

    /**
     * Stores the currency entity after validating attributes of currency.
     * The currencyDTO argument should be given during post operations.
     *
     * @param currencyDTO the currency entity to be stored.
     * @return the persisted currency entity.
     */
    CurrencyDTO save(CurrencyDTO currencyDTO);

    /**
     * Retrieves all the currencies from currency database.
     *
     * @param pageable the pagination information
     * @return the list of currencies
     */
    Page<CurrencyDTO> findAll(Pageable pageable);

    /**
     * Retrieves the currency whose currencyId is specified
     * in argument, from currency database.
     *
     * @param currencyId the currencyId of the currency entity to be retrieved.
     * @return the currency entity of specified currencyId.
     */
    Optional<CurrencyDTO> findOne(String currencyId);

    /**
     * Inactive the currency whose currencyId is specified
     * in argument.
     *
     * @param currencyId the currencyId of the currency
     *        entity to be deleted.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    void delete(String currencyId) throws URISyntaxException;
    /**
     * Retrieves the currency whose currencyIsoCode is specified
     * in argument, from currency database.
     *
     * @param currencyIsoCode the currencyIsoCode of the currency entity to be retrieved.
     * @return the currency entity of specified currencyIsoCode.
     */
    Optional<CurrencyDTO> findCode(String currencyIsoCode);
    /**
     * Amends the currency entity after validating attributes of currency.
     * The currencyDTO argument should be given during put operations.
     *
     * @param currency the currency entity to be amended.
     * @return the persisted currency entity.
     * @throws URISyntaxException if if the Location URI syntax is incorrect.
     */
    CurrencyDTO update(CurrencyDTO currency) throws URISyntaxException;
    /**
     * Synchronizing currency entities between
     * the currency database and  elasticsearch.
     *
     * @return the list of currencies.
     */
    void syncData();

    /**
     * Retrieves all the currencies from elasticsearch.
     * @param filter the string to be searched.
     * @return  the list of currencies.
     */
    ResponseEntity<List<CurrencyDTO>> findCurrencyByFilter(CurrencyDTO filter);
}
