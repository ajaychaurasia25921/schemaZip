/**
 * Spring Data JPA repositories.
 */
package com.finastra.essence.shared.repository;
