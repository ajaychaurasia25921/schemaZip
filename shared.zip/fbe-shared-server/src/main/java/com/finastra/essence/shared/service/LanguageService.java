/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.finastra.essence.shared.service;

import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import com.finastra.essence.shared.service.dto.LanguageDTO;
/**
 * Service Interface for managing Language.
 */
public interface LanguageService {

    /**
     * Stores the language entity after validating attributes of language.
     * The languageDTO argument should be given during post operations.
     * If the none of the language's attribute violates the constraints then
     * the language gets stored, otherwise relative message
     * of violation should be displayed.
     *
     * @param languageDTO the language entity to save
     * @return the persisted language entity.
     */
    LanguageDTO save(LanguageDTO languageDTO);

    /**
     * Retrieves all the languages from language database.
     *
     * @param pageable the pagination information
     * @return the list of languages
     */
    Page<LanguageDTO> findAll(Pageable pageable);


    /**
     * Retrieves the language whose languageId is specified
     * in argument, from language database.
     *
     * @param languageId the id of the language entity to be retrieved.
     * @return the language entity of specified languageId.
     */
    Optional<LanguageDTO> findOne(String languageId);

    /**
     * Amends the language entity after validating attributes of language.
     * The languageDTO argument should be given during put operations.
     * If the none of the currency's attribute violates the constraints then
     * the respective language gets updated, otherwise relative message
     * of violation should be displayed.
     *
     * @param languageDTO the language entity to update.
     * @return the persisted language entity.
     */
    LanguageDTO update(LanguageDTO languageDTO) throws URISyntaxException;

    /**
     * Inactive the language whose languageId is specified
     * in argument, from currency database.
     *
     * @param languageId the languageId of the language
     *        entity to be deleted.
     *
     */
    void delete(String languageId) throws URISyntaxException;

    /**
     * Retrieves the language whose languageCode is specified
     * in argument, from language database.
     *
     * @param languageCode the languageCode of the language entity to be retrieved.
     * @return the language entity of specified languageCode.
     */
    Optional<LanguageDTO> findCode(String languageCode);

    /**
     * Synchronizing language entities between
     * the language database and  elasticsearch.
     */
    void syncData();
    /**
     * Retrieves all the languages from elasticsearch.
     * @param filter the string to be searched.
     * @return  the list of languages.
     */
    Page<LanguageDTO> findLanguagesByFilter(LanguageDTO filter,String filterSource,Pageable page);
    
}
