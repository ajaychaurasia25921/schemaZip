/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */


package com.finastra.essence.shared.service.impl;

import com.finastra.essence.shared.common.ISearchFactory;
import com.finastra.essence.shared.domain.Language;
import com.finastra.essence.shared.domain.Language_;
import com.finastra.essence.shared.repository.LanguageRepository;
import com.finastra.essence.shared.service.dto.LanguageCriteria;
import com.finastra.essence.shared.service.dto.LanguageDTO;
import com.finastra.essence.shared.service.mapper.LanguageMapper;
import io.github.jhipster.service.QueryService;

import java.util.List;

import io.github.jhipster.service.filter.BooleanFilter;
import org.slf4j.Logger;
import io.github.jhipster.service.filter.StringFilter;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Pageable;


@Service
@Transactional
public class LanguageCriteriaSearchFilterImpl extends QueryService<Language> implements ISearchFactory {

    private final Logger log = LoggerFactory.getLogger(LanguageCriteriaSearchFilterImpl.class);

    @Override
    @Transactional(readOnly = true)
    public Page<LanguageDTO> search(LanguageDTO filter, Pageable page, LanguageRepository languageRepository,LanguageMapper languageMapper) {
            log.info("Enter in the Language Criteria Search Filter Implementation");
            LanguageCriteria languageCriteria = new LanguageCriteria();
            languageCriteria.setActiveFlag((BooleanFilter) new BooleanFilter().setEquals(filter.isActiveFlag()));
            languageCriteria.setLanguageName(new StringFilter().setContains(filter.getLanguageName()));
            languageCriteria.setLanguageCode(new StringFilter().setContains(filter.getLanguageCode()));
			languageCriteria.setLanguageIsoCode(new StringFilter().setContains(filter.getLanguageIsoCode()));
            Specification<Language> specification = createSpecification(languageCriteria);
            Page<LanguageDTO> spec = languageRepository.findAll(specification,page).map(languageMapper::toDto);
        return spec;
    }

    /**
     * Function to convert LanguageCriteria to a {@link Specification}
     */
    private Specification<Language> createSpecification(LanguageCriteria criteria) {
        Specification<Language> specification = Specification.where(null);
        if (criteria != null) {
            if(criteria.isActiveFlag() != null) {
                specification = specification.and(buildSpecification(criteria.isActiveFlag(), Language_.activeFlag));
            }
            if (criteria.getLanguageCode() != null) {
                specification = specification.and(buildStringSpecification(criteria.getLanguageCode(), Language_.languageCode));
            }
            if (criteria.getLanguageIsoCode() != null) {
                specification = specification.and(buildStringSpecification(criteria.getLanguageIsoCode(), Language_.languageIsoCode));
            }
            if (criteria.getLanguageName() != null) {
                specification = specification.and(buildStringSpecification(criteria.getLanguageName(), Language_.languageName));
            }
        }
        return specification;
    }
}
