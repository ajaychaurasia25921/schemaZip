/**
 * Spring Framework configuration files.
 */
package com.finastra.essence.shared.config;
