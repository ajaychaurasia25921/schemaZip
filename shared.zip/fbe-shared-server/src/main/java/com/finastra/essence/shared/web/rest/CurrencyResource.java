/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.finastra.essence.shared.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.finastra.essence.shared.service.CurrencyService;
import com.finastra.essence.shared.service.CurrencyTranslationService;
import com.finastra.essence.shared.web.rest.util.HeaderUtil;
import com.finastra.essence.shared.web.rest.util.PaginationUtil;
import com.finastra.essence.shared.service.dto.CurrencyDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Currency.
 */
@RestController
@RequestMapping("/api")
public class CurrencyResource {

    @Autowired
    private CurrencyTranslationService currencyTranslationService;

    private final Logger log = LoggerFactory.getLogger(CurrencyResource.class);

    private static final String ENTITY_NAME = "fbeSharedCurrency";

    private static final String ENTITY_TL_NAME = "fbeSharedCurrencyTranslation";

    private final CurrencyService currencyService;

    public CurrencyResource(CurrencyService currencyService) {
        this.currencyService = currencyService;
    }

    /**
     * POST  /currency : Create a new currency.
     *
     * @param currencyDTO the currencyDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new currencyDTO, or with status 400 (Bad Request) if the currency has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/currency")
    @Timed
    public ResponseEntity<CurrencyDTO> createCurrency(@Valid @RequestBody CurrencyDTO currencyDTO) throws URISyntaxException {
        log.debug("REST request to save Currency : {}", currencyDTO);
        CurrencyDTO result = currencyService.save(currencyDTO);
        return ResponseEntity.created(new URI("/api/currency/" + result.getCurrencyId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getCurrencyId().toString()))
            .body(result);
    }

    /**
     * PUT  /currency : Updates an existing currency.
     *
     * @param currencyDTO the currencyDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated currencyDTO,
     * or with status 400 (Bad Request) if the currencyDTO is not valid,
     * or with status 500 (Internal Server Error) if the currencyDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/currency")
    @Timed
    public ResponseEntity<CurrencyDTO> updateCurrency(@Valid @RequestBody CurrencyDTO currencyDTO) throws URISyntaxException {
        log.debug("REST request to update Currency : {}", currencyDTO);
        CurrencyDTO result = currencyService.update(currencyDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, currencyDTO.getCurrencyId().toString()))
            .body(result);
    }

    /**
     * GET  /currency : get all the currencies.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of currencies in body
     */
    @GetMapping("/currency")
    @Timed
    public ResponseEntity<List<CurrencyDTO>> getAllCurrencies(Pageable pageable) {
        log.debug("REST request to get a page of Currencies");
        Page<CurrencyDTO> page = currencyService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/currency");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

    /**
     * GET  /currency/:id : get the "id" currency.
     *
     * @param id the id of the currencyDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the currencyDTO, or with status 404 (Not Found)
     */
    @GetMapping("/currency/{id}")
    @Timed
    public ResponseEntity<CurrencyDTO> getCurrency(@PathVariable String id) {
        log.debug("REST request to get Currency : {}", id);
        Optional<CurrencyDTO> currencyDTO = currencyService.findOne(id);
        return ResponseUtil.wrapOrNotFound(currencyDTO);
    }
    @GetMapping("/currency/code/{currencyIsoCode}")
    @Timed
    public ResponseEntity<CurrencyDTO> getCurrencyWithCode(@PathVariable String currencyIsoCode) {
        log.debug("REST request to get Currency : {}", currencyIsoCode);
        Optional<CurrencyDTO> currency = currencyService.findCode(currencyIsoCode);
        return ResponseUtil.wrapOrNotFound(currency);
    }
    /**
     * DELETE  /currency/:id : delete the "id" currency.
     *
     * @param id the id of the currencyDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/currency/{id}")
    @Timed
    public ResponseEntity<Void> deleteCurrency(@PathVariable String id) throws URISyntaxException {
        log.debug("REST request to delete Currency : {}", id);
        currencyService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }

    /**
     * DELETE  /currency/currencyTranslations/:id : delete the "id" currencyTranslations.
     *
     * @param id the id of the currencyTlDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/currency/currencyTranslations/{id}")
    @Timed
    public ResponseEntity<Void> deleteCurrencyTranslation(@PathVariable String id) throws URISyntaxException {
        log.debug("REST request to delete CurrencyTranslation : {}", id);
        currencyTranslationService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_TL_NAME, id.toString())).build();
    }

    /**
     * Post /currency/elastic/syncData : elastic search will sync with database when server is up.
     *
     * @return list of currency entities to elastic search
     */
    @PostMapping("/currency/elastic/syncData")
    @Timed
    public ResponseEntity<Void> currencySync() {
        log.debug("REST request to get Sink with Elastic Search : ");
        currencyService.syncData();
        return ResponseEntity.ok().headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME,null)).build();
    }

    /**
     * Post /currency/search : get all currency entities from elastic search.
     * @param filter the string to be searched. 
     * @return the ResponseEntity with status 200 (OK) and list of currency entities in body
     */
    @PostMapping("/currency/search")
    @Timed
    public ResponseEntity<List<CurrencyDTO>> currencySearch(@RequestBody CurrencyDTO filter) {
        log.debug("REST request to get Search with Elastic Search : ");
        return currencyService.findCurrencyByFilter(filter);
    }
}
