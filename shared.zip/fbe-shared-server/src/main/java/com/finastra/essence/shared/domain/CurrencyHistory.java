/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.shared.domain;

import com.finastra.essence.common.domain.AbstractEffectiveEntity;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * CurrencyHistory is a class extends {@link AbstractEffectiveEntity} and hold
 * definitions for history_id, currency_id, currency_code, currency_iso_code,
 * currency_numeric_code, currency_alternative_code and icon_image_file.
 *
 * @since 1.0
 */

@Entity
@Table(name = "FES_CURRENCY_HISTORY")
public class CurrencyHistory extends AbstractEffectiveEntity implements Serializable {
	/**
	 * Serialization version identifier
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Attribute holding the value of unique identifier assigned to a currency
	 * history, which is auto-generated.
	 */
	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Size(max = 36)
	@Column(name = "history_id", length = 36)
	private String historyId;
	/**
	 * Attribute referring the unique identifier assigned to a currency.
	 */
	@NotNull
	@Size(max = 36)
	@Column(name = "currency_id", length = 36, nullable = false)
	private String currencyId;
	/**
	 * Attribute holding the value of unique code assigned to the referred currency.
	 */
	@NotNull
	@Column(name = "currency_code", nullable = false)
	private String currencyCode;
	/**
	 * Attribute holding the value of ISO code (3 letters) associated with the
	 * referred currency.
	 */
	@NotNull
	@Column(name = "currency_iso_code", nullable = false)
	private String currencyIsoCode;
	/**
	 * Attribute holding the image filename associated with the referred currency.
	 */
	@Size(max = 240)
	@Column(name = "icon_image_file", length = 240)
	private String iconImageFile;
	/**
	 * Attribute holding the value of three-digit unique code number assigned to the
	 * referred currency.
	 */
	@NotNull
	@Column(name = "currency_numeric_code", nullable = false)
	private String currencyNumericCode;
	/**
	 * Attribute holding the value of alternative code assigned to the referred
	 * currency.
	 */
	@NotNull
	@Size(max = 10)
	@Column(name = "currency_alternative_code", length = 10)
	private String currencyAlternativeCode;

	// jhipster-needle-entity-add-field -
	// JHipster will add fields here, do not remove



	/**
	 * Attribute holding version number of the currency.
	 */
	private Long versionNumber;

	/**
	 * This is a setter which sets version number assigned to the currency.
	 * @param versionNumber the string value holding version number assigned to a currency.
	 */
	public void setVersionNumber(Long versionNumber) {
		this.versionNumber = versionNumber;
	}

	/**
	 * This is a getter which gets version number assigned to the currency.
	 * @return the string value holding version number assigned to a currency.
	 */
	public Long getVersionNumber() {
		return versionNumber;
	}
	
	public CurrencyHistory versionNumber(long versionNumber) {
		this.versionNumber = versionNumber;
		return this;
	}

	/**
	 * This is a getter which gets unique identifier to the Currency History.
	 * @return historyId the string value holding unique identifier assigned to a currency History.
	 */
	public String getHistoryId() {
		return historyId;
	}

	public CurrencyHistory historyId(String historyId) {
		this.historyId = historyId;
		return this;
	}

	/**
	 * This is a setter which sets unique identifier to the Currency History.
	 * @param historyId the unique identifier assigned to a currency History.
	 */
	public void setHistoryId(String historyId) {
		this.historyId = historyId;
	}

	/**
	 * This is a getter which gets unique identifier of the referred currency.
	 * @return currencyId the string value holding unique identifier assigned to a referred currency.
	 */
	public String getCurrencyId() {
		return currencyId;
	}

	public CurrencyHistory currencyId(String currencyId) {
		this.currencyId = currencyId;
		return this;
	}

	/**
	 * This is a setter which gets unique identifier of the referred currency.
	 * @param  currencyId the unique identifier assigned to a referred currency.
	 */
	public void setCurrencyId(String currencyId) {
		this.currencyId = currencyId;
	}

	/**
	 * This is a getter which gets unique code of the referred currency.
	 * @return currencyCode the string value holding the unique code assigned to a referred currency.
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	public CurrencyHistory currencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
		return this;
	}

	/**
	 * This is a setter which sets unique code of the referred currency.
	 * @param currencyCode the unique code assigned to a referred currency.
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * This is a getter which gets ISO code of the referred currency.
	 * @return currencyIsoCode the string value holding the ISO code assigned to a referred currency.
	 */
	public String getCurrencyIsoCode() {
		return currencyIsoCode;
	}

	public CurrencyHistory currencyIsoCode(String currencyIsoCode) {
		this.currencyIsoCode = currencyIsoCode;
		return this;
	}

	/**
	 * This is a setter which sets ISO code of the referred currency.
	 * @param currencyIsoCode the ISO code (3 letters) assigned to a referred currency.
	 */
	public void setCurrencyIsoCode(String currencyIsoCode) {
		this.currencyIsoCode = currencyIsoCode;
	}

	/**
	 * This is a getter which gets the image filename of the referred currency.
	 * @return the string value holding the image filename assigned to a referred currency.
	 */
	public String getIconImageFile() {
		return iconImageFile;
	}

	public CurrencyHistory iconImageFile(String iconImageFile) {
		this.iconImageFile = iconImageFile;
		return this;
	}

	/**
	 * This is a setter which sets the image filename of the referred currency.
	 * @param iconImageFile the image filename assigned to a referred currency.
	 */
	public void setIconImageFile(String iconImageFile) {
		this.iconImageFile = iconImageFile;
	}

	/**
	 * This is a getter which gets three-digit Numeric code number of the referred currency.
	 * @return the string value holding the three-digit unique Numeric code number assigned
	 *         to a referred currency.
	 */
	public String getCurrencyNumericCode() {
		return currencyNumericCode;
	}

	public CurrencyHistory currencyNumericCode(String currencyNumericCode) {
		this.currencyNumericCode = currencyNumericCode;
		return this;
	}

	/**
	 * This is a setter which sets three-digit Numeric code  of the referred currency.
	 * @param currencyNumericCode the three-digit unique Numeric code assigned to a
	 * 	      referred currency as per ISO 3166-1 numeric codes.
	 */
	public void setCurrencyNumericCode(String currencyNumericCode) {
		this.currencyNumericCode = currencyNumericCode;
	}

	/**
	 * This is a getter which gets alternative code of the referred currency.
	 * @return the string value holding the alternative code assigned to a referred currency.
	 */
	public String getCurrencyAlternativeCode() {
		return currencyAlternativeCode;
	}

	public CurrencyHistory currencyAlternativeCode(String currencyAlternativeCode) {
		this.currencyAlternativeCode = currencyAlternativeCode;
		return this;
	}

	/**
	 * This is a setter which sets alternative code of the referred currency.
	 * @param currencyAlternativeCode the alternative code assigned to a referred currency.
	 */
	public void setCurrencyAlternativeCode(String currencyAlternativeCode) {
		this.currencyAlternativeCode = currencyAlternativeCode;
	}

	// jhipster-needle-entity-add-getters-setters
	// JHipster will add getters and setters here, do not remove

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		CurrencyHistory currencyHistory = (CurrencyHistory) o;
		if (currencyHistory.getHistoryId() == null || getHistoryId() == null) {
			return false;
		}
		return Objects.equals(getHistoryId(), currencyHistory.getHistoryId());
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getHistoryId());
	}

	@Override
	public String toString() {
		return "CurrencyHistory{" + ", historyId='" + getHistoryId() + "'" + ", currencyId='" + getCurrencyId() + "'"
				+ ", currencyCode='" + getCurrencyCode() + "'" + ", currencyIsoCode='" + getCurrencyIsoCode() + "'"
				+ ", iconImageFile='" + getIconImageFile() + "'" + ", currencyNumericCode=" + getCurrencyNumericCode()
				+ ", currencyAlternativeCode='" + getCurrencyAlternativeCode() + "'" + "}";
	}

	public CurrencyHistory copyObject(Currency object) {
		CurrencyHistory currencyHistory = new CurrencyHistory();
		currencyHistory.setCurrencyId(object.getCurrencyId());
		currencyHistory.setCurrencyCode(object.getCurrencyCode());
		currencyHistory.setCurrencyIsoCode(object.getCurrencyIsoCode());
		currencyHistory.setCurrencyNumericCode(object.getCurrencyNumericCode());
		currencyHistory.setCurrencyAlternativeCode(object.getCurrencyAlternativeCode());
		currencyHistory.setIconImageFile(object.getIconImageFile());
		currencyHistory.setVersionNumber(object.getVersionNumber());
		currencyHistory.setSystemFlag(object.isSystemFlag());
		currencyHistory.setActiveFlag(object.isActiveFlag());
		currencyHistory.setCreatedBy(object.getCreatedBy());
		currencyHistory.setCreatedOn(object.getCreatedOn());
		currencyHistory.setActiveFrom(object.getActiveFrom());
		currencyHistory.setActiveTill(object.getActiveTill());
		currencyHistory.setLastModifiedBy(object.getLastModifiedBy());
		currencyHistory.setLastModifiedOn(object.getLastModifiedOn());
		return currencyHistory;
	}
}
