/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.shared.domain;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.finastra.essence.common.domain.AbstractEntity;
import com.finastra.essence.shared.service.dto.CurrencyTranslationDTO;
import org.hibernate.annotations.GenericGenerator;

/**
 * CurrencyTranslation is a class extends {@link AbstractEntity} and hold
 * definitions for translation_id, parent_id, language_id, entity_name and
 * entity_desc. Many to One relationship association using a foreign key
 * mapping, with Currency and Language.
 *
 * @since 1.0
 */
@Entity
@Table(name = "FES_CURRENCY_TL", uniqueConstraints = @UniqueConstraint(name = "parent_and_language_ids", columnNames = {
		"parent_id", "language_id" }), indexes = {
		@Index(name = "FES_CURRENCY_TL_IX1", columnList = "parent_id", unique = false),
		@Index(name = "FES_CURRENCY_TL_IX2", columnList = "language_id", unique = false) })

public class CurrencyTranslation extends AbstractEntity implements Serializable {

	/**
	 * Serialization version identifier
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Attribute holding the value of unique identifier assigned to a currency
	 * translation, which is auto-generated.
	 */
	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Size(max = 36)
	@Column(name = "translation_id", length = 36, updatable = false)
	private String translationId;

	/**
	 * Attribute referring the unique code assigned to a language.
	 */
	@NotNull
	@Size(max = 36)
	@Column(name = "language_id", length = 36, nullable = false)
	private String languageId;

	/**
	 * Attribute holding the value of the name of the referred currency in a
	 * specific language.
	 */
	@NotNull
	@Column(name = "entity_name", length = 80, nullable = false)
	private String entityName;

	/**
	 * Attribute holding the brief description about the currency.
	 */
	@Size(max = 240)
	@Column(name = "entity_desc", length = 240)
	private String entityDesc;
	/**
	 * This is a getter which gets unique identifier assigned to the currencyTranslation.
	 * @return the string value holding unique identifier assigned to a currencyTranslation.
	 */
	public String getTranslationId() {
		return translationId;
	}

	public CurrencyTranslation translationId(String translationId) {
		this.translationId = translationId;
		return this;
	}

	/**
	 * This is a setter which sets unique identifier to the currencyTranslation.
	 * @param translationId the unique identifier assigned to a currencyTranslation.
	 */
	public void setTranslationId(String translationId) {
		this.translationId = translationId;
	}

	/**
	 * This is a getter which gets unique identifier of language assigned to Currency Translation.
	 * @return languageId the string value holding unique identifier of referred language.
	 */
	public String getLanguageId() {
		return languageId;
	}

	public CurrencyTranslation languageId(String languageId) {
		this.languageId = languageId;
		return this;
	}

	/**
	 * This is a setter which sets unique identifier of language assigned to Currency Translation.
	 * @param languageId the languageId of the referred language to be set.
	 */
	public void setLanguageId(String languageId) {
		this.languageId = languageId;
	}

	/**
	 * This is a getter which gets the name of the currency in a specific language.
	 * @return entityName the name of the referred currency in a specific language.
	 */
	public String getEntityName() {
		return entityName;
	}

	public CurrencyTranslation entityName(String entityName) {
		this.entityName = entityName;
		return this;
	}

	/**
	 * This is a setter which sets the name of the currency in a specific language.
	 * @param entityName the name of the referred currency in a specific language.
	 */
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	/**
	 * This is a getter which gets the brief description about the currency.
	 * @return entityDesc the brief description about the currency.
	 */
	public String getEntityDesc() {
		return entityDesc;
	}

	public CurrencyTranslation entityDesc(String entityDesc) {
		this.entityDesc = entityDesc;
		return this;
	}

	/**
	 * This is a setter which sets the brief description about the currency.
	 * @param entityDesc the brief description about the currency.
	 */
	public void setEntityDesc(String entityDesc) {
		this.entityDesc = entityDesc;
	}

	// jhipster-needle-entity-add-getters-setters -
	// JHipster will add getters and setters here, do not remove

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		CurrencyTranslation that = (CurrencyTranslation) o;
		return Objects.equals(translationId, that.translationId)
				&& Objects.equals(languageId, that.languageId)
				&& Objects.equals(entityName, that.entityName)
				&& Objects.equals(entityDesc, that.entityDesc);

	}

	@Override
	public int hashCode() {
		return Objects.hash(translationId, languageId, entityName, entityDesc);
	}

	@Override
	public String toString() {
		return "{" + ", translationId:'" + getTranslationId()
				+ "'" + ", languageId:'" + getLanguageId() + "'" + ", entityName:'" + getEntityName() + "'"
				+ ", entityDesc:'" + getEntityDesc() + "'" + "}";
	}

	public CurrencyTranslation setUpdate(CurrencyTranslationDTO object, CurrencyTranslation currency) {
		currency.setTranslationId(object.getTranslationId());
		currency.setEntityDesc(object.getEntityDesc());
		currency.setEntityName(object.getEntityName());
		currency.setLanguageId(object.getLanguageId());
		currency.setCreatedBy(object.getCreatedBy());
		currency.setCreatedOn(object.getCreatedOn());
		currency.setLastModifiedBy(object.getLastModifiedBy());
		currency.setLastModifiedOn(object.getLastModifiedOn());
		return currency;
	}
}
