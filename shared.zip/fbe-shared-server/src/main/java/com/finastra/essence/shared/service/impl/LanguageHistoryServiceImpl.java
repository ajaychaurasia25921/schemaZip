/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.shared.service.impl;

import com.finastra.essence.shared.service.LanguageHistoryService;
import com.finastra.essence.shared.domain.LanguageHistory;
import com.finastra.essence.shared.repository.LanguageHistoryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing LanguageHistory.
 */
@Service
@Transactional
public class LanguageHistoryServiceImpl implements LanguageHistoryService {

    private final Logger log = LoggerFactory.getLogger(LanguageHistoryServiceImpl.class);

    private final LanguageHistoryRepository languageHistoryRepository;

    /**
     * Class constructor initializes languageHistoryRepository object.
     * @param languageHistoryRepository the object of LanguageHistoryRepository to be initialized.
     */
    public LanguageHistoryServiceImpl(LanguageHistoryRepository languageHistoryRepository) {
        this.languageHistoryRepository = languageHistoryRepository;
    }

    /**
     * Stores the entry for creation and modification of language entity.
     * The languageHistory argument holds information about language entity.
     *
     * @param languageHistory the language history entity to be stored.
     * @return the persisted language history entity.
     */
    @Override
    public LanguageHistory save(LanguageHistory languageHistory) {
        log.debug("Request to save LanguageHistory : {}", languageHistory);
        return languageHistoryRepository.save(languageHistory);
    }

    /**
     *  Retrieves all the language histories from language history database.
     *
     * @param pageable the pagination information.
     * @return the list of language histories.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<LanguageHistory> findAll(Pageable pageable) {
        log.debug("Request to get all LanguageHistories");
        return languageHistoryRepository.findAll(pageable);
    }

}
