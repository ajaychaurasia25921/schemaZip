/**
 * Service layer beans.
 */
package com.finastra.essence.shared.service;
