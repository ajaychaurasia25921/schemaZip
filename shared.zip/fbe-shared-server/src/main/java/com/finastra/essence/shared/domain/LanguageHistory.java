/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.shared.domain;

import com.finastra.essence.common.domain.AbstractEffectiveEntity;
import com.finastra.essence.common.util.BooleanToStringConverter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * Language is a class extends {@link AbstractEffectiveEntity} and hold
 * definitions for history_id, language_id, language_code, language_iso_code, language_name,
 * language_native_name, icon_image_file and installed_flag.
 *
 * @since 1.0
 */

@Entity
@Table(name = "FES_LANGUAGE_HISTORY", indexes = {
		@Index(name = "FES_LANGUAGE_HIST_IX2", columnList = "installed_flag", unique = false) })
public class LanguageHistory extends AbstractEffectiveEntity implements Serializable {
	/**
	 * Serialization version identifier
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Attribute which holds the value of unique identifier assigned to a language
	 * history, which is auto-generated.
	 */
	@Id
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Size(max = 36)
	@Column(name = "history_id", length = 36)
	private String historyId;
	/**
	 * Attribute referring the unique identifier assigned to a language.
	 */
	@NotNull
	@Size(max = 36)
	@GeneratedValue(generator = "uuid2")
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@Column(name = "language_id", length = 36, nullable = false)
	private String languageId;
	/**
	 * Attribute which holds the value of unique code assigned to a language.
	 */
	@NotNull
	@Column(name = "language_code", nullable = false)
	private String languageCode;
	/**
	 * Attribute which holds the value of ISO 2-characters code associated with the
	 * language.
	 */
	@NotNull
	@Column(name = "language_iso_code", nullable = false)
	private String languageIsoCode;
	/**
	 * Attribute which holds the name of the language.
	 */
	@NotNull
	@Size(max = 80)
	@Column(name = "language_name", length = 80, nullable = false)
	private String languageName;
	/**
	 * Attribute which holds the native name of the language.
	 */
	@NotNull
	@Size(max = 100)
	@Column(name = "language_native_name", length = 100, nullable = false)
	private String languageNativeName;
	/**
	 * Attribute which holds the image filename associated with the language, along with
	 * the location.
	 */
	@Size(max = 240)
	@Column(name = "icon_image_file", length = 240)
	private String iconImageFile;
	/**
	 * Flag to indicate whether the language is installed in the application.
	 */
	@Column(name = "installed_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private boolean installedFlag;
	
	@Column(name = "default_language_flag", length = 1)
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean defaultLanguageFlag;
	/**
	 * Default constructor of Language History.
	 */

	public LanguageHistory() {
		// Default constructor.
	}
	/**
	 * This method gets whether the language  has been set
	 * to default in the application or not.
	 *
	 * @return true if the language is set as default
	 *         application, otherwise false.
	 */
	
	
	public Boolean getDefaultLanguageFlag() {
		return defaultLanguageFlag;
	}
	/**
	 * This method sets the language to default language in application.
	 * @param defaultLanguageFlag the language is set as default
	 *         application.
	 */
	public void setDefaultLanguageFlag(Boolean defaultLanguageFlag) {
		this.defaultLanguageFlag = defaultLanguageFlag;
	}

	/**
	 * Attribute holding version number of the currency.
	 */
	private Long versionNumber;

	/**
	 * This is a getter which gets version number assigned to the language.
	 * @return the string value holding version number assigned to a language.
	 */
	public Long getVersionNumber() {
		return versionNumber;
	}
	
	public LanguageHistory versionNumber(long versionNumber) {
		this.versionNumber = versionNumber;
		return this;
	}

	/**
	 * This is a setter which sets version number assigned to the language.
	 * @param versionNumber the string value holding version number assigned to a language.
	 */
	public void setVersionNumber(Long versionNumber) {
		this.versionNumber = versionNumber;
	}
	/**
	 * This method returns an identifier assigned to the language history.
	 *
	 * @return the identifier assigned to the language history.
	 */
	public String getHistoryId() {
		return historyId;
	}

	public LanguageHistory historyId(String historyId) {
		this.historyId = historyId;
		return this;
	}

	/**
	 * This method registers an identifier to the language history
	 *
	 * @param historyId the auto-generated string value to be set.
	 */
	public void setHistoryId(String historyId) {
		this.historyId = historyId;
	}

	/**
	 * This method returns an identifier assigned to the language
	 *
	 * @return the identifier assigned to the language.
	 */
	public String getLanguageId() {
		return languageId;
	}

	public LanguageHistory languageId(String languageId) {
		this.languageId = languageId;
		return this;
	}

	/**
	 * This method registers an identifier to the language
	 *
	 * @param languageId the auto-generated string value to be set.
	 */
	public void setLanguageId(String languageId) {
		this.languageId = languageId;
	}

	/**
	 * This method returns a language code to the language
	 *
	 * @return the code assigned to a language.
	 */
	public String getLanguageCode() {
		return languageCode;
	}

	public LanguageHistory languageCode(String languageCode) {
		this.languageCode = languageCode;
		return this;
	}

	/**
	 * This method registers an language code  to the language
	 *
	 * @param languageCode the code assigned to the language.
	 */
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	/**
	 * This method returns a language iso code to the language
	 *
	 * @return the iso code assigned to a language.
	 */
	public String getLanguageIsoCode() {
		return languageIsoCode;
	}

	public LanguageHistory languageIsoCode(String languageIsoCode) {
		this.languageIsoCode = languageIsoCode;
		return this;
	}

	/**
	 * This method registers an language iso code  to the language
	 *
	 * @param languageIsoCode the iso code assigned to the language.
	 */
	public void setLanguageIsoCode(String languageIsoCode) {
		this.languageIsoCode = languageIsoCode;
	}

	/**
	 * This method returns a language native name to the language
	 *
	 * @return the native name of a language.
	 */
	public String getLanguageName() {
		return languageName;
	}

	public LanguageHistory languageName(String languageName) {
		this.languageName = languageName;
		return this;
	}

	/**
	 * This method registers an language name to the language
	 *
	 * @param languageName the name ogf the language.
	 */
	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}

	/**
	 * This method returns a language native name to the language
	 *
	 * @return the native name of a language.
	 */
	public String getLanguageNativeName() {
		return languageNativeName;
	}

	public LanguageHistory languageNativeName(String languageNativeName) {
		this.languageNativeName = languageNativeName;
		return this;
	}

	/**
	 * This method registers an language name to the language
	 *
	 * @param languageNativeName the native name of the language
	 */
	public void setLanguageNativeName(String languageNativeName) {
		this.languageNativeName = languageNativeName;
	}

	/**
	 * This method returns a icon image file to the language.
	 *
	 * @return the image filename associated with a
	 *         language.
	 */
	public String getIconImageFile() {
		return iconImageFile;
	}

	public LanguageHistory iconImageFile(String iconImageFile) {
		this.iconImageFile = iconImageFile;
		return this;
	}

	/**
	 * This method registers an icon image file to the language
	 *
	 * @param iconImageFile the image filename.
	 */
	public void setIconImageFile(String iconImageFile) {
		this.iconImageFile = iconImageFile;
	}

	/**
	 * This method checks whether the language  has been successfully
	 * installed in the application or not.
	 *
	 * @return true if the language is installed in the
	 *         application, otherwise false.
	 */
	public boolean getInstalledFlag() {
		return installedFlag;
	}

	public LanguageHistory installedFlag(boolean installedFlag) {
		this.installedFlag = installedFlag;
		return this;
	}

	/**
	 * This method installs an language in the application.
	 *
	 * @param installedFlag true if the language is installed in the
	 * 	       application, otherwise false.
	 */
	public void setInstalledFlag(boolean installedFlag) {
		this.installedFlag = installedFlag;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		LanguageHistory languageHistory = (LanguageHistory) o;
		if (languageHistory.getHistoryId() == null || getHistoryId() == null) {
			return false;
		}
		return Objects.equals(getHistoryId(), languageHistory.getHistoryId());
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getHistoryId());
	}

	@Override
	public String toString() {
		return "LanguageHistory{" + ", historyId='" + getHistoryId() + "'" + ", languageId='" + getLanguageId() + "'"
				+ ", languageCode='" + getLanguageCode() + "'" + ", languageIsoCode='" + getLanguageIsoCode() + "'"
				+ ", languageName='" + getLanguageName() + "'" + ", languageNativeName='" + getLanguageNativeName()
				+ "'" + ", iconImageFile='" + getIconImageFile() + "'" + ", installedFlag='" + getInstalledFlag() + "'"
				+ ", defaultLanguageFlag='" + getDefaultLanguageFlag() + "'"
				+ "}";
	}

	public LanguageHistory copyObject(Language object) {
		LanguageHistory languageHistory = new LanguageHistory();
		languageHistory.setLanguageId(object.getLanguageId());
		languageHistory.setLanguageCode(object.getLanguageCode());
		languageHistory.setLanguageIsoCode(object.getLanguageIsoCode());
		languageHistory.setLanguageName(object.getLanguageName());
		languageHistory.setLanguageNativeName(object.getLanguageNativeName());
		languageHistory.setIconImageFile(object.getIconImageFile());
		languageHistory.setSystemFlag(object.isSystemFlag());
		languageHistory.setVersionNumber(object.getVersionNumber());
		languageHistory.setInstalledFlag(object.getInstalledFlag());
		languageHistory.setActiveFlag(object.isActiveFlag());
		languageHistory.setCreatedBy(object.getCreatedBy());
		languageHistory.setCreatedOn(object.getCreatedOn());
		languageHistory.setActiveFrom(object.getActiveFrom());
		languageHistory.setActiveTill(object.getActiveTill());
		languageHistory.setLastModifiedBy(object.getLastModifiedBy());
		languageHistory.setDefaultLanguageFlag(object.getDefaultLanguageFlag());
		languageHistory.setLastModifiedOn(object.getLastModifiedOn());
		return languageHistory;
	}
}
