/**
 * JPA domain objects.
 */
package com.finastra.essence.shared.domain;
