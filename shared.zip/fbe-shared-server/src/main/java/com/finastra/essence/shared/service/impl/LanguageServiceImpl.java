/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.shared.service.impl;

import com.finastra.essence.common.exception.ErrorDetails;
import com.finastra.essence.common.domain.Elastic;
import com.finastra.essence.common.domain.KafkaMessage;
import com.finastra.essence.common.exception.UserDefinedException;
import com.finastra.essence.common.util.ElasticSearchRestClient;
import com.finastra.essence.shared.common.ISearchFactory;
import com.finastra.essence.shared.common.KafkaHandler;
import com.finastra.essence.shared.common.FBESharedServicesConstants;
import com.finastra.essence.shared.domain.LanguageHistory;
import com.finastra.essence.shared.service.LanguageHistoryService;
import com.finastra.essence.shared.service.LanguageService;
import com.finastra.essence.shared.domain.Language;
import com.finastra.essence.shared.repository.LanguageRepository;
import com.finastra.essence.shared.service.dto.LanguageDTO;
import com.finastra.essence.shared.service.mapper.LanguageMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing Language.
 */
@Service
@Transactional
@RefreshScope
public class LanguageServiceImpl implements LanguageService {

	@Value("${elasticSearchServiceUrl}")
	private String elasticSearchServiceUrl;

	@Value("${broker}")
	private String broker;

	@Value("${languageTopic}")
	private String languageTopic;

	@Value("${docUrl}")
	private String docUrl;

	@Value("${searchServiceUrl}")
	private String searchServiceUrl;
	
	private String searchParameters = "languageCode,languageIsoCode,languageName,activeFlag_B";

	private final ErrorDetails errorDetails = new ErrorDetails();

	private final String entityName = "fes_language";

	private final Logger log = LoggerFactory.getLogger(LanguageServiceImpl.class);

	private final LanguageRepository languageRepository;

	private final LanguageMapper languageMapper;

	private LocalDateTime date = LocalDateTime.now();

	/**
	 * Class constructor initializes languageRepository and languageMapper objects.
	 * 
	 * @param languageRepository the object of languageRepository to be initialized.
	 * @param languageMapper     the object of languageMapper to be initialized.
	 */
	public LanguageServiceImpl(LanguageRepository languageRepository, LanguageMapper languageMapper) {
		this.languageRepository = languageRepository;
		this.languageMapper = languageMapper;
	}

	@Autowired
	private LanguageHistoryService languageHistoryService;

	/**
	 * Stores the language entity after validating attributes of language. The
	 * languageDTO argument should be given during post operations. If the none of
	 * the language's attribute violates the constraints then the language gets
	 * stored, otherwise relative message of violation should be displayed.
	 *
	 * @param languageDTO the language entity to save
	 * @return the persisted language entity.
	 */
	@Override
	public LanguageDTO save(LanguageDTO languageDTO) {
		log.debug("Request to save Language : {}", languageDTO);
		validatePostLanguage(languageDTO);
		Language languageSavedResult = null;
		Language language = null;
		try {
			language = languageMapper.toEntity(languageDTO);
			languageSavedResult = languageRepository.saveAndFlush(language);
			languageHistoryService.save(new LanguageHistory().copyObject(languageSavedResult));
		} catch (DataIntegrityViolationException e) {
			log.error(" [ERROR] : {} ", e.getMessage());
			errorDetails.setDetail(FBESharedServicesConstants.LANG_EXIST);
			throw new UserDefinedException(errorDetails);
		}
		KafkaHandler.produce(new KafkaMessage().createMessage(FBESharedServicesConstants.LANG_ENTITY, languageSavedResult.getLanguageId(),FBESharedServicesConstants.CREATED,String.valueOf(languageSavedResult)), broker, languageTopic);
		ElasticSearchRestClient.post(languageSavedResult, languageSavedResult.getLanguageId(),
				elasticSearchServiceUrl + entityName + docUrl);

		return languageMapper.toDto(languageSavedResult);
	}

	/**
	 * Amends the language entity after validating attributes of language. The
	 * languageDTO argument should be given during put operations. If the none of
	 * the currency's attribute violates the constraints then the respective
	 * language gets updated, otherwise relative message of violation should be
	 * displayed.
	 *
	 * @param languageDTO the language entity to update.
	 * @return the persisted language entity.
	 */
	@Override
	public LanguageDTO update(LanguageDTO languageDTO) throws URISyntaxException {
		log.debug("Request to update Language : {}", languageDTO);
		validatePutLanguage(languageDTO);
		try {
			Language languageSavedResult = null;
			Optional<Language> languageExist = languageRepository.findById(languageDTO.getLanguageId());
			if (!languageExist.isPresent()) {
				throw new DataIntegrityViolationException(FBESharedServicesConstants.LANG_NOT_EXIST);
			} else {
				Language languageToUpdate = languageMapper.toEntity(languageDTO);
				if (!languageToUpdate.equals(languageExist.get())) {
						languageSavedResult = new Language().setUpdate(languageDTO, languageExist.get());
						languageHistoryService.save(new LanguageHistory().copyObject(languageSavedResult));
				} else {
					throw new DataIntegrityViolationException(FBESharedServicesConstants.EN_NO_CHNG_FOUND);
				}
			}

		KafkaHandler.produce(new KafkaMessage().createMessage(FBESharedServicesConstants.LANG_ENTITY, languageSavedResult.getLanguageId(),FBESharedServicesConstants.UPDATED,String.valueOf(languageSavedResult)), broker,
				languageTopic);
		ElasticSearchRestClient.put(languageSavedResult, languageSavedResult.getLanguageId(), elasticSearchServiceUrl + entityName + docUrl);
		return languageMapper.toDto(languageSavedResult);
		} catch (DataIntegrityViolationException e) {
			errorDetails.setDetail(e.getMessage());
			throw new UserDefinedException(errorDetails);
		}
	}

	/**
	 * Synchronizing language entities between the language database and
	 * elasticsearch.
	 */
	@Override
	public void syncData() {
		ResponseEntity<Elastic> responseEntity = null;
		try {

			List<Language> getSyncLanguages = languageRepository.findAll();
			for (Language language : getSyncLanguages) {
				responseEntity = ElasticSearchRestClient.post(language, language.getLanguageId(),
						elasticSearchServiceUrl + entityName + docUrl);
			}
			if (!(responseEntity.getStatusCode().toString().equalsIgnoreCase("200"))
					&& !(responseEntity.getStatusCode().toString().equalsIgnoreCase("201"))) {
				throw new Exception(FBESharedServicesConstants.ELST_SEARCH_DOWN);
			}
		} catch (Exception e) {
			errorDetails.setDetail(FBESharedServicesConstants.ELST_SEARCH_DOWN);
			throw new UserDefinedException(errorDetails);
		}

	}

	/**
     * Retrieves all the languages from elasticsearch.
     * @param filter the string to be searched.
     * @return  the list of languages.
      */
	@Override
	public Page<LanguageDTO> findLanguagesByFilter(LanguageDTO filter,String filterSource,Pageable page) {
		ElasticSearchFilterImpl.ElasticSearchFilterData(elasticSearchServiceUrl + entityName + searchServiceUrl);
	 return ISearchFactory.getSearchFactory(filterSource).search(filter,page,languageRepository,languageMapper);
	}

	/**
	 * Retrieves all the languages from language database.
	 *
	 * @param pageable the pagination information
	 * @return the list of languages
	 */
	@Override
	@Transactional(readOnly = true)
	public Page<LanguageDTO> findAll(Pageable pageable) {
		log.debug("Request to get all Languages");
		Page<LanguageDTO> languagePage = languageRepository.findAll(pageable).map(languageMapper::toDto);
		return languagePage;
	}

	/**
	 * Retrieves the language whose languageId is specified in argument, from
	 * language database.
	 *
	 * @param id the id of the language entity to be retrieved.
	 * @return the language entity of specified languageId.
	 */
	@Override
	@Transactional(readOnly = true)
	public Optional<LanguageDTO> findOne(String id) {
		log.debug("Request to get Language : {}", id);
		Optional<LanguageDTO> languageSaved = languageRepository.findById(id).map(languageMapper::toDto);
		return languageSaved;
	}

	/**
	 * Retrieves the language whose languageCode is specified in argument, from
	 * language database.
	 *
	 * @param languageCode the languageCode of the language entity to be retrieved.
	 * @return the language entity of specified languageCode.
	 */
	@Override
	public Optional<LanguageDTO> findCode(String languageCode) {
		Optional<LanguageDTO> languageCodeSaved = languageRepository.findByLanguageCode(languageCode)
				.map(languageMapper::toDto);
		log.debug("findCode : {} ", languageCodeSaved);
		return languageCodeSaved;
	}

	/**
	 * Validates all the attributes of language before saving into database and
	 * elasticsearch.
	 *
	 * @param languageDTO the language entity to be validated.
	 */
	public void validatePostLanguage(LanguageDTO languageDTO) {
		validateLanguageId(languageDTO);
		languageDTO.setLanguageCode(languageDTO.getLanguageCode().trim().toLowerCase());
		languageDTO.setLanguageIsoCode(languageDTO.getLanguageIsoCode().trim().toLowerCase());
		formatLanguageName(languageDTO);
		setPostActiveDate(languageDTO);
		validateDefaultLanguageFlag(languageDTO);
	}

	/**
	 * Validates all the attributes of language before updating into database and
	 * elasticsearch.
	 *
	 * @param languageDTO the language entity to be validated.
	 */
	public void validatePutLanguage(LanguageDTO languageDTO) {
		validatePutLanguageId(languageDTO);
		languageDTO.setLanguageCode(languageDTO.getLanguageCode().trim().toLowerCase());
		languageDTO.setLanguageIsoCode(languageDTO.getLanguageIsoCode().trim().toLowerCase());
		setPutActiveDate(languageDTO);
		formatLanguageName(languageDTO);
		validateDefaultLanguageFlag(languageDTO);
	}

	/**
	 * Validates the "languageId" of language entity during post operations.
	 * 
	 * @param language the language entity whose languageId to be validated.
	 */
	private void validateLanguageId(LanguageDTO language) {
		if (language.getLanguageId() != null && !language.getLanguageId().trim().equals("")) {
			errorDetails.setDetail(FBESharedServicesConstants.LANG_ID_AUTOGEN);
			throw new UserDefinedException(errorDetails);
		}
	}

	/**
	 * Validates the "languageId" of language entity during put operations.
	 * 
	 * @param language the language entity whose languageId to be validated.
	 */
	private void validatePutLanguageId(LanguageDTO language) {
		if (language.getLanguageId() == null) {
			errorDetails.setDetail(FBESharedServicesConstants.LANG_ID_NULL);
			throw new UserDefinedException(errorDetails);
		}
	}

	/**
	 * Formats the "languageName" of language entity during both post and put
	 * operations.
	 * 
	 * @param language the language entity whose languageName to be formatted.
	 */
	private void formatLanguageName(LanguageDTO language) {

		String languageName = language.getLanguageName();
		String word[];
		if (languageName != null) {
			languageName = languageName.trim();
			word = languageName.toLowerCase().split(".*\\s+");
			languageName = "";
			for (int i = 0; i < word.length; i++) {
				languageName += Character.toUpperCase(word[i].charAt(0)) + word[i].substring(1).toLowerCase() + " ";
			}
			language.setLanguageName(languageName.trim());
		}
	}

	/**
	 * Validating the defaultLanguageFlag of language.
	 * @param languageDTO the language in which defaultLanguageFlag
	 *                    to be set.
	 */
	private void validateDefaultLanguageFlag(LanguageDTO languageDTO) {

		if(languageDTO.getDefaultLanguageFlag()) {
			List<Language> languages = languageRepository.findAll();
			log.debug("LanguageDTO Value: "+languageDTO.getDefaultLanguageFlag());
			for(Language languageList : languages) {
				if(languageList.getDefaultLanguageFlag()) {
					log.debug("languageList Value " +languageList.getDefaultLanguageFlag() + "Name" + languageList.getLanguageName());
					errorDetails.setDetail("Language " + languageList.getLanguageName() + " is already set to default");
					throw new UserDefinedException(errorDetails);
				}
			}
		}
	}

	/**
	 * The activeTill and activeFrom are getting set based on the value of
	 * activeFlag of language during post operation.
	 * 
	 * @param language the language entity whose activeTill stores the date till
	 *                 when the entity is set to be active, and activeFrom stores
	 *                 the date when the entity is set to be active.
	 */
	private void setPostActiveDate(LanguageDTO language) {
		if (!language.isActiveFlag()) {
			LocalDateTime previousDate = date.minusDays(1);
			log.debug("date when active flag set to n is " + previousDate);
			language.setActiveFrom(previousDate);
			language.setActiveTill(previousDate);
		} else {
			setTrueActiveFlagDate(language);
		}
	}

	/**
	 * The activeTill and activeFrom are getting set based on the value of
	 * activeFlag of language during put operation.
	 * 
	 * @param language the language entity whose activeTill stores the date till
	 *                 when the entity is set to be active, and activeFrom stores
	 *                 the date when the entity is set to be active.
	 */
	private void setPutActiveDate(LanguageDTO language) {
		if (!language.isActiveFlag()) {
			language.setActiveTill(date);
			log.debug("ActiveTill field contains " + language.getActiveTill());
		} else {
			setTrueActiveFlagDate(language);
		}
	}

	/**
	 * The activeTill and activeFrom are getting set when the value of activeFlag of
	 * language is true.
	 * 
	 * @param language the language entity whose activeTill stores the date till
	 *                 when the entity is set to be active, and activeFrom stores
	 *                 the date when the entity is set to be active.
	 */
	private void setTrueActiveFlagDate(LanguageDTO language) {
		log.debug("ActiveFrom field is " + date);

		language.setActiveFrom(date);

		LocalDateTime dateTrue = date.plusYears(50);

		log.debug("ActiveTill field is " + dateTrue);
		language.setActiveTill(dateTrue);
	}

	/**
	 * Inactive the language whose languageId is specified in argument, from
	 * currency database.
	 *
	 * @param languageId the languageId of the language entity to be deleted.
	 *
	 */
	@Override
	public void delete(String languageId) throws URISyntaxException {
		log.debug("Request to delete Language : {}", languageId);
		Optional<Language> language = languageRepository.findById(languageId);
		language.get().setActiveFlag(false);
		language.get().setActiveTill(date);
		languageHistoryService.save(new LanguageHistory().copyObject(language.get()));
		KafkaHandler.produce(new KafkaMessage().createMessage(FBESharedServicesConstants.LANG_ENTITY, languageId,FBESharedServicesConstants.DEACTIVATED,String.valueOf(language.get())),broker,
				languageTopic);
		ElasticSearchRestClient.put(language.get(), languageId, elasticSearchServiceUrl + entityName + docUrl);
	}
}
