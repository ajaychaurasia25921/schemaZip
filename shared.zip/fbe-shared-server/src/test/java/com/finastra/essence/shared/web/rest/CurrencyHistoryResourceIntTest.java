package com.finastra.essence.shared.web.rest;

import static com.finastra.essence.shared.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.persistence.EntityManager;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import com.finastra.essence.shared.FbeSharedApp;
import com.finastra.essence.shared.domain.CurrencyHistory;
import com.finastra.essence.shared.repository.CurrencyHistoryRepository;
import com.finastra.essence.shared.service.CurrencyHistoryService;
import com.finastra.essence.shared.web.rest.errors.FBESharedResponseEntityExceptionHandler;

/**
 * Test class for the CurrencyHistoryResource REST controller.
 *
 * @see CurrencyHistoryResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = FbeSharedApp.class)
public class CurrencyHistoryResourceIntTest {

	private static final String DEFAULT_HISTORY_ID = "0169618eed720002";

	private static final String DEFAULT_CURRENCY_ID = "01696e3a5a480005";

	private static final String DEFAULT_CURRENCY_CODE = "INR";

	private static final String DEFAULT_CURRENCY_ISO_CODE = "INR";

	private static final String DEFAULT_ICON_IMAGE_FILE = "WASHINGTON";

	private static final String DEFAULT_CURRENCY_NUMERIC_CODE = "256";

	private static final String DEFAULT_CURRENCY_ALTERNATIVE_CODE = "INR";
	
	private static final long  DEFAULT_VERSION_NUMBER = 1L;
	
	

	@Autowired
	private CurrencyHistoryRepository currencyHistoryRepository;

	@Autowired
	private CurrencyHistoryService currencyHistoryService;

	@Autowired
	private MappingJackson2HttpMessageConverter jacksonMessageConverter;

	@Autowired
	private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

	@Autowired
	private FBESharedResponseEntityExceptionHandler exceptionTranslator;

	@Autowired
	private EntityManager em;

	private MockMvc restCurrencyHistoryMockMvc;

	private CurrencyHistory currencyHistory;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		final CurrencyHistoryResource currencyHistoryResource = new CurrencyHistoryResource(currencyHistoryService);
		this.restCurrencyHistoryMockMvc = MockMvcBuilders.standaloneSetup(currencyHistoryResource)
				.setCustomArgumentResolvers(pageableArgumentResolver).setControllerAdvice(exceptionTranslator)
				.setConversionService(createFormattingConversionService()).setMessageConverters(jacksonMessageConverter)
				.build();
	}

	/**
	 * Create an entity for this test.
	 *
	 * This is a static method, as tests for other entities might also need it, if
	 * they test an entity which requires the current entity.
	 */
	public static CurrencyHistory createEntity(EntityManager em) {
		CurrencyHistory currencyHistory = new CurrencyHistory().historyId(DEFAULT_HISTORY_ID)
				.currencyId(DEFAULT_CURRENCY_ID).currencyCode(DEFAULT_CURRENCY_CODE)
				.currencyIsoCode(DEFAULT_CURRENCY_ISO_CODE).iconImageFile(DEFAULT_ICON_IMAGE_FILE)
				.currencyNumericCode(DEFAULT_CURRENCY_NUMERIC_CODE)
				.currencyAlternativeCode(DEFAULT_CURRENCY_ALTERNATIVE_CODE)
				.versionNumber(DEFAULT_VERSION_NUMBER);
		return currencyHistory;
	}

	@Before
	public void initTest() {
		currencyHistory = createEntity(em);
	}

	@Test
	@Transactional
	public void getCurrencyHistory() throws Exception {
		// Initialize the database
		currencyHistoryRepository.saveAndFlush(currencyHistory);

		// Get the currencyHistory
		restCurrencyHistoryMockMvc.perform(get("/api/currency/history", currencyHistory.getHistoryId()))
				.andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(jsonPath("$.[0].currencyId").value(DEFAULT_CURRENCY_ID.toString()))
				.andExpect(jsonPath("$.[0].currencyCode").value(DEFAULT_CURRENCY_CODE.toString()))
				.andExpect(jsonPath("$.[0].currencyIsoCode").value(DEFAULT_CURRENCY_ISO_CODE.toString()))
				.andExpect(jsonPath("$.[0].iconImageFile").value(DEFAULT_ICON_IMAGE_FILE.toString()))
				.andExpect(jsonPath("$.[0].currencyNumericCode").value(DEFAULT_CURRENCY_NUMERIC_CODE))
				.andExpect(jsonPath("$.[0].currencyAlternativeCode").value(DEFAULT_CURRENCY_ALTERNATIVE_CODE.toString()))
				.andExpect(jsonPath("$.[0].versionNumber").value(DEFAULT_VERSION_NUMBER));
	}

	@Test
	@Transactional
	public void getNonExistingCurrencyHistory() throws Exception {
		// Get the currencyHistory
		restCurrencyHistoryMockMvc.perform(get("/api/currency/history/{id}", Long.MAX_VALUE))
				.andExpect(status().isNotFound());
	}

	@Test
	@Transactional
	public void equalsVerifier() throws Exception {
		TestUtil.equalsVerifier(CurrencyHistory.class);
		CurrencyHistory currencyHistory1 = new CurrencyHistory();
		currencyHistory1.setHistoryId(DEFAULT_HISTORY_ID);
		CurrencyHistory currencyHistory2 = new CurrencyHistory();
		currencyHistory2.setHistoryId(currencyHistory1.getHistoryId());
		assertThat(currencyHistory1).isEqualTo(currencyHistory2);
		currencyHistory2.setHistoryId(DEFAULT_HISTORY_ID);
		assertThat(currencyHistory1).isEqualTo(currencyHistory2);
		currencyHistory1.setHistoryId(null);
		assertThat(currencyHistory1).isNotEqualTo(currencyHistory2);
	}
}
