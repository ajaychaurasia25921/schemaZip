package com.finastra.essence.shared.web.rest;

import static com.finastra.essence.shared.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import javax.persistence.EntityManager;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import com.finastra.essence.shared.FbeSharedApp;
import com.finastra.essence.shared.domain.LanguageHistory;
import com.finastra.essence.shared.repository.LanguageHistoryRepository;
import com.finastra.essence.shared.service.LanguageHistoryService;
import com.finastra.essence.shared.web.rest.errors.FBESharedResponseEntityExceptionHandler;

/**
 * Test class for the LanguageHistoryResource REST controller.
 *
 * @see LanguageHistoryResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = FbeSharedApp.class)
public class LanguageHistoryResourceIntTest {

    private static final String DEFAULT_HISTORY_ID = "01696a999ea90018";
    
    private static final String DEFAULT_LANGUAGE_ID = "0169618794bb0001";
    
    private static final String DEFAULT_LANGUAGE_CODE = "FR";
    
    private static final String DEFAULT_LANGUAGE_ISO_CODE = "FR";
    
    private static final String DEFAULT_LANGUAGE_NAME = "FRENCH";
   
    private static final String DEFAULT_LANGUAGE_NATIVE_NAME = "FRANCAIS";
   
    private static final String DEFAULT_ICON_IMAGE_FILE = "DALLAS";
   
    private static final boolean DEFAULT_INSTALLED_FLAG = true;
    
    private static final long  DEFAULT_VERSION_NUMBER = 1L;
   
    @Autowired
    private LanguageHistoryRepository languageHistoryRepository;
    
    @Autowired
    private LanguageHistoryService languageHistoryService;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private FBESharedResponseEntityExceptionHandler exceptionTranslator;

    @Autowired
    private EntityManager em;

    private MockMvc restLanguageHistoryMockMvc;

    private LanguageHistory languageHistory;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final LanguageHistoryResource languageHistoryResource = new LanguageHistoryResource(languageHistoryService);
        this.restLanguageHistoryMockMvc = MockMvcBuilders.standaloneSetup(languageHistoryResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static LanguageHistory createEntity(EntityManager em) {
        LanguageHistory languageHistory = new LanguageHistory()
            .historyId(DEFAULT_HISTORY_ID)
            .languageCode(DEFAULT_LANGUAGE_CODE)
            .languageIsoCode(DEFAULT_LANGUAGE_ISO_CODE)
            .languageName(DEFAULT_LANGUAGE_NAME)
            .languageNativeName(DEFAULT_LANGUAGE_NATIVE_NAME)
            .languageId(DEFAULT_LANGUAGE_ID)
            .iconImageFile(DEFAULT_ICON_IMAGE_FILE)
            .installedFlag(DEFAULT_INSTALLED_FLAG)
            .versionNumber(DEFAULT_VERSION_NUMBER);
        return languageHistory;
    }

    @Before
    public void initTest() {
        languageHistory = createEntity(em);
    }


    //@Test
    @Transactional
    public void getAllLanguageHistories() throws Exception {
        languageHistoryRepository.saveAndFlush(languageHistory);
        restLanguageHistoryMockMvc.perform(get("/api/language/history?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].languageCode").value(hasItem(DEFAULT_LANGUAGE_CODE.toString())))
            .andExpect(jsonPath("$.[*].languageIsoCode").value(hasItem(DEFAULT_LANGUAGE_ISO_CODE.toString())))
            .andExpect(jsonPath("$.[*].languageName").value(hasItem(DEFAULT_LANGUAGE_NAME.toString())))
            .andExpect(jsonPath("$.[*].languageNativeName").value(hasItem(DEFAULT_LANGUAGE_NATIVE_NAME.toString())))
            .andExpect(jsonPath("$.[*].iconImageFile").value(hasItem(DEFAULT_ICON_IMAGE_FILE.toString())))
            .andExpect(jsonPath("$.[*].installedFlag").value(hasItem(DEFAULT_INSTALLED_FLAG)))
            .andExpect(jsonPath("$.[*].versionNumber").value(hasItem(DEFAULT_VERSION_NUMBER)));
    }
    
    @Test
    @Transactional
    public void getLanguageHistory() throws Exception {
        languageHistoryRepository.saveAndFlush(languageHistory);
        restLanguageHistoryMockMvc.perform(get("/api/language/history", languageHistory.getHistoryId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[0].languageCode").value(DEFAULT_LANGUAGE_CODE.toString()))
            .andExpect(jsonPath("$.[0].languageIsoCode").value(DEFAULT_LANGUAGE_ISO_CODE.toString()))
            .andExpect(jsonPath("$.[0].languageName").value(DEFAULT_LANGUAGE_NAME.toString()))
            .andExpect(jsonPath("$.[0].languageNativeName").value(DEFAULT_LANGUAGE_NATIVE_NAME.toString()))
            .andExpect(jsonPath("$.[0].iconImageFile").value(DEFAULT_ICON_IMAGE_FILE.toString()))
            .andExpect(jsonPath("$.[0].installedFlag").value(DEFAULT_INSTALLED_FLAG))
            .andExpect(jsonPath("$.[0].versionNumber").value(DEFAULT_VERSION_NUMBER));
    }

    @Test
    @Transactional
    public void getNonExistingLanguageHistory() throws Exception {
        // Get the languageHistory
        restLanguageHistoryMockMvc.perform(get("/api/language/history/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }




    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
       TestUtil.equalsVerifier(LanguageHistory.class);
        LanguageHistory languageHistory1 = new LanguageHistory();
        languageHistory1.setHistoryId(DEFAULT_HISTORY_ID);
        LanguageHistory languageHistory2 = new LanguageHistory();
        languageHistory2.setHistoryId(languageHistory1.getHistoryId());
        assertThat(languageHistory1).isEqualTo(languageHistory2);
        languageHistory2.setHistoryId(DEFAULT_HISTORY_ID);
        assertThat(languageHistory1).isEqualTo(languageHistory2);
        languageHistory1.setHistoryId(null);
        assertThat(languageHistory1).isNotEqualTo(languageHistory2);
    }
}
