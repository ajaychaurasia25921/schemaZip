package com.finastra.essence.shared.web.rest;

import static com.finastra.essence.shared.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import com.finastra.essence.shared.FbeSharedApp;
import com.finastra.essence.shared.domain.Currency;
import com.finastra.essence.shared.domain.Language;
import com.finastra.essence.shared.repository.LanguageRepository;
import com.finastra.essence.shared.service.LanguageService;
import com.finastra.essence.shared.service.dto.CurrencyDTO;
import com.finastra.essence.shared.service.dto.LanguageDTO;
import com.finastra.essence.shared.service.mapper.LanguageMapper;
import com.finastra.essence.shared.web.rest.errors.FBESharedResponseEntityExceptionHandler;

/**
 * Test class for the LanguageResource REST controller.
 *
 * @see LanguageResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = FbeSharedApp.class)
public class LanguageResourceIntTest {

	private static final String DEFAULT_LANGUAGE_ID = "01696189a8b00001";
	private static final String UPDATED_LANGUAGE_ID = "01696189c8a00002";

	private static final String DEFAULT_LANGUAGE_CODE = "FR";
	private static final String UPDATED_LANGUAGE_CODE = "EN";

	private static final String DEFAULT_LANGUAGE_ISO_CODE = "FR";
	private static final String UPDATED_LANGUAGE_ISO_CODE = "EN";

	private static final String DEFAULT_LANGUAGE_NAME = "FRENCH";
	private static final String UPDATED_LANGUAGE_NAME = "ENGLISH";

	private static final String DEFAULT_LANGUAGE_NATIVE_NAME = "FRANCAIS";
	private static final String UPDATED_LANGUAGE_NATIVE_NAME = "ENGLISH";

	private static final String DEFAULT_ICON_IMAGE_FILE = "DALLAS";
	private static final String UPDATED_ICON_IMAGE_FILE = "CHICAGO";

	private static final boolean DEFAULT_SYSTEM_FLAG = true;
	private static final boolean UPDATED_SYSTEM_FLAG = true;

	private static final boolean DEFAULT_INSTALLED_FLAG = false;
	private static final boolean UPDATED_INSTALLED_FLAG = false;

	private static final long DEFAULT_VERSION_NUMBER = 1L;
	private static final long UPDATED_VERSION_NUMBER = 2L;

	@Autowired
	private LanguageRepository languageRepository;

	@Autowired
	private LanguageMapper languageMapper;

	@Autowired
	private LanguageService languageservice;

	@Autowired
	private MappingJackson2HttpMessageConverter jacksonMessageConverter;

	@Autowired
	private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

	@Autowired
	private FBESharedResponseEntityExceptionHandler exceptionTranslator;

	@Autowired
	private EntityManager em;

	private MockMvc restLanguageMockMvc;

	private Language language;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		final LanguageResource languageResource = new LanguageResource(languageservice);
		this.restLanguageMockMvc = MockMvcBuilders.standaloneSetup(languageResource)
				.setCustomArgumentResolvers(pageableArgumentResolver).setControllerAdvice(exceptionTranslator)
				.setConversionService(createFormattingConversionService()).setMessageConverters(jacksonMessageConverter)
				.build();
	}

	/**
	 * Create an entity for this test.
	 *
	 * This is a static method, as tests for other entities might also need it, if
	 * they test an entity which requires the current entity.
	 */
	public static Language createEntity(EntityManager em) {
		Language language = new Language().languageId(DEFAULT_LANGUAGE_ID).languageCode(DEFAULT_LANGUAGE_CODE)
				.languageIsoCode(DEFAULT_LANGUAGE_ISO_CODE).languageName(DEFAULT_LANGUAGE_NAME)
				.languageNativeName(DEFAULT_LANGUAGE_NATIVE_NAME).iconImageFile(DEFAULT_ICON_IMAGE_FILE)
				.versionNumber(DEFAULT_VERSION_NUMBER).installedFlag(DEFAULT_INSTALLED_FLAG);
		return language;
	}

	@Before
	public void initTest() {
		language = createEntity(em);
	}

	@Test
	@Transactional
	public void createLanguage() throws Exception {
		int databaseSizeBeforeCreate = languageRepository.findAll().size();
		language.setLanguageId("");
		LanguageDTO languageDTO = languageMapper.toDto(language);
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isCreated());
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isCreated());
		List<Language> languageList = languageRepository.findAll();
		//assertThat(languageList).hasSize(databaseSizeBeforeCreate + 1);
		Language testLanguage = languageList.get(languageList.size() - 1);
		assertThat(testLanguage.getLanguageId()).isNotEqualTo(DEFAULT_LANGUAGE_ID);
		assertThat(testLanguage.getLanguageCode()).isNotEqualTo(DEFAULT_LANGUAGE_CODE);
		assertThat(testLanguage.getLanguageIsoCode()).isNotEqualTo(DEFAULT_LANGUAGE_ISO_CODE);
		assertThat(testLanguage.getLanguageName()).isNotEqualTo(DEFAULT_LANGUAGE_NAME);
		assertThat(testLanguage.getLanguageNativeName()).isEqualTo(DEFAULT_LANGUAGE_NATIVE_NAME);
		assertThat(testLanguage.getIconImageFile()).isEqualTo(DEFAULT_ICON_IMAGE_FILE);
		assertThat(testLanguage.isSystemFlag()).isNotEqualTo(DEFAULT_SYSTEM_FLAG);
		assertThat(testLanguage.getInstalledFlag()).isEqualTo(DEFAULT_INSTALLED_FLAG);
		assertThat(testLanguage.getVersionNumber()).isEqualTo(DEFAULT_VERSION_NUMBER);

	}

	@Test
	@Transactional
	public void createLanguageValidateLanguageId() throws Exception {
		LanguageDTO languageDTO = languageMapper.toDto(language);
		languageDTO.setLanguageId(DEFAULT_LANGUAGE_ID);
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
	}
	
	@Test
	@Transactional
	public void languageSearchTest() throws Exception {
		languageRepository.saveAndFlush(language);
		LanguageDTO languageDTO = languageMapper.toDto(language);
		languageDTO.setLanguageId(DEFAULT_LANGUAGE_ID);
		restLanguageMockMvc.perform(post("/api/language/search").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().is3xxRedirection());
	}
	
	@Test
	@Transactional
	public void currencySyncTest() throws Exception {
		languageRepository.saveAndFlush(language);
		LanguageDTO languageDTO = languageMapper.toDto(language);
		//List<Language> languageList = languageRepository.findAll();
		restLanguageMockMvc.perform(post("/api/language/elastic/syncData").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
	}

	
	@Test
	@Transactional
	public void createLanguageValidateCode() throws Exception {
		LanguageDTO languageDTO = languageMapper.toDto(language);
		languageDTO.setLanguageCode(DEFAULT_LANGUAGE_CODE);
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void createLanguageValidateCodeFailure() throws Exception {
		LanguageDTO languageDTO = languageMapper.toDto(language);
		languageDTO.setLanguageCode("ewqe24234234");
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void createLanguageValidateISOCode() throws Exception {
		LanguageDTO languageDTO = languageMapper.toDto(language);
		languageDTO.setLanguageIsoCode(DEFAULT_LANGUAGE_ISO_CODE);
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void createLanguageValidateISOCodeFailure() throws Exception {
		LanguageDTO languageDTO = languageMapper.toDto(language);
		languageDTO.setLanguageIsoCode("ewqe24234234");
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void createLanguageValidateLanguageName() throws Exception {
		LanguageDTO languageDTO = languageMapper.toDto(language);
		languageDTO.setLanguageName("__________");
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void createLanguageWithExistingId() throws Exception {
		int databaseSizeBeforeCreate = languageRepository.findAll().size();
		LanguageDTO languageDTO = languageMapper.toDto(language);
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
		List<Language> languageList = languageRepository.findAll();
		assertThat(languageList).hasSize(databaseSizeBeforeCreate);
	}

	@Test
	@Transactional
	public void checkLanguageIdIsRequired() throws Exception {
		int databaseSizeBeforeTest = languageRepository.findAll().size();
		LanguageDTO languageDTO = languageMapper.toDto(language);
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
		List<Language> languageList = languageRepository.findAll();
		assertThat(languageList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void checkLanguageCodeIsRequired() throws Exception {
		int databaseSizeBeforeTest = languageRepository.findAll().size();
		// set the field null
		language.setLanguageCode(null);

		// Create the Language, which fails.
		LanguageDTO languageDTO = languageMapper.toDto(language);

		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());

		List<Language> languageList = languageRepository.findAll();
		assertThat(languageList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void checkLanguageIsoCodeIsRequired() throws Exception {
		int databaseSizeBeforeTest = languageRepository.findAll().size();
		// set the field null
		language.setLanguageIsoCode(null);

		// Create the Language, which fails.
		LanguageDTO languageDTO = languageMapper.toDto(language);

		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());

		List<Language> languageList = languageRepository.findAll();
		assertThat(languageList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void checkLanguageNameIsRequired() throws Exception {
		int databaseSizeBeforeTest = languageRepository.findAll().size();
		// set the field null
		language.setLanguageName(null);

		// Create the Language, which fails.
		LanguageDTO languageDTO = languageMapper.toDto(language);

		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());

		List<Language> languageList = languageRepository.findAll();
		assertThat(languageList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void checkLanguageNativeNameIsRequired() throws Exception {
		int databaseSizeBeforeTest = languageRepository.findAll().size();
		language.setLanguageNativeName(null);

		// Create the Language, which fails.
		LanguageDTO languageDTO = languageMapper.toDto(language);

		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());

		List<Language> languageList = languageRepository.findAll();
		assertThat(languageList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void checkSystemFlagIsRequired() throws Exception {
		int databaseSizeBeforeTest = languageRepository.findAll().size();
		LanguageDTO languageDTO = languageMapper.toDto(language);
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
		List<Language> languageList = languageRepository.findAll();
		assertThat(languageList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void checkInstalledFlagIsRequired() throws Exception {
		int databaseSizeBeforeTest = languageRepository.findAll().size();
		LanguageDTO languageDTO = languageMapper.toDto(language);
		restLanguageMockMvc.perform(post("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());
		List<Language> languageList = languageRepository.findAll();
		assertThat(languageList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void getAlllanguage() throws Exception {
		languageRepository.saveAndFlush(language);
		restLanguageMockMvc.perform(get("/api/language")).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(jsonPath("$.[*].languageCode").value(hasItem(DEFAULT_LANGUAGE_CODE.toString())))
				.andExpect(jsonPath("$.[*].languageIsoCode").value(hasItem(DEFAULT_LANGUAGE_ISO_CODE.toString())))
				.andExpect(jsonPath("$.[*].languageName").value(hasItem(DEFAULT_LANGUAGE_NAME.toString())))
				.andExpect(jsonPath("$.[*].languageNativeName").value(hasItem(DEFAULT_LANGUAGE_NATIVE_NAME.toString())))
				.andExpect(jsonPath("$.[*].iconImageFile").value(hasItem(DEFAULT_ICON_IMAGE_FILE.toString())))
				.andExpect(jsonPath("$.[*].installedFlag").value(hasItem(DEFAULT_INSTALLED_FLAG)));
	}

	@Test
	@Transactional
	public void getLanguageWithCode() throws Exception {
		languageRepository.saveAndFlush(language);
		restLanguageMockMvc.perform(get("/api/language/code/{languageIsoCode}", language.getLanguageIsoCode()))
				.andExpect(status().isOk());
	}

	@Test
	@Transactional
	public void getLanguage() throws Exception {
		Language saveAndFlush = languageRepository.saveAndFlush(language);
		restLanguageMockMvc.perform(get("/api/language/{id}", saveAndFlush.getLanguageId())).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(jsonPath("$.languageCode").value(DEFAULT_LANGUAGE_CODE.toString()))
				.andExpect(jsonPath("$.languageIsoCode").value(DEFAULT_LANGUAGE_ISO_CODE.toString()))
				.andExpect(jsonPath("$.languageName").value(DEFAULT_LANGUAGE_NAME.toString()))
				.andExpect(jsonPath("$.languageNativeName").value(DEFAULT_LANGUAGE_NATIVE_NAME.toString()))
				.andExpect(jsonPath("$.iconImageFile").value(DEFAULT_ICON_IMAGE_FILE.toString()))
				.andExpect(jsonPath("$.installedFlag").value(DEFAULT_INSTALLED_FLAG));
	}

	@Test
	@Transactional
	public void getNonExistingLanguage() throws Exception {
		// Get the language
		restLanguageMockMvc.perform(get("/api/language/{id}", Long.MAX_VALUE)).andExpect(status().isNotFound());
	}

	@Test
	@Transactional
	public void updateLanguage() throws Exception {
		Language saveAndFlush = languageRepository.saveAndFlush(language);
		Language updatedLanguage = languageRepository.findById(saveAndFlush.getLanguageId()).get();
		em.detach(updatedLanguage);
		updatedLanguage.languageCode(UPDATED_LANGUAGE_CODE)
				.languageIsoCode(UPDATED_LANGUAGE_ISO_CODE).languageName(UPDATED_LANGUAGE_NAME)
				.languageNativeName(UPDATED_LANGUAGE_NATIVE_NAME).iconImageFile(UPDATED_ICON_IMAGE_FILE)
				.setSystemFlag(UPDATED_SYSTEM_FLAG);
		updatedLanguage.setActiveFlag(true);
		LanguageDTO languageDTO = languageMapper.toDto(updatedLanguage);
		restLanguageMockMvc.perform(put("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isOk());
	}

	@Test
	@Transactional
	public void updateNonExistingLanguage() throws Exception {
		int databaseSizeBeforeUpdate = languageRepository.findAll().size();

		// Create the Language
		LanguageDTO languageDTO = languageMapper.toDto(language);

		// If the entity doesn't have an ID, it will throw BadRequestAlertException
		restLanguageMockMvc.perform(put("/api/language").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(languageDTO))).andExpect(status().isBadRequest());

		// Validate the Language in the database
		List<Language> languageList = languageRepository.findAll();
		assertThat(languageList).hasSize(databaseSizeBeforeUpdate);
	}

	@Test
	@Transactional
	public void deleteLanguage() throws Exception {
		Language saveAndFlush = languageRepository.saveAndFlush(language);
		int databaseSizeBeforeDelete = languageRepository.findAll().size();
		restLanguageMockMvc
				.perform(delete("/api/language/{id}", saveAndFlush.getLanguageId()).accept(TestUtil.APPLICATION_JSON_UTF8))
				.andExpect(status().isOk());
		List<Language> languageList = languageRepository.findAll();
		assertThat(languageList).hasSize(databaseSizeBeforeDelete);
	}

	@Test
	@Transactional
	public void equalsVerifier() throws Exception {
		TestUtil.equalsVerifier(Language.class);
		Language language1 = new Language();
		language1.setLanguageId(DEFAULT_LANGUAGE_ID);
		Language language2 = new Language();
		assertThat(language1).isNotEqualTo(language2);
		language2.setLanguageId(language1.getLanguageId());
		assertThat(language1).isEqualTo(language2);
		language2.setLanguageId(DEFAULT_LANGUAGE_ID);
		assertThat(language1).isEqualTo(language2);
		language2.setLanguageId(null);
		assertThat(language1).isNotEqualTo(language2);
	}

	@Test
	@Transactional
	public void dtoEqualsVerifier() throws Exception {
		TestUtil.equalsVerifier(LanguageDTO.class);
		LanguageDTO languageDTO1 = new LanguageDTO();
		languageDTO1.setLanguageId(DEFAULT_LANGUAGE_ID);
		LanguageDTO languageDTO2 = new LanguageDTO();
		assertThat(languageDTO1).isNotEqualTo(languageDTO2);
		languageDTO2.setLanguageId(languageDTO1.getLanguageId());
		assertThat(languageDTO1).isEqualTo(languageDTO2);
		languageDTO2.setLanguageId(DEFAULT_LANGUAGE_ID);
		assertThat(languageDTO1).isEqualTo(languageDTO2);
		languageDTO1.setLanguageId(null);
		assertThat(languageDTO1).isNotEqualTo(languageDTO2);
	}

	@Test
	@Transactional
	public void testEntityFromId() {
		assertThat(languageMapper.fromId("42").equals("42"));
		assertThat(languageMapper.fromId(null)).isNull();
		LanguageDTO languageDTO1 = new LanguageDTO();
		languageDTO1.setLanguageId(DEFAULT_LANGUAGE_ID);
		List<LanguageDTO> languageDTOList = new ArrayList<LanguageDTO>();
		List<Language> language = new ArrayList<Language>();
		languageMapper.toEntity(languageDTO1);
		languageMapper.toEntity(languageDTOList);
		languageMapper.toDto(language);
	}
}
