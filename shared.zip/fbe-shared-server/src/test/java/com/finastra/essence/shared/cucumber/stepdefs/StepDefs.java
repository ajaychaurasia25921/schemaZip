package com.finastra.essence.shared.cucumber.stepdefs;

import com.finastra.essence.shared.FbeSharedApp;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.ResultActions;

import org.springframework.boot.test.context.SpringBootTest;

@WebAppConfiguration
@SpringBootTest
@ContextConfiguration(classes = FbeSharedApp.class)
public abstract class StepDefs {

    protected ResultActions actions;

}
