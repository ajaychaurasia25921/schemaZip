package com.finastra.essence.shared.web.rest.util;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.reflect.SourceLocation;
import org.aspectj.runtime.internal.AroundClosure;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.finastra.essence.shared.FbeSharedApp;
import com.finastra.essence.shared.aop.logging.LoggingAspect;

import cucumber.api.java.Before;
@RunWith(SpringRunner.class)
@SpringBootTest(classes = FbeSharedApp.class)
public class LoggingAspectTest {

	@Mock
	private LoggingAspect loggingAspect;
	
	@Mock
	JoinPoint joinPoint;
	
	@Mock
	ProceedingJoinPoint pjp;

	@Mock
	Object result;
	
	@Mock
	Throwable e;
	
	
	@Test
	public void testLogJoinPoint() {
		loggingAspect.springBeanPointcut();
	}

	@Test
	public void testLogAfterThrowing() {
		loggingAspect.logAfterThrowing(joinPoint, e);
	}
	
	@Test
	public void testLogAfterThrowingForGetMethod() {
		loggingAspect.logAfterThrowing(joinPoint, e);
	}
	@Test
	public void testLogAfterThrowingForGetMethod1() {
		loggingAspect.logAfterThrowing(joinPoint, e);
	}
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		pjp = new ProceedingJoinPoint() {

			@Override
			public String toShortString() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String toLongString() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getThis() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getTarget() {
				// TODO Auto-generated method stub
				return new Object();
			}

			@Override
			public StaticPart getStaticPart() {
				// TODO Auto-generated method stub
				return null;
			}


			@Override
			public String getKind() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object[] getArgs() {
				// TODO Auto-generated method stub
				return null;
			}


			@Override
			public Object proceed(Object[] args) throws Throwable {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object proceed() throws Throwable {
				// TODO Auto-generated method stub
				return null;
			}


			@Override
			public SourceLocation getSourceLocation() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public void set$AroundClosure(AroundClosure arc) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public Signature getSignature() {
				// TODO Auto-generated method stub
				return null;
			}
		};

		joinPoint = new JoinPoint() {

			@Override
			public String toShortString() {

				return "abc";
			}

			@Override
			public String toLongString() {
				// TODO Auto-generated method stub
				return "abc";
			}

			@Override
			public Object getThis() {
				// TODO Auto-generated method stub
				return new Object();
			}

			@Override
			public Object getTarget() {
				// TODO Auto-generated method stub
				return new Object();
			}

			@Override
			public StaticPart getStaticPart() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public SourceLocation getSourceLocation() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getKind() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object[] getArgs() {
				Object obj = new Object();
				return new Object[] { obj };
			}

			@Override
			public Signature getSignature() {
				// TODO Auto-generated method stub
				return null;
			}
		};
	}
}
