package com.finastra.essence.shared.web.rest;

import static com.finastra.essence.shared.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.persistence.EntityManager;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import com.finastra.essence.common.util.ElasticSearchRestClient;
import com.finastra.essence.shared.FbeSharedApp;
import com.finastra.essence.shared.domain.Currency;
import com.finastra.essence.shared.domain.CurrencyTranslation;
import com.finastra.essence.shared.repository.CurrencyRepository;
import com.finastra.essence.shared.service.CurrencyService;
import com.finastra.essence.shared.service.dto.CurrencyDTO;
import com.finastra.essence.shared.service.dto.CurrencyTranslationDTO;
import com.finastra.essence.shared.service.mapper.CurrencyMapper;
import com.finastra.essence.shared.service.mapper.CurrencyTranslationMapper;
import com.finastra.essence.shared.web.rest.errors.FBESharedResponseEntityExceptionHandler;

/**
 * Test class for the CurrencyResource REST controller.
 *
 * @see CurrencyResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = FbeSharedApp.class)
public class CurrencyResourceIntTest {

	private static final String DEFAULT_CURRENCY_ID = "01696b3f5a480001";
	private static final String UPDATED_CURRENCY_ID = "01696e3a5a480005";

	private static final String DEFAULT_CURRENCY_CODE = "USD";
	private static final String UPDATED_CURRENCY_CODE = "INR";

	private static final String DEFAULT_CURRENCY_ISO_CODE = "INR";
	private static final String UPDATED_CURRENCY_ISO_CODE = "USD";

	private static final String DEFAULT_CURRENCY_NUMERIC_CODE = "356";
	private static final String UPDATED_CURRENCY_NUMERIC_CODE = "036";

	private static final String DEFAULT_CURRENCY_ALTERNATIVE_CODE = "INR";
	private static final String UPDATED_CURRENCY_ALTERNATIVE_CODE = "AUD";

	private static final String DEFAULT_ICON_IMAGE = "NewYork";
	private static final String UPDATE_ICON_IMAGE = "NewYork";

	private static final boolean DEFAULT_SYSTEM_FLAG = true;
	private static final boolean UPDATED_SYSTEM_FLAG = false;

	private static final long DEFAULT_VERSION_NUMBER = 1L;
	private static final long UPDATED_VERSION_NUMBER = 2L;
	
	private static final String DEFAULT_TRANSLATION_ID = "01696a8e9bb10007";

	private static final String DEFAULT_LANGUAGE_ID = "0169618ce0a50004";

	private static final String DEFAULT_ENTITY_NAME = "INDIAN RUPEE";

	private static final String DEFAULT_ENTITY_DESC = "THE INDIAN RUPEE IS THE OFFICIAL  CURRENCY OF INDIA";


	@Autowired
	private CurrencyRepository currencyRepository;

	@Autowired
	private CurrencyMapper currencyMapper;
	@Autowired
	private CurrencyTranslationMapper currencyTranslationMapper;

	@Autowired
	private CurrencyService currencyService;

	@Autowired
	private MappingJackson2HttpMessageConverter jacksonMessageConverter;

	@Autowired
	private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

	@Autowired
	private FBESharedResponseEntityExceptionHandler exceptionTranslator;

	@Autowired
	private EntityManager em;

	private MockMvc restCurrencyMockMvc;

	private Currency currency;
	
	private CurrencyTranslation currencyTranslation;
	@Mock
	ElasticSearchRestClient elasticSearchRestClient;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		final CurrencyResource currencyResource = new CurrencyResource(currencyService);
		this.restCurrencyMockMvc = MockMvcBuilders.standaloneSetup(currencyResource)
				.setCustomArgumentResolvers(pageableArgumentResolver).setControllerAdvice(exceptionTranslator)
				.setConversionService(createFormattingConversionService()).setMessageConverters(jacksonMessageConverter)
				.build();

	}

	/**
	 * Create an entity for this test.
	 *
	 * This is a static method, as tests for other entities might also need it, if
	 * they test an entity which requires the current entity.
	 */
	public static Currency createEntity(EntityManager em) {
		Currency currency = new Currency().currencyId(DEFAULT_CURRENCY_ID).currencyCode(DEFAULT_CURRENCY_CODE)
				.currencyIsoCode(DEFAULT_CURRENCY_ISO_CODE).currencyNumericCode(DEFAULT_CURRENCY_NUMERIC_CODE)
				.currencyAlternativeCode(DEFAULT_CURRENCY_ALTERNATIVE_CODE).versionNumber(DEFAULT_VERSION_NUMBER)
				.currencyIconImageFile(DEFAULT_ICON_IMAGE);
		return currency;
	}
	
	/**
	 * Create an entity for this test.
	 *
	 * This is a static method, as tests for other entities might also need it, if
	 * they test an entity which requires the current entity.
	 */
	public static CurrencyTranslation createEntityForCurrencyTranslation(EntityManager em) {
		CurrencyTranslation currencyTranslation = new CurrencyTranslation().translationId(DEFAULT_TRANSLATION_ID)
				.languageId(DEFAULT_LANGUAGE_ID).entityName(DEFAULT_ENTITY_NAME)
				.entityDesc(DEFAULT_ENTITY_DESC);
		return currencyTranslation;
	}

	@Before
	public void initTest() {
		currency = createEntity(em);
		currencyTranslation = createEntityForCurrencyTranslation(em);
	}

	@Test
	@Transactional
	public void createCurrency() throws Exception {
		int databaseSizeBeforeCreate = currencyRepository.findAll().size();
		CurrencyDTO currencyDTO = currencyMapper.toDto(currency);
		currencyDTO.setCurrencyId(null);
		restCurrencyMockMvc.perform(post("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isCreated());
		// Validate the Currency in the database
		List<Currency> currencyList = currencyRepository.findAll();
		assertThat(currencyList).hasSize(databaseSizeBeforeCreate + 1);
		Currency testCurrency = currencyList.get(currencyList.size() - 1);
		assertThat(testCurrency.getCurrencyId()).isNotEqualTo(DEFAULT_CURRENCY_ID);
		assertThat(testCurrency.getCurrencyCode()).isEqualTo(DEFAULT_CURRENCY_CODE);
		assertThat(testCurrency.getCurrencyIsoCode()).isEqualTo(DEFAULT_CURRENCY_ISO_CODE);
		assertThat(testCurrency.getCurrencyNumericCode()).isEqualTo(DEFAULT_CURRENCY_NUMERIC_CODE);
		assertThat(testCurrency.getCurrencyAlternativeCode()).isEqualTo(DEFAULT_CURRENCY_ALTERNATIVE_CODE);
		assertThat(testCurrency.getIconImageFile()).isEqualTo(DEFAULT_ICON_IMAGE);
		assertThat(testCurrency.getVersionNumber()).isEqualTo(DEFAULT_VERSION_NUMBER);
		assertThat(testCurrency.isSystemFlag()).isNotEqualTo(DEFAULT_SYSTEM_FLAG);

		// Negative test case
		CurrencyDTO currencyDTOForFilure = currencyMapper.toDto(currency);
		currencyDTOForFilure.setCurrencyId(null);
		CurrencyTranslationDTO currencyTranslationDTO = new CurrencyTranslationDTO();
		currencyTranslationDTO.setCreatedBy("Manjunatha");
		currencyTranslationDTO.setEntityDesc("this is description");
		currencyTranslationDTO.setEntityName("Name of entity");
		currencyTranslationDTO.setLanguageId("1");
		currencyTranslationDTO.setLastModifiedBy("Reddy");
		currencyTranslationDTO.setTranslationId("translationId");
		Set<CurrencyTranslationDTO> currencyTranslations = new HashSet<CurrencyTranslationDTO>();
		currencyTranslations.add(currencyTranslationDTO);
		currencyDTOForFilure.setActiveFlag(true);
		currencyDTOForFilure.setCurrencyTranslations(currencyTranslations);
		restCurrencyMockMvc
				.perform(post("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
						.content(TestUtil.convertObjectToJsonBytes(currencyDTOForFilure)))
				.andExpect(status().isBadRequest());

	}
	@Test
	@Transactional
	public void doCurrencySearchByPOST() throws Exception {
		CurrencyDTO currencyDTO = currencyMapper.toDto(currency);
		currencyDTO.setCurrencyId(null);
		restCurrencyMockMvc.perform(post("/api/currency/search").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void createCurrencyWithExistingId() throws Exception {
		int databaseSizeBeforeCreate = currencyRepository.findAll().size();
		CurrencyDTO currencyDTO = currencyMapper.toDto(currency);
		restCurrencyMockMvc.perform(post("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());
		List<Currency> currencyList = currencyRepository.findAll();
		assertThat(currencyList).hasSize(databaseSizeBeforeCreate);
	}

	@Test
	@Transactional
	public void checkCurrencyIdIsRequired() throws Exception {
		int databaseSizeBeforeTest = currencyRepository.findAll().size();
		currency.setCurrencyId(null);
		CurrencyDTO currencyDTO = currencyMapper.toDto(currency);
		currencyDTO.setCurrencyNumericCode(null);
		restCurrencyMockMvc.perform(post("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());

		List<Currency> currencyList = currencyRepository.findAll();
		assertThat(currencyList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void checkCurrencyCodeIsRequired() throws Exception {
		int databaseSizeBeforeTest = currencyRepository.findAll().size();
		currency.setCurrencyCode(null);
		CurrencyDTO currencyDTO = currencyMapper.toDto(currency);

		restCurrencyMockMvc.perform(post("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());

		List<Currency> currencyList = currencyRepository.findAll();
		assertThat(currencyList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void checkCurrencyIsoCodeIsRequired() throws Exception {
		int databaseSizeBeforeTest = currencyRepository.findAll().size();
		currency.setCurrencyIsoCode(null);
		CurrencyDTO currencyDTO = currencyMapper.toDto(currency);
		restCurrencyMockMvc.perform(post("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());
		List<Currency> currencyList = currencyRepository.findAll();
		assertThat(currencyList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void checkCurrencyNumericCodeIsRequired() throws Exception {
		int databaseSizeBeforeTest = currencyRepository.findAll().size();
		currency.setCurrencyNumericCode(null);
		CurrencyDTO currencyDTO = currencyMapper.toDto(currency);
		restCurrencyMockMvc.perform(post("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());
		List<Currency> currencyList = currencyRepository.findAll();
		assertThat(currencyList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void checkSystemFlagIsRequired() throws Exception {
		int databaseSizeBeforeTest = currencyRepository.findAll().size();
		CurrencyDTO currencyDTO = currencyMapper.toDto(currency);
		restCurrencyMockMvc.perform(post("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());
		List<Currency> currencyList = currencyRepository.findAll();
		assertThat(currencyList).hasSize(databaseSizeBeforeTest);
	}

	@Test
	@Transactional
	public void getAllCurrencies() throws Exception {
		currencyRepository.saveAndFlush(currency);
		restCurrencyMockMvc.perform(get("/api/currency")).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(jsonPath("$.[*].currencyCode").value(hasItem(DEFAULT_CURRENCY_CODE.toString())))
				.andExpect(jsonPath("$.[*].currencyIsoCode").value(hasItem(DEFAULT_CURRENCY_ISO_CODE.toString())))
				.andExpect(jsonPath("$.[*].currencyNumericCode").value(hasItem(DEFAULT_CURRENCY_NUMERIC_CODE)))
				.andExpect(jsonPath("$.[*].currencyAlternativeCode")
						.value(hasItem(DEFAULT_CURRENCY_ALTERNATIVE_CODE.toString())));
	}

	@Test
	@Transactional
	public void getCurrency() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		restCurrencyMockMvc.perform(get("/api/currency/{id}", saveAndFlush.getCurrencyId())).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(jsonPath("$.currencyCode").value(DEFAULT_CURRENCY_CODE.toString()))
				.andExpect(jsonPath("$.currencyIsoCode").value(DEFAULT_CURRENCY_ISO_CODE.toString()))
				.andExpect(jsonPath("$.currencyNumericCode").value(DEFAULT_CURRENCY_NUMERIC_CODE))
				.andExpect(jsonPath("$.currencyAlternativeCode").value(DEFAULT_CURRENCY_ALTERNATIVE_CODE.toString()));
	}

	@Test
	@Transactional
	public void getCurrencyWithCode() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		restCurrencyMockMvc.perform(get("/api/currency/code/{currencyIsoCode}", saveAndFlush.getCurrencyIsoCode()))
				.andExpect(status().isOk());
	}

	// @Test
	@Transactional
	public void getNonExistingCurrency() throws Exception {
		// Get the currency
		restCurrencyMockMvc.perform(get("/api/currency/{id}", Long.MAX_VALUE)).andExpect(status().isNotFound());
	}

	@Test
	@Transactional
	public void updateCurrency() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		Currency updatedCurrency = currencyRepository.findById(saveAndFlush.getCurrencyId()).get();
		em.detach(updatedCurrency);
		updatedCurrency.currencyCode(UPDATED_CURRENCY_CODE).currencyIsoCode(UPDATED_CURRENCY_ISO_CODE)
				.currencyNumericCode(UPDATED_CURRENCY_NUMERIC_CODE)
				.currencyAlternativeCode(UPDATED_CURRENCY_ALTERNATIVE_CODE).versionNumber(UPDATED_VERSION_NUMBER)
				.currencyIconImageFile(UPDATE_ICON_IMAGE).setSystemFlag(UPDATED_SYSTEM_FLAG);
		updatedCurrency.setActiveFlag(true);
		CurrencyDTO currencyDTO = currencyMapper.toDto(updatedCurrency);
		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isOk());

	}

	@Test
	@Transactional
	public void updateCurrencyWithTranslation() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		Currency updatedCurrency = currencyRepository.findById(saveAndFlush.getCurrencyId()).get();
		em.detach(updatedCurrency);
		updatedCurrency.currencyCode(UPDATED_CURRENCY_CODE).currencyIsoCode(UPDATED_CURRENCY_ISO_CODE)
				.currencyNumericCode(UPDATED_CURRENCY_NUMERIC_CODE)
				.currencyAlternativeCode(UPDATED_CURRENCY_ALTERNATIVE_CODE).versionNumber(UPDATED_VERSION_NUMBER)
				.currencyIconImageFile(UPDATE_ICON_IMAGE).setSystemFlag(UPDATED_SYSTEM_FLAG);
		updatedCurrency.setActiveFlag(true);
		CurrencyTranslationDTO currencyTranslationDTO = new CurrencyTranslationDTO();
		currencyTranslationDTO.setCreatedBy("Manjunatha");
		currencyTranslationDTO.setEntityDesc("this is description");
		currencyTranslationDTO.setEntityName("Name of entity");
		currencyTranslationDTO.setLanguageId("1");
		currencyTranslationDTO.setLastModifiedBy("Reddy");
		currencyTranslationDTO.setTranslationId("translationId");
		Set<CurrencyTranslationDTO> currencyTranslations = new HashSet<CurrencyTranslationDTO>();
		currencyTranslations.add(currencyTranslationDTO);
		CurrencyDTO currencyDTO = currencyMapper.toDto(updatedCurrency);
		currencyDTO.setCurrencyTranslations(currencyTranslations);
		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isOk());
	}

	@Test
	@Transactional
	public void updateCurrencyWithActiveFlagFalse() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		Currency updatedCurrency = currencyRepository.findById(saveAndFlush.getCurrencyId()).get();
		em.detach(updatedCurrency);
		updatedCurrency.currencyCode(UPDATED_CURRENCY_CODE).currencyIsoCode(UPDATED_CURRENCY_ISO_CODE)
				.currencyNumericCode(UPDATED_CURRENCY_NUMERIC_CODE)
				.currencyAlternativeCode(UPDATED_CURRENCY_ALTERNATIVE_CODE).versionNumber(UPDATED_VERSION_NUMBER)
				.currencyIconImageFile(UPDATE_ICON_IMAGE).setSystemFlag(UPDATED_SYSTEM_FLAG);
		updatedCurrency.setActiveFlag(false);
		CurrencyDTO currencyDTO = currencyMapper.toDto(updatedCurrency);
		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void updateCurrencyWithBadRequest() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		Currency updatedCurrency = currencyRepository.findById(saveAndFlush.getCurrencyId()).get();
		em.detach(updatedCurrency);
		CurrencyDTO currencyDTO = currencyMapper.toDto(updatedCurrency);
		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void updateCurrencyToValidatePutCurrencyId() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		Currency updatedCurrency = currencyRepository.findById(saveAndFlush.getCurrencyId()).get();
		em.detach(updatedCurrency);
		updatedCurrency.currencyId(null).currencyCode(UPDATED_CURRENCY_CODE).currencyIsoCode(UPDATED_CURRENCY_ISO_CODE)
				.currencyNumericCode(UPDATED_CURRENCY_NUMERIC_CODE)
				.currencyAlternativeCode(UPDATED_CURRENCY_ALTERNATIVE_CODE).versionNumber(UPDATED_VERSION_NUMBER)
				.currencyIconImageFile(UPDATE_ICON_IMAGE).setSystemFlag(UPDATED_SYSTEM_FLAG);
		CurrencyDTO currencyDTO = currencyMapper.toDto(updatedCurrency);

		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());

	}

	@Test
	@Transactional
	public void updateCurrencyToValidateCurrencyIsoCode() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		Currency updatedCurrency = currencyRepository.findById(saveAndFlush.getCurrencyId()).get();
		em.detach(updatedCurrency);
		updatedCurrency.currencyId(UPDATED_CURRENCY_ID).currencyCode(UPDATED_CURRENCY_CODE).currencyIsoCode("_______")
				.currencyNumericCode(UPDATED_CURRENCY_NUMERIC_CODE)
				.currencyAlternativeCode(UPDATED_CURRENCY_ALTERNATIVE_CODE).versionNumber(UPDATED_VERSION_NUMBER)
				.currencyIconImageFile(UPDATE_ICON_IMAGE).setSystemFlag(UPDATED_SYSTEM_FLAG);
		CurrencyDTO currencyDTO = currencyMapper.toDto(updatedCurrency);

		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());

	}

	@Test
	@Transactional
	public void updateCurrencyToValidateCurrencyCode() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		Currency updatedCurrency = currencyRepository.findById(saveAndFlush.getCurrencyId()).get();
		em.detach(updatedCurrency);
		updatedCurrency.currencyId(UPDATED_CURRENCY_ID).currencyCode("______").currencyIsoCode(UPDATED_CURRENCY_CODE)
				.currencyNumericCode("001").currencyAlternativeCode(UPDATED_CURRENCY_ALTERNATIVE_CODE)
				.versionNumber(UPDATED_VERSION_NUMBER).currencyIconImageFile(UPDATE_ICON_IMAGE)
				.setSystemFlag(UPDATED_SYSTEM_FLAG);
		CurrencyDTO currencyDTO = currencyMapper.toDto(updatedCurrency);

		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());

	}

	@Test
	@Transactional
	public void updateCurrencyException() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		Currency updatedCurrency = currencyRepository.findById(saveAndFlush.getCurrencyId()).get();
		em.detach(updatedCurrency);
		updatedCurrency.currencyId(UPDATED_CURRENCY_ID).currencyCode(UPDATED_CURRENCY_CODE)
				.currencyIsoCode(UPDATED_CURRENCY_ISO_CODE).currencyNumericCode("001")
				.currencyAlternativeCode(UPDATED_CURRENCY_ALTERNATIVE_CODE).versionNumber(UPDATED_VERSION_NUMBER)
				.currencyIconImageFile(UPDATE_ICON_IMAGE).setSystemFlag(UPDATED_SYSTEM_FLAG);

		updatedCurrency.setActiveFlag(true);
		CurrencyDTO currencyDTO = currencyMapper.toDto(updatedCurrency);

		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());

	}

	@Test
	@Transactional
	public void updateCurrencyToValidateCurrencyNumericCode() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		Currency updatedCurrency = currencyRepository.findById(saveAndFlush.getCurrencyId()).get();
		em.detach(updatedCurrency);
		updatedCurrency.currencyId(UPDATED_CURRENCY_ID).currencyCode(UPDATED_CURRENCY_CODE)
				.currencyIsoCode(UPDATED_CURRENCY_CODE).currencyNumericCode("1")
				.currencyAlternativeCode(UPDATED_CURRENCY_ALTERNATIVE_CODE).versionNumber(UPDATED_VERSION_NUMBER)
				.currencyIconImageFile(UPDATE_ICON_IMAGE).setSystemFlag(UPDATED_SYSTEM_FLAG);
		CurrencyDTO currencyDTO = currencyMapper.toDto(updatedCurrency);

		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());

		updatedCurrency.currencyId(UPDATED_CURRENCY_ID).currencyCode(UPDATED_CURRENCY_CODE)
				.currencyIsoCode(UPDATED_CURRENCY_CODE).currencyNumericCode("12")
				.currencyAlternativeCode(UPDATED_CURRENCY_ALTERNATIVE_CODE).versionNumber(UPDATED_VERSION_NUMBER)
				.currencyIconImageFile(UPDATE_ICON_IMAGE).setSystemFlag(UPDATED_SYSTEM_FLAG);
		CurrencyDTO currencyDTO1 = currencyMapper.toDto(updatedCurrency);

		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO1))).andExpect(status().isBadRequest());

		updatedCurrency.currencyId(UPDATED_CURRENCY_ID).currencyCode(UPDATED_CURRENCY_CODE)
				.currencyIsoCode(UPDATED_CURRENCY_CODE).currencyNumericCode("ASASAS")
				.currencyAlternativeCode(UPDATED_CURRENCY_ALTERNATIVE_CODE).versionNumber(UPDATED_VERSION_NUMBER)
				.currencyIconImageFile(UPDATE_ICON_IMAGE).setSystemFlag(UPDATED_SYSTEM_FLAG);
		CurrencyDTO currencyDTO2 = currencyMapper.toDto(updatedCurrency);

		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO2))).andExpect(status().isBadRequest());

	}

	@Test
	@Transactional
	public void updateNonExistingCurrency() throws Exception {
		int databaseSizeBeforeUpdate = currencyRepository.findAll().size();
		CurrencyDTO currencyDTO = currencyMapper.toDto(currency);
		restCurrencyMockMvc.perform(put("/api/currency").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());
		List<Currency> currencyList = currencyRepository.findAll();
		assertThat(currencyList).hasSize(databaseSizeBeforeUpdate);
	}

	@Test
	@Transactional
	public void deleteCurrency() throws Exception {
		Currency saveAndFlush = currencyRepository.saveAndFlush(currency);
		int databaseSizeBeforeDelete = currencyRepository.findAll().size();
		restCurrencyMockMvc
				.perform(delete("/api/currency/{id}", saveAndFlush.getCurrencyId()).accept(TestUtil.APPLICATION_JSON_UTF8))
				.andExpect(status().isOk());
		List<Currency> currencyList = currencyRepository.findAll();
		assertThat(currencyList).hasSize(databaseSizeBeforeDelete);
	}

	@Test
	@Transactional
	public void currencySyncTest() throws Exception {
		CurrencyDTO currencyDTO = currencyMapper.toDto(currency);
		restCurrencyMockMvc.perform(post("/api/currency/elastic/syncData").contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(currencyDTO))).andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void equalsVerifier() throws Exception {
		TestUtil.equalsVerifier(Currency.class);
		Currency currency1 = new Currency();
		currency1.setCurrencyId(DEFAULT_CURRENCY_ID);
		Currency currency2 = new Currency();
		assertThat(currency1).isNotEqualTo(currency2);
		currency2.setCurrencyId(currency1.getCurrencyId());
		assertThat(currency1).isEqualTo(currency2);
		currency2.setCurrencyId(DEFAULT_CURRENCY_ID);
		assertThat(currency1).isEqualTo(currency2);
		currency1.setCurrencyId(null);
		assertThat(currency1).isNotEqualTo(currency2);
	}

	@Test
	@Transactional
	public void dtoEqualsVerifier() throws Exception {
		TestUtil.equalsVerifier(CurrencyDTO.class);
		CurrencyDTO currencyDTO1 = new CurrencyDTO();
		currencyDTO1.setCurrencyId(DEFAULT_CURRENCY_ID);
		CurrencyDTO currencyDTO2 = new CurrencyDTO();
		assertThat(currencyDTO1).isNotEqualTo(currencyDTO2);
		currencyDTO2.setCurrencyId(currencyDTO1.getCurrencyId());
		assertThat(currencyDTO1).isEqualTo(currencyDTO2);
		currencyDTO2.setCurrencyId(DEFAULT_CURRENCY_ID);
		assertThat(currencyDTO1).isEqualTo(currencyDTO2);
		currencyDTO1.setCurrencyId(null);
		assertThat(currencyDTO1).isNotEqualTo(currencyDTO2);
	}

	@Test
	@Transactional
	public void testEntityFromId() {
		assertThat(currencyMapper.fromId("42").equals("42"));
		assertThat(currencyMapper.fromId(null)).isNull();
		currencyMapper.toDto(currency);
		CurrencyDTO currencyDTO1 = new CurrencyDTO();
		List<CurrencyDTO> currencyDTOList = new ArrayList<CurrencyDTO>();
		List<Currency> currency = new ArrayList<Currency>();
		currencyDTO1.setCurrencyId(DEFAULT_CURRENCY_ID);
		currencyMapper.toEntity(currencyDTO1);
		currencyMapper.toEntity(currencyDTOList);
		currencyMapper.toDto(currency);
	}
	
	@Test
	@Transactional
	public void testcurrencyTranslationMapperEntityFromId() {
		assertThat(currencyTranslationMapper.fromId("42").equals("42"));
		assertThat(currencyTranslationMapper.fromId(null)).isNull();
		CurrencyTranslation currencyTranslation = new CurrencyTranslation();
		currencyTranslation.setCreatedBy("Manjunatha");
		currencyTranslation.setEntityDesc("this is description");
		currencyTranslation.setEntityName("Name of entity");
		currencyTranslation.setLanguageId("1");
		currencyTranslation.setLastModifiedBy("Reddy");
		currencyTranslation.setTranslationId("translationId");
		List<CurrencyTranslation> currencyTranslationList = new ArrayList<CurrencyTranslation>();
		 currencyTranslationMapper.toDto(currencyTranslation);
		 currencyTranslationMapper.toDto(currencyTranslationList);
		 currencyTranslationList.clear();
		 currencyTranslationMapper.toDto(currencyTranslationList);
		 
		 CurrencyTranslationDTO currencyTranslationDTO = new CurrencyTranslationDTO();
			currencyTranslationDTO.setCreatedBy("Manjunatha");
			currencyTranslationDTO.setEntityDesc("this is description");
			currencyTranslationDTO.setEntityName("Name of entity");
			currencyTranslationDTO.setLanguageId("1");
			currencyTranslationDTO.setLastModifiedBy("Reddy");
			currencyTranslationDTO.setTranslationId("translationId");
			List<CurrencyTranslationDTO> currencyTranslations = new ArrayList<CurrencyTranslationDTO>();
			currencyTranslations.add(currencyTranslationDTO);
			
			
		 currencyTranslationMapper.toEntity(currencyTranslationDTO);
		 currencyTranslationMapper.toEntity(currencyTranslations);
	}
}
