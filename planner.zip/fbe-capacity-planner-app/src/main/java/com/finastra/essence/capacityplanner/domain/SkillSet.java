package com.finastra.essence.capacityplanner.domain;

/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * A SkillSet.
 */
@Entity
@Table(name = "skill_set")
public class SkillSet extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "skill_set_id", columnDefinition = "char(36)", unique = true)
    private String skillSetId;

    @NotNull
    @Size(max = 36)
    @Column(name = "product_function_id", length = 36, nullable = false)
    private String productFunctionId;

    @NotNull
    @Size(max = 80)
    @Column(name = "skill_set_name", length = 80, nullable = false)
    private String skillSetName;

    @Size(max = 240)
    @Column(name = "skill_set_desc", length = 240)
    private String skillSetDesc;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "skill_set_id")
    private List<AppUser> appUsers;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove


    public List<AppUser> getAppUsers() {
        return appUsers;
    }

    public void setAppUsers(List<AppUser> appUsers) {
        this.appUsers = appUsers;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getSkillSetId() {
        return skillSetId;
    }

    public void setSkillSetId(String skillSetId) {
        this.skillSetId = skillSetId;
    }

    public String getProductFunctionId() {
        return productFunctionId;
    }

    public SkillSet productFunctionId(String productFunctionId) {
        this.productFunctionId = productFunctionId;
        return this;
    }

    public void setProductFunctionId(String productFunctionId) {
        this.productFunctionId = productFunctionId;
    }

    public String getSkillSetName() {
        return skillSetName;
    }

    public SkillSet skillSetName(String skillSetName) {
        this.skillSetName = skillSetName;
        return this;
    }

    public void setSkillSetName(String skillSetName) {
        this.skillSetName = skillSetName;
    }

    public String getSkillSetDesc() {
        return skillSetDesc;
    }

    public SkillSet skillSetDesc(String skillSetDesc) {
        this.skillSetDesc = skillSetDesc;
        return this;
    }

    public void setSkillSetDesc(String skillSetDesc) {
        this.skillSetDesc = skillSetDesc;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SkillSet skillSet = (SkillSet) o;
        if (skillSet.getSkillSetId() == null || getSkillSetId() == null) {
            return false;
        }
        return Objects.equals(getSkillSetId(), skillSet.getSkillSetId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getSkillSetId());
    }

    @Override
    public String toString() {
        return "SkillSet{" +
                "id=" + getSkillSetId() +
                ", productFunctionId='" + getProductFunctionId() + "'" +
                ", skillSetName='" + getSkillSetName() + "'" +
                ", skillSetDesc='" + getSkillSetDesc() + "'" +
                "}";
    }
}
