package com.finastra.essence.capacityplanner;
import java.util.ArrayList;
import java.util.List;

public class JIRAJQLBuilder {
	private String jql;
	private float startAt;
	private float maxResults;
	List<String> fields = new ArrayList<String>();

	public String getJql() {
		return jql;
	}

	public void setJql(String jql) {
		this.jql = jql;
	}

	public float getStartAt() {
		return startAt;
	}

	public void setStartAt(float startAt) {
		this.startAt = startAt;
	}

	public float getMaxResults() {
		return maxResults;
	}

	public void setMaxResults(float maxResults) {
		this.maxResults = maxResults;
	}
	
	

	@Override
	public String toString() {
		return "JqlSearchRequest [jql=" + jql + ", startAt=" + startAt + ", maxResults=" + maxResults + ", fields="
				+ fields + ", getJql()=" + getJql() + ", getStartAt()=" + getStartAt() + ", getMaxResults()="
				+ getMaxResults() + ", getFields()=" + getFields() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

	public List<String> getFields() {
		return fields;
	}

	public void setFields(List<String> fields) {
		this.fields = fields;
	}

}