package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.OrgJiraProject;
import com.finastra.essence.capacityplanner.repository.OrgJiraProjectRepository;
import com.finastra.essence.capacityplanner.service.OrgJiraProjectService;
import com.finastra.essence.capacityplanner.service.dto.OrgJiraProjectDTO;
import com.finastra.essence.capacityplanner.service.mapper.OrgJiraProjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing OrgJiraProject.
 */
@Service
@Transactional
public class OrgJiraProjectServiceImpl implements OrgJiraProjectService {

    private final Logger log = LoggerFactory.getLogger(OrgJiraProjectServiceImpl.class);
    /**
     * Attribute holding the reference for the org jira project repository.
     */
    private final OrgJiraProjectRepository orgJiraProjectRepository;
    /**
     * Attribute holding the reference for the org jira project mapper.
     */
    private final OrgJiraProjectMapper orgJiraProjectMapper;
    /**
     * Attribute holding the reference of error details.
     */
    private final ErrorDetails errorDetails = new ErrorDetails();

    /**
     * This is used to initialize the repository and mapper.
     *
     * @param orgJiraProjectRepository org jira project repository.
     * @param orgJiraProjectMapper     org jira project mapper.
     */
    public OrgJiraProjectServiceImpl(OrgJiraProjectRepository orgJiraProjectRepository, OrgJiraProjectMapper orgJiraProjectMapper) {
        this.orgJiraProjectRepository = orgJiraProjectRepository;
        this.orgJiraProjectMapper = orgJiraProjectMapper;
    }

    /**
     * Save a orgJiraProject.
     *
     * @param orgJiraProjectDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public OrgJiraProjectDTO save(OrgJiraProjectDTO orgJiraProjectDTO) {
        log.debug("Request to save OrgJiraProject : {}", orgJiraProjectDTO);
        validateIdDuringPostOperation(orgJiraProjectDTO);
        validateWhetherIdExists(orgJiraProjectDTO);
        try {
            OrgJiraProject orgJiraProject = orgJiraProjectMapper.toEntity(orgJiraProjectDTO);
            orgJiraProject = orgJiraProjectRepository.saveAndFlush(orgJiraProject);
            return orgJiraProjectMapper.toDto(orgJiraProject);

        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails, e);
        }
        catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }
    }

    private void validateWhetherIdExists(OrgJiraProjectDTO orgJiraProjectDTO) {
        if (!orgJiraProjectRepository.existsByProductOrgId(orgJiraProjectDTO.getProductOrgId())) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.NOT_FOUND));
            throw new UserDefinedException(errorDetails);
        }
    }

    private void validateIdDuringPostOperation(OrgJiraProjectDTO orgJiraProjectDTO) {
        if (null != orgJiraProjectDTO.getJiraProjectId() && !orgJiraProjectDTO.getJiraProjectId().isEmpty()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.AUTOGEN_ID));
            throw new UserDefinedException(errorDetails);
        }

    }

    @Override
    public OrgJiraProjectDTO update(OrgJiraProjectDTO orgJiraProjectDTO) {
        validateIdDuringPutOperation(orgJiraProjectDTO);
        validateWhetherIdExists(orgJiraProjectDTO);
        OrgJiraProject orgJiraProject;
        try {
            Optional<OrgJiraProject> orgJiraProjectRepositoryById = orgJiraProjectRepository.findById(orgJiraProjectDTO.getJiraProjectId());
            if (orgJiraProjectRepositoryById.isPresent()) {
                orgJiraProject = orgJiraProjectMapper.toEntity(orgJiraProjectDTO);
                if (orgJiraProject.equals(orgJiraProjectRepositoryById.get())) {
                    throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NO_CHANGE_FOUND));
                }
                else{
                    orgJiraProjectRepository.save(orgJiraProjectMapper.toEntity(orgJiraProjectDTO));
                }
            } else {
                throw new DataIntegrityViolationException("OrgJiraProject "+FBECapacityPlannerConstants.INVALID_ID);
            }
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }

        return orgJiraProjectMapper.toDto(orgJiraProject);
    }

    private void validateIdDuringPutOperation(OrgJiraProjectDTO orgJiraProjectDTO) {
        if (orgJiraProjectDTO.getJiraProjectId().isEmpty() && null == orgJiraProjectDTO.getJiraProjectId()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.PROVIDE_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * Get all the orgJiraProjects.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<OrgJiraProjectDTO> findAll(Pageable pageable) {
        log.debug("Request to get all OrgJiraProjects");
        return orgJiraProjectRepository.findAll(pageable)
                .map(orgJiraProjectMapper::toDto);
    }

    /**
     * This method is used to fetch a list of Product Organizations by Product Org Id.
     *
     * @param productOrgId the id of the Product Organization.
     * @return fetches the list of job functions by Product Org Id.
     */
    @Override
    public List<OrgJiraProjectDTO> findByProductOrgId(String productOrgId) {
        if (!orgJiraProjectRepository.existsByProductOrgId(productOrgId)) {
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }

        return orgJiraProjectMapper.toDto(orgJiraProjectRepository.findByProductOrgId(productOrgId));
    }

    /**
     * This method is used to check whether Product Org Id exists or not
     *
     * @param productOrgId the id of the product Organization
     * @return true if Product Organization exists
     * false if Product Organization does not exists.
     */
    @Override
    public boolean existsByProductOrgId(String productOrgId) {
        return orgJiraProjectRepository.existsByProductOrgId(productOrgId);
    }


    /**
     * Get one orgJiraProject by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<OrgJiraProjectDTO> findOne(String id) {
        log.debug("Request to get OrgJiraProject : {}", id);
        return orgJiraProjectRepository.findById(id)
                .map(orgJiraProjectMapper::toDto);
    }

    /**
     * Delete the orgJiraProject by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete OrgJiraProject : {}", id);
        Optional<OrgJiraProject> orgJiraProjectRepositoryById = orgJiraProjectRepository.findById(id);
        orgJiraProjectRepositoryById.ifPresent(jiraProject -> jiraProject.setActiveFlag(false));
    }
}
