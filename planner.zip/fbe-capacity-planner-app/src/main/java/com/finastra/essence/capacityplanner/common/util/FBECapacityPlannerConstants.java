/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.capacityplanner.common.util;

public enum FBECapacityPlannerConstants {
    /**
     * Attribute holding the message for internal server error.
     */
    INT_ERR_TITLE("The request could not be processed due to Internal server error."),
    /**
     * Attribute holding the message for Not Found.
     */
    NOT_FOUND("Not Found"),

    DATA_EXISTS("Data already exists"),
    /**
     * Attribute holding the message for invalid id.
     */
    INVALID_ID("Invalid Id"),
    /**
     *
     */
    USER_DOES_NOT_EXISTS("user does not exits"),
    /**
     * Attribute holding the message for Provide Id.
     */
    PROVIDE_VALID_ID("Provide valid Id "),
    /**
     *
     */
    PROVIDE_ID("Provide valid Id "),

    /**
     *
     */
    UNIQUE_VIOLATION("Data Already Exists"),
    /**
     * Attribute holding th error message for act pm date.
     */
    INVALID_ACT_PM_DATE("Act Pm End date must be greater than start date"),
    /**
     * Attribute holding the error message for act dev date
     */
    INVALID_ACT_DEV_DATE("Act Dev End date must be greater than start date"),
    /**
     * Attribute holding the error message for estimated test development.
     */
    INVALID_EST_TEST_DEV_DATE("Est Test Dev End date must be greater than start date"),
    /**
     * Attribute holding the error message for estimated development .
     */
    INVALID_EST_DEV_DATE("Est Dev End date must be greater than start date"),
    /**
     * Attribute holding the error message for act test date.
     */
    INVALID_ACT_TEST_DATE("Test Act Dev End date must be greater than start date"),
    /**
     * Attribute holding the error message for estimated pm date.
     */
    INVALID_EST_PM_DATE("Est Pm End date must be greater than start date"),
    /**
     * Attribute holding the message for business validation error.
     */
    BUESS_VALID_ERR("The request could not be processed due to business validation error."),
    /**
     *  Attribute holding the error message for auto generated id.
     */
    AUTOGEN_ID( " id is meant to be auto generated"),
    /**
     * Attribute holding the error message for existing user.
     */
    USER_EXISTS("User already exists"),
    /**
     * Attribute holding the error message while updating user.
     */
    NO_CHANGE_FOUND("No Change Found"),
    /**
     *  Attribute holding the error message when user id is null during update.
     */
    USER_ID_NULL("Provide User Id"),
    /**
     * Attribute holding the message for validation error.
     */
    VALID_ERR_TITLE("The request could not be processed due to Attribute holding the message for business validation error."),
    /**
     * Attribute holding the message for {ENTITY} validation failed.
     */

    VALID_ERR_DETAIL("{ENTITY} validation failed."),
	
	/**
     * Attribute holding the message for filter error
     */
	NOT_EMPTY("At least one filter needs to be pass."),
	
    /**
     * Attribute holding the message for error
     */
    ERROR("ERROR");


    private String value;

    @Override
    public String toString() {
        return value ;
    }

    FBECapacityPlannerConstants(String value) {
        this.value = value;
    }
}
