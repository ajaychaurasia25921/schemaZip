package com.finastra.essence.capacityplanner.domain;


/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import org.hibernate.annotations.GenericGenerator;

import com.finastra.essence.capacityplanner.service.dto.ProjectTaskDTO;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * This class is used to maintain  the details of the tasks handled by various projects.
 */
@Entity
@Table(name = "project_task")
public class ProjectTask extends AbstractAuditingCustomEntity implements Serializable {
    /**
     * Attribute holding the serial version UID.
     */
    private static final long serialVersionUID = 1L;
    /**
     * Attribute holding the id of the project task.
     */
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "project_task_id", columnDefinition = "char(36)", unique = true)
    private String projectTaskId;
    /**
     * Attribute holding the id of the product organization.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "product_org_id", length = 36, nullable = false)
    private String productOrgId;
    /**
     * Attribute holding the id of the product category.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "product_category_id", length = 36, nullable = false)
    private String productCategoryId;
    /**
     * Attribute holding the id of the product function.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "product_function_id", length = 36, nullable = false)
    private String productFunctionId;
    /**
     * Attribute holding the id of the task type.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "task_type_id", length = 36, nullable = false)
    private String taskTypeId;
    /**
     * Attribute holding the id of the task category.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "task_category_id", length = 36, nullable = false)
    private String taskCategoryId;
    /**
     * Attribute holding the id of the project.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "project_id", length = 36, nullable = false)
    private String projectId;
    /**
     * Attribute holding the id of the jira project.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "jira_project_id", length = 36, nullable = false)
    private String jiraProjectId;
    /**
     * Attribute holding the id of the complexity.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "complexity_id", length = 36, nullable = false)
    private String complexityId;
    /**
     * Attribute holding the id of the jira issue.
     */
    @NotNull
    @Column(name = "jira_issue_id", precision = 10, scale = 2, nullable = false)
    private BigDecimal jiraIssueId;
    /**
     * Attribute holding the JIRA: Project Key.
     */
    @NotNull
    @Size(max = 255)
    @Column(name = "jira_pkey", length = 255, nullable = false)
    private String jiraPkey;
    /**
     * Attribute holding the JIRA: Issue number.
     */
    @NotNull
    @Column(name = "jira_issue_num", precision = 10, scale = 2, nullable = false)
    private BigDecimal jiraIssueNum;
    /**
     * Attribute holding the JIRA: Project.
     */
    @NotNull
    @Column(name = "jira_project", precision = 10, scale = 2, nullable = false)
    private BigDecimal jiraProject;
    /**
     * Attribute holding the JIRA: Reporter.
     */
    @Size(max = 255)
    @Column(name = "jira_reporter", length = 255)
    private String jiraReporter;
    /**
     * Attribute holding the JIRA: Assignee.
     */
    @Size(max = 255)
    @Column(name = "jira_assignee", length = 255)
    private String jiraAssignee;
    /**
     * Attribute holding the JIRA: Issue type.
     */
    @Size(max = 255)
    @Column(name = "jira_issue_type", length = 255)
    private String jiraIssueType;
    /**
     * Attribute holding the JIRA: Priority.
     */
    @Size(max = 255)
    @Column(name = "jira_priority", length = 255)
    private String jiraPriority;
    /**
     * Attribute holding the JIRA: Resolution.
     */
    @Size(max = 255)
    @Column(name = "jira_resolution", length = 255)
    private String jiraResolution;
    /**
     * Attribute holding the JIRA: Issue status.
     */
    @Size(max = 255)
    @Column(name = "jira_issue_status", length = 255)
    private String jiraIssueStatus;
    /**
     * Attribute holding the JIRA: Estimated end date.
     */
    @Column(name = "jira_est_end_date")
    private LocalDate jiraEstEndDate;
    /**
     * Attribute holding the JIRA: Estimated start date.
     */
    @Column(name = "jira_est_start_date")
    private LocalDate jiraEstStartDate;
    /**
     * Attribute holding the JIRA: Updated timestamp.
     */
    @Column(name = "jira_updated")
    private ZonedDateTime jiraUpdated;
    /**
     * Attribute holding the JIRA: Created timestamp.
     */
    @Column(name = "jira_created")
    private ZonedDateTime jiraCreated;
    /**
     * Attribute holding the JIRA: Original time estimate.
     */
    @Column(name = "jira_time_org_estimate", precision = 10, scale = 2)
    private BigDecimal jiraTimeOrgEstimate;
    /**
     * Attribute holding the JIRA: time estimate.
     */
    @Column(name = "jira_time_estimate", precision = 10, scale = 2)
    private BigDecimal jiraTimeEstimate;
    /**
     * Attribute holding the JIRA: time spent.
     */
    @Column(name = "jira_time_spent", precision = 10, scale = 2)
    private BigDecimal jiraTimeSpent;
    /**
     * Attribute holding the JIRA: summary.
     */
    @Size(max = 255)
    @Column(name = "jira_summary", length = 255)
    private String jiraSummary;
    /**
     * Attribute holding the Identifier of the assignee.
     */
    @Size(max = 36)
    @Column(name = "assignee_user_id", length = 36)
    private String assigneeUserId;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    /**
     * This method is used to get the id of the jira project.
     * @return the id of the jira project.
     */
    public String getJiraProjectId() {
        return jiraProjectId;
    }
    /**
     * This method is used to set the id of the jira project.
     * @param jiraProjectId the id of the jira project.
     */
    public void setJiraProjectId(String jiraProjectId) {
        this.jiraProjectId = jiraProjectId;
    }
    /**
     * This method is used to get the id of the complexity.
     * @return the id of the complexity.
     */
    public String getComplexityId() {
        return complexityId;
    }
    /**
     * This method is used to set the id of the complexity.
     * @param complexityId the id of the complexity.
     */
    public void setComplexityId(String complexityId) {
        this.complexityId = complexityId;
    }
    /**
     * This method is used to get the id of the assignee user.
     * @return the id of the assignee user.
     */
    public String getAssigneeUserId() {
        return assigneeUserId;
    }
    /**
     * This method is used to set the id of the assignee user.
     * @param assigneeUserId the id of the assignee user.
     */
    public void setAssigneeUserId(String assigneeUserId) {
        this.assigneeUserId = assigneeUserId;
    }
    /**
     * This method is used to get the serial version UID.
     * @return the serial version UID.
     */
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
    /**
     * This method is used to get the id of the project task.
     * @return the id of the project task.
     */
    public String getProjectTaskId() {
        return projectTaskId;
    }
    /**
     * This method is used to set the id of the project task.
     * @param projectTaskId the id of the project task.
     */
    public void setProjectTaskId(String projectTaskId) {
        this.projectTaskId = projectTaskId;
    }
    /**
     * This method is used to get the id of the product organization.
     * @return the id of the product organization.
     */
    public String getProductOrgId() {
        return productOrgId;
    }
    /**
     * This method is used to set the id of the product organization.
     * @param productOrgId the id of the product organization.
     * @return the id of the product organization.
     */
    public ProjectTask productOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
        return this;
    }
    /**
     * This method is used to set the id of the product organization.
     * @param productOrgId the id of the product organization.
     */
    public void setProductOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
    }
    /**
     * This method is used to get the id of the product organization.
     * @return the id of the product organization.
     */
    public String getProductCategoryId() {
        return productCategoryId;
    }

    public ProjectTask productCategoryId(String productCategoryId) {
        this.productCategoryId = productCategoryId;
        return this;
    }

    public void setProductCategoryId(String productCategoryId) {
        this.productCategoryId = productCategoryId;
    }

    public String getProductFunctionId() {
        return productFunctionId;
    }

    public ProjectTask productFunctionId(String productFunctionId) {
        this.productFunctionId = productFunctionId;
        return this;
    }

    public void setProductFunctionId(String productFunctionId) {
        this.productFunctionId = productFunctionId;
    }

    public String getTaskTypeId() {
        return taskTypeId;
    }

    public ProjectTask taskTypeId(String taskTypeId) {
        this.taskTypeId = taskTypeId;
        return this;
    }

    public void setTaskTypeId(String taskTypeId) {
        this.taskTypeId = taskTypeId;
    }

    public String getTaskCategoryId() {
        return taskCategoryId;
    }

    public ProjectTask taskCategoryId(String taskCategoryId) {
        this.taskCategoryId = taskCategoryId;
        return this;
    }

    public void setTaskCategoryId(String taskCategoryId) {
        this.taskCategoryId = taskCategoryId;
    }

    public String getProjectId() {
        return projectId;
    }

    public ProjectTask projectId(String projectId) {
        this.projectId = projectId;
        return this;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public BigDecimal getJiraIssueId() {
        return jiraIssueId;
    }

    public ProjectTask jiraIssueId(BigDecimal jiraIssueId) {
        this.jiraIssueId = jiraIssueId;
        return this;
    }

    public void setJiraIssueId(BigDecimal jiraIssueId) {
        this.jiraIssueId = jiraIssueId;
    }

    public String getJiraPkey() {
        return jiraPkey;
    }

    public ProjectTask jiraPkey(String jiraPkey) {
        this.jiraPkey = jiraPkey;
        return this;
    }

    public void setJiraPkey(String jiraPkey) {
        this.jiraPkey = jiraPkey;
    }

    public BigDecimal getJiraIssueNum() {
        return jiraIssueNum;
    }

    public ProjectTask jiraIssueNum(BigDecimal jiraIssueNum) {
        this.jiraIssueNum = jiraIssueNum;
        return this;
    }

    public void setJiraIssueNum(BigDecimal jiraIssueNum) {
        this.jiraIssueNum = jiraIssueNum;
    }

    public BigDecimal getJiraProject() {
        return jiraProject;
    }

    public ProjectTask jiraProject(BigDecimal jiraProject) {
        this.jiraProject = jiraProject;
        return this;
    }

    public void setJiraProject(BigDecimal jiraProject) {
        this.jiraProject = jiraProject;
    }

    public String getJiraReporter() {
        return jiraReporter;
    }

    public ProjectTask jiraReporter(String jiraReporter) {
        this.jiraReporter = jiraReporter;
        return this;
    }

    public void setJiraReporter(String jiraReporter) {
        this.jiraReporter = jiraReporter;
    }

    public String getJiraAssignee() {
        return jiraAssignee;
    }

    public ProjectTask jiraAssignee(String jiraAssignee) {
        this.jiraAssignee = jiraAssignee;
        return this;
    }

    public void setJiraAssignee(String jiraAssignee) {
        this.jiraAssignee = jiraAssignee;
    }

    public String getJiraIssueType() {
        return jiraIssueType;
    }

    public ProjectTask jiraIssueType(String jiraIssueType) {
        this.jiraIssueType = jiraIssueType;
        return this;
    }

    public void setJiraIssueType(String jiraIssueType) {
        this.jiraIssueType = jiraIssueType;
    }

    public String getJiraPriority() {
        return jiraPriority;
    }

    public ProjectTask jiraPriority(String jiraPriority) {
        this.jiraPriority = jiraPriority;
        return this;
    }

    public void setJiraPriority(String jiraPriority) {
        this.jiraPriority = jiraPriority;
    }

    public String getJiraResolution() {
        return jiraResolution;
    }

    public ProjectTask jiraResolution(String jiraResolution) {
        this.jiraResolution = jiraResolution;
        return this;
    }

    public void setJiraResolution(String jiraResolution) {
        this.jiraResolution = jiraResolution;
    }

    public String getJiraIssueStatus() {
        return jiraIssueStatus;
    }

    public ProjectTask jiraIssueStatus(String jiraIssueStatus) {
        this.jiraIssueStatus = jiraIssueStatus;
        return this;
    }

    public void setJiraIssueStatus(String jiraIssueStatus) {
        this.jiraIssueStatus = jiraIssueStatus;
    }

    public LocalDate getJiraEstEndDate() {
        return jiraEstEndDate;
    }

    public ProjectTask jiraEstEndDate(LocalDate jiraEstEndDate) {
        this.jiraEstEndDate = jiraEstEndDate;
        return this;
    }

    public void setJiraEstEndDate(LocalDate jiraEstEndDate) {
        this.jiraEstEndDate = jiraEstEndDate;
    }

    public LocalDate getJiraEstStartDate() {
        return jiraEstStartDate;
    }

    public ProjectTask jiraEstStartDate(LocalDate jiraEstStartDate) {
        this.jiraEstStartDate = jiraEstStartDate;
        return this;
    }

    public void setJiraEstStartDate(LocalDate jiraEstStartDate) {
        this.jiraEstStartDate = jiraEstStartDate;
    }

    public ZonedDateTime getJiraUpdated() {
        return jiraUpdated;
    }

    public ProjectTask jiraUpdated(ZonedDateTime jiraUpdated) {
        this.jiraUpdated = jiraUpdated;
        return this;
    }

    public void setJiraUpdated(ZonedDateTime jiraUpdated) {
        this.jiraUpdated = jiraUpdated;
    }

    public ZonedDateTime getJiraCreated() {
        return jiraCreated;
    }

    public ProjectTask jiraCreated(ZonedDateTime jiraCreated) {
        this.jiraCreated = jiraCreated;
        return this;
    }

    public void setJiraCreated(ZonedDateTime jiraCreated) {
        this.jiraCreated = jiraCreated;
    }

    public BigDecimal getJiraTimeOrgEstimate() {
        return jiraTimeOrgEstimate;
    }

    public ProjectTask jiraTimeOrgEstimate(BigDecimal jiraTimeOrgEstimate) {
        this.jiraTimeOrgEstimate = jiraTimeOrgEstimate;
        return this;
    }

    public void setJiraTimeOrgEstimate(BigDecimal jiraTimeOrgEstimate) {
        this.jiraTimeOrgEstimate = jiraTimeOrgEstimate;
    }

    public BigDecimal getJiraTimeEstimate() {
        return jiraTimeEstimate;
    }

    public ProjectTask jiraTimeEstimate(BigDecimal jiraTimeEstimate) {
        this.jiraTimeEstimate = jiraTimeEstimate;
        return this;
    }

    public void setJiraTimeEstimate(BigDecimal jiraTimeEstimate) {
        this.jiraTimeEstimate = jiraTimeEstimate;
    }

    public BigDecimal getJiraTimeSpent() {
        return jiraTimeSpent;
    }

    public ProjectTask jiraTimeSpent(BigDecimal jiraTimeSpent) {
        this.jiraTimeSpent = jiraTimeSpent;
        return this;
    }

    public void setJiraTimeSpent(BigDecimal jiraTimeSpent) {
        this.jiraTimeSpent = jiraTimeSpent;
    }

    public String getJiraSummary() {
        return jiraSummary;
    }

    public void setJiraSummary(String jiraSummary) {
        this.jiraSummary = jiraSummary;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProjectTask that = (ProjectTask) o;
        return Objects.equals(projectTaskId, that.projectTaskId) &&
                Objects.equals(productOrgId, that.productOrgId) &&
                Objects.equals(productCategoryId, that.productCategoryId) &&
                Objects.equals(productFunctionId, that.productFunctionId) &&
                Objects.equals(taskTypeId, that.taskTypeId) &&
                Objects.equals(taskCategoryId, that.taskCategoryId) &&
                Objects.equals(projectId, that.projectId) &&
                Objects.equals(jiraIssueId, that.jiraIssueId) &&
                Objects.equals(jiraPkey, that.jiraPkey) &&
                Objects.equals(jiraIssueNum, that.jiraIssueNum) &&
                Objects.equals(jiraProject, that.jiraProject) &&
                Objects.equals(jiraReporter, that.jiraReporter) &&
                Objects.equals(jiraAssignee, that.jiraAssignee) &&
                Objects.equals(jiraIssueType, that.jiraIssueType) &&
                Objects.equals(jiraPriority, that.jiraPriority) &&
                Objects.equals(jiraResolution, that.jiraResolution) &&
                Objects.equals(jiraIssueStatus, that.jiraIssueStatus) &&
                Objects.equals(jiraEstEndDate, that.jiraEstEndDate) &&
                Objects.equals(jiraEstStartDate, that.jiraEstStartDate) &&
                Objects.equals(jiraUpdated, that.jiraUpdated) &&
                Objects.equals(jiraCreated, that.jiraCreated) &&
                Objects.equals(jiraTimeOrgEstimate, that.jiraTimeOrgEstimate) &&
                Objects.equals(jiraTimeEstimate, that.jiraTimeEstimate) &&
                Objects.equals(jiraTimeSpent, that.jiraTimeSpent) &&
                Objects.equals(jiraSummary, that.jiraSummary) &&
                Objects.equals(jiraProjectId, that.jiraProjectId) &&
                Objects.equals(complexityId, that.complexityId) &&
                Objects.equals(assigneeUserId, that.assigneeUserId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(projectTaskId, productOrgId, productCategoryId, productFunctionId, taskTypeId, taskCategoryId, projectId, jiraIssueId, jiraPkey, jiraIssueNum, jiraProject, jiraReporter, jiraAssignee, jiraIssueType, jiraPriority, jiraResolution, jiraIssueStatus, jiraEstEndDate, jiraEstStartDate, jiraUpdated, jiraCreated, jiraTimeOrgEstimate, jiraTimeEstimate, jiraTimeSpent, jiraSummary, jiraProjectId, complexityId, assigneeUserId);
    }

    @Override
    public String toString() {
        return "ProjectTask{" +
                "projectTaskId='" + projectTaskId + '\'' +
                ", productOrgId='" + productOrgId + '\'' +
                ", productCategoryId='" + productCategoryId + '\'' +
                ", productFunctionId='" + productFunctionId + '\'' +
                ", taskTypeId='" + taskTypeId + '\'' +
                ", taskCategoryId='" + taskCategoryId + '\'' +
                ", projectId='" + projectId + '\'' +
                ", jiraIssueId=" + jiraIssueId +
                ", jiraPkey='" + jiraPkey + '\'' +
                ", jiraIssueNum=" + jiraIssueNum +
                ", jiraProject=" + jiraProject +
                ", jiraReporter='" + jiraReporter + '\'' +
                ", jiraAssignee='" + jiraAssignee + '\'' +
                ", jiraIssueType='" + jiraIssueType + '\'' +
                ", jiraPriority='" + jiraPriority + '\'' +
                ", jiraResolution='" + jiraResolution + '\'' +
                ", jiraIssueStatus='" + jiraIssueStatus + '\'' +
                ", jiraEstEndDate=" + jiraEstEndDate +
                ", jiraEstStartDate=" + jiraEstStartDate +
                ", jiraUpdated=" + jiraUpdated +
                ", jiraCreated=" + jiraCreated +
                ", jiraTimeOrgEstimate=" + jiraTimeOrgEstimate +
                ", jiraTimeEstimate=" + jiraTimeEstimate +
                ", jiraTimeSpent=" + jiraTimeSpent +
                ", jiraSummary='" + jiraSummary + '\'' +
                ", jiraProjectId='" + jiraProjectId + '\'' +
                ", complexityId='" + complexityId + '\'' +
                ", assigneeUserId='" + assigneeUserId + '\'' +
                '}';
    }
}