package com.finastra.essence.capacityplanner.service.dto;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import io.github.jhipster.service.filter.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the AppProperty entity.
 */
public class AppPropertyCriteria implements Serializable {

    private BooleanFilter activeFlag;

    private StringFilter propertyId;

    private StringFilter propertyName;

    private StringFilter propertyDesc;

    private StringFilter propertyValueDataType;

    private StringFilter propertyValueText;

    private IntegerFilter propertyValueInteger;

    private BigDecimalFilter propertyValueDecimal;

    private StringFilter propertyValueFlag;


    public StringFilter getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(StringFilter propertyId) {
        this.propertyId = propertyId;
    }

    public StringFilter getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(StringFilter propertyName) {
        this.propertyName = propertyName;
    }

    public StringFilter getPropertyDesc() {
        return propertyDesc;
    }

    public void setPropertyDesc(StringFilter propertyDesc) {
        this.propertyDesc = propertyDesc;
    }

    public StringFilter getPropertyValueDataType() {
        return propertyValueDataType;
    }

    public void setPropertyValueDataType(StringFilter propertyValueDataType) {
        this.propertyValueDataType = propertyValueDataType;
    }

    public StringFilter getPropertyValueText() {
        return propertyValueText;
    }

    public void setPropertyValueText(StringFilter propertyValueText) {
        this.propertyValueText = propertyValueText;
    }

    public IntegerFilter getPropertyValueInteger() {
        return propertyValueInteger;
    }

    public void setPropertyValueInteger(IntegerFilter propertyValueInteger) {
        this.propertyValueInteger = propertyValueInteger;
    }

    public BigDecimalFilter getPropertyValueDecimal() {
        return propertyValueDecimal;
    }

    public void setPropertyValueDecimal(BigDecimalFilter propertyValueDecimal) {
        this.propertyValueDecimal = propertyValueDecimal;
    }

    public StringFilter getPropertyValueFlag() {
        return propertyValueFlag;
    }

    public void setPropertyValueFlag(StringFilter propertyValueFlag) {
        this.propertyValueFlag = propertyValueFlag;
    }

    public BooleanFilter getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(BooleanFilter activeFlag) {
        this.activeFlag = activeFlag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AppPropertyCriteria that = (AppPropertyCriteria) o;
        return Objects.equals(activeFlag, that.activeFlag) &&
                Objects.equals(propertyId, that.propertyId) &&
                Objects.equals(propertyName, that.propertyName) &&
                Objects.equals(propertyDesc, that.propertyDesc) &&
                Objects.equals(propertyValueDataType, that.propertyValueDataType) &&
                Objects.equals(propertyValueText, that.propertyValueText) &&
                Objects.equals(propertyValueInteger, that.propertyValueInteger) &&
                Objects.equals(propertyValueDecimal, that.propertyValueDecimal) &&
                Objects.equals(propertyValueFlag, that.propertyValueFlag);
    }

    @Override
    public int hashCode() {
        return Objects.hash(activeFlag, propertyId, propertyName, propertyDesc, propertyValueDataType, propertyValueText, propertyValueInteger, propertyValueDecimal, propertyValueFlag);
    }

    @Override
    public String toString() {
        return "AppPropertyCriteria{" +
                "activeFlag=" + activeFlag +
                ", propertyId=" + propertyId +
                ", propertyName=" + propertyName +
                ", propertyDesc=" + propertyDesc +
                ", propertyValueDataType=" + propertyValueDataType +
                ", propertyValueText=" + propertyValueText +
                ", propertyValueInteger=" + propertyValueInteger +
                ", propertyValueDecimal=" + propertyValueDecimal +
                ", propertyValueFlag=" + propertyValueFlag +
                '}';
    }
}