package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.AppUser;
import com.finastra.essence.capacityplanner.domain.JobFunction;
import com.finastra.essence.capacityplanner.repository.JobFunctionRepository;
import com.finastra.essence.capacityplanner.service.JobFunctionService;
import com.finastra.essence.capacityplanner.service.dto.JobFunctionDTO;
import com.finastra.essence.capacityplanner.service.mapper.JobFunctionMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing JobFunction.
 */
@Service
@Transactional
public class JobFunctionServiceImpl implements JobFunctionService {

    private final Logger log = LoggerFactory.getLogger(JobFunctionServiceImpl.class);
    /**
     * Attribute holding the reference for the job function repository.
     */
    private final JobFunctionRepository jobFunctionRepository;
    /**
     * Attribute holding the reference for job function mapper.
     */
    private final JobFunctionMapper jobFunctionMapper;

    /**
     * This is used to initialize the repository and mapper.
     * @param jobFunctionRepository job function repository.
     * @param jobFunctionMapper job function mapper.
     */
    public JobFunctionServiceImpl(JobFunctionRepository jobFunctionRepository, JobFunctionMapper jobFunctionMapper) {
        this.jobFunctionRepository = jobFunctionRepository;
        this.jobFunctionMapper = jobFunctionMapper;
    }

    /**
     * Save a jobFunction.
     *
     * @param jobFunctionDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public JobFunctionDTO save(JobFunctionDTO jobFunctionDTO) {
        log.debug("Request to save JobFunction : {}", jobFunctionDTO);
        JobFunction jobFunction = jobFunctionMapper.toEntity(jobFunctionDTO);
        jobFunction = jobFunctionRepository.save(jobFunction);
        return jobFunctionMapper.toDto(jobFunction);
    }

    /**
     * This method is used to fetch a list of job functions by Product Function Id.
     *
     * @param productFunctionId the id of the Product Function.
     * @return fetches the list of job functions by Product function Id.
     */
    @Override
    public List<JobFunctionDTO> findByProductFunctionId(String productFunctionId) {
        if(!jobFunctionRepository.existsByProductFunctionId(productFunctionId)){
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }
        return  jobFunctionMapper.toDto(jobFunctionRepository.findByProductFunctionId(productFunctionId));
    }


    /**
     * Get all the jobFunctions.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<JobFunctionDTO> findAll(Pageable pageable) {
        log.debug("Request to get all JobFunctions");
        return jobFunctionRepository.findAll(pageable)
                .map(jobFunctionMapper::toDto);
    }
    /**
     * This method is used to check whether Product Function Id exists or not
     *
     * @param productFunctionId the id of the product Function
     * @return true if Product Function exists
     * false if Product Function does not exists.
     */
    @Override
    public boolean existsByProductFunctionId(String productFunctionId) {
        return jobFunctionRepository.existsByProductFunctionId(productFunctionId);
    }


    /**
     * Get one jobFunction by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<JobFunctionDTO> findOne(String id) {
        log.debug("Request to get JobFunction : {}", id);
        return jobFunctionRepository.findById(id)
                .map(jobFunctionMapper::toDto);
    }

    /**
     * Delete the jobFunction by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete JobFunction : {}", id);
        Optional<JobFunction> jobFunctionRepositoryById = jobFunctionRepository.findById(id);
        jobFunctionRepositoryById.ifPresent(user -> user.setActiveFlag(false));
    }
}
