/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.capacityplanner.service;

import com.finastra.essence.capacityplanner.domain.AppProperty;
import com.finastra.essence.capacityplanner.domain.AppProperty_;
import com.finastra.essence.capacityplanner.repository.AppPropertyRepository;
import com.finastra.essence.capacityplanner.service.dto.AppPropertyCriteria;
import com.finastra.essence.capacityplanner.service.dto.AppPropertyDTO;
import com.finastra.essence.capacityplanner.service.mapper.AppPropertyMapper;
import io.github.jhipster.service.QueryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional(readOnly = true)
public class AppPropertyQueryService extends QueryService<AppProperty> {

    private final Logger log = LoggerFactory.getLogger(AppPropertyQueryService.class);

    private final AppPropertyRepository appPropertyRepository;

    private final AppPropertyMapper appPropertyMapper;

    public AppPropertyQueryService(AppPropertyRepository appPropertyRepository, AppPropertyMapper appPropertyMapper) {
        this.appPropertyRepository = appPropertyRepository;
        this.appPropertyMapper = appPropertyMapper;
    }


    @Transactional(readOnly = true)
    public Page<AppPropertyDTO> findByCriteria(AppPropertyCriteria filter, Pageable page) {
        log.debug("find by filter : {}, page: {}", filter, page);
        final Specification<AppProperty> specification = createSpecification(filter);
        return appPropertyRepository.findAll(specification, page)
                .map(appPropertyMapper::toDto);
    }

    private Specification<AppProperty> createSpecification(AppPropertyCriteria filter) {
        Specification<AppProperty> specification = Specification.where(null);
        if (filter != null) {
            if (filter.getActiveFlag() != null) {
                specification = specification.and(buildSpecification(filter.getActiveFlag(), AppProperty_.activeFlag));
            }
            if (filter.getPropertyDesc() != null) {
                specification = specification.and(buildStringSpecification(filter.getPropertyDesc(), AppProperty_.propertyDesc));
            }
            if (filter.getPropertyId() != null) {
                specification = specification.and(buildStringSpecification(filter.getPropertyId(), AppProperty_.propertyId));
            }
            if (filter.getPropertyName() != null) {
                specification = specification.and(buildStringSpecification(filter.getPropertyName(), AppProperty_.propertyName));
            }
            if (filter.getPropertyValueDataType() != null) {
                specification = specification.and(buildStringSpecification(filter.getPropertyValueDataType(), AppProperty_.propertyValueDataType));
            }
            if (filter.getPropertyValueText() != null) {
                specification = specification.and(buildStringSpecification(filter.getPropertyValueText(), AppProperty_.propertyValueText));
            }
            if (filter.getPropertyValueInteger() != null) {
                specification = specification.and(buildSpecification(filter.getPropertyValueInteger(), AppProperty_.propertyValueInteger));
            }
            if (filter.getPropertyValueDecimal() != null) {
                specification = specification.and(buildSpecification(filter.getPropertyValueDecimal(), AppProperty_.propertyValueDecimal));
            }
            if (filter.getPropertyValueFlag() != null) {
                specification = specification.and(buildStringSpecification(filter.getPropertyValueFlag(), AppProperty_.propertyValueFlag));
            }
        }
        return specification;
    }
}
