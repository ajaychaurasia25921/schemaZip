package com.finastra.essence.capacityplanner.web.rest;
import com.finastra.essence.capacityplanner.JIRAReportScheduler;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
import com.finastra.essence.capacityplanner.service.ProjectTaskQueryService;
import com.finastra.essence.capacityplanner.service.ProjectTaskService;
import com.finastra.essence.capacityplanner.service.dto.ProjectTaskCriteria;
import com.finastra.essence.capacityplanner.service.dto.ProjectTaskDTO;
import com.finastra.essence.capacityplanner.web.rest.errors.BadRequestAlertException;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import io.swagger.annotations.ApiOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing ProjectTask.
 */
@RestController
@RequestMapping("/api")
public class ProjectTaskResource {

    private final Logger log = LoggerFactory.getLogger(ProjectTaskResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppProjectTask";

    private final ProjectTaskService projectTaskService;

    private final ProjectTaskQueryService projectTaskQueryService;
    
    @Autowired
    public JIRAReportScheduler jIRAReportScheduler;

    public ProjectTaskResource(ProjectTaskService projectTaskService, ProjectTaskQueryService projectTaskQueryService) {
        this.projectTaskService = projectTaskService;
        this.projectTaskQueryService = projectTaskQueryService;
    }

    /**
     * POST  /project-tasks : Create a new projectTask.
     *
     * @param projectTaskDTO the projectTaskDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new projectTaskDTO, or with status 400 (Bad Request) if the projectTask has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/project-tasks")
    public ResponseEntity<ProjectTaskDTO> createProjectTask(@Valid @RequestBody ProjectTaskDTO projectTaskDTO) throws URISyntaxException {
        log.debug("REST request to save ProjectTask : {}", projectTaskDTO);
        ProjectTaskDTO result = projectTaskService.save(projectTaskDTO);
        return ResponseEntity.created(new URI("/api/project-tasks/" + result.getProjectTaskId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getProjectTaskId().toString()))
            .body(result);
    }

    /**
     * PUT  /project-tasks : Updates an existing projectTask.
     *
     * @param projectTaskDTO the projectTaskDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated projectTaskDTO,
     * or with status 400 (Bad Request) if the projectTaskDTO is not valid,
     * or with status 500 (Internal Server Error) if the projectTaskDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/project-tasks")
    public ResponseEntity<ProjectTaskDTO> updateProjectTask(@Valid @RequestBody ProjectTaskDTO projectTaskDTO) throws URISyntaxException {
        log.debug("REST request to update ProjectTask : {}", projectTaskDTO);
        ProjectTaskDTO result = projectTaskService.update(projectTaskDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, projectTaskDTO.getProjectTaskId().toString()))
            .body(result);
    }

    /**
     * GET  /project-tasks : get all the projectTasks.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of projectTasks in body
     */
    @GetMapping("/project-tasks")
    public ResponseEntity<List<ProjectTaskDTO>> getAllProjectTasks(Pageable pageable) {
        log.debug("REST request to get a page of ProjectTasks");
        Page<ProjectTaskDTO> page = projectTaskService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/project-tasks");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /project-tasks/:id : get the "id" projectTask.
     *
     * @param id the id of the projectTaskDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the projectTaskDTO, or with status 404 (Not Found)
     */
    @GetMapping("/project-tasks/{id}")
    public ResponseEntity<ProjectTaskDTO> getProjectTask(@PathVariable String id) {
        log.debug("REST request to get ProjectTask : {}", id);
        Optional<ProjectTaskDTO> projectTaskDTO = projectTaskService.findOne(id);
        return ResponseUtil.wrapOrNotFound(projectTaskDTO);
    }

    /**
     * {@code POST  /project-tasks/filter} : get all the projectTasks.
     *
     * @param pageable the pagination information.
     * @param filter the criteria which the requested entities should match.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of projectTasks in body.
     */
    @PostMapping("/project-tasks/filter")
    public ResponseEntity<List<ProjectTaskDTO>> getAllProjectTasks(@RequestBody ProjectTaskCriteria filter,String username, Pageable pageable) {
        log.debug("REST request to get ProjectTasks by criteria: {}", filter);
        Page<ProjectTaskDTO> page = projectTaskQueryService.findByCriteria(filter, pageable);
        projectTaskQueryService.JsonToCSV(page.getContent(),username);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page,"/api/project-tasks/filter");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * DELETE  /project-tasks/:id : delete the "id" projectTask.
     *
     * @param id the id of the projectTaskDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/project-tasks/{id}")
    public ResponseEntity<Void> deleteProjectTask(@PathVariable String id) {
        log.debug("REST request to delete ProjectTask : {}", id);
        projectTaskService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
    
    /**
     * Post /project-tasks/filter/syncData : DB will sync
     * with JIRA when this API called.
     *
     * @return return 200
     */
    @PostMapping("/project-tasks/jobTrigger/{jobName}")
    @ApiOperation("Synchronizing the JIRA tasks with DB.")
    public ResponseEntity<Void> jiraDetailsSync() {
    	jIRAReportScheduler.processJiraReport();
        return ResponseEntity.ok().headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME,null)).build();
    }
}
