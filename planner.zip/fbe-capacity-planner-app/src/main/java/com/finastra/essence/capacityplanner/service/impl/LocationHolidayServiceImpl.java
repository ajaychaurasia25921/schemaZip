package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.LocationHoliday;
import com.finastra.essence.capacityplanner.domain.LocationHoliday;
import com.finastra.essence.capacityplanner.repository.LocationHolidayRepository;
import com.finastra.essence.capacityplanner.repository.OrgLocationRepository;
import com.finastra.essence.capacityplanner.service.LocationHolidayService;
import com.finastra.essence.capacityplanner.service.dto.LocationHolidayDTO;
import com.finastra.essence.capacityplanner.service.mapper.LocationHolidayMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing {@link LocationHoliday}.
 */
@Service
@Transactional
public class LocationHolidayServiceImpl implements LocationHolidayService {

    private final Logger log = LoggerFactory.getLogger(LocationHolidayServiceImpl.class);

    private final LocationHolidayRepository locationHolidayRepository;

    private final OrgLocationRepository orgLocationRepository;

    private final LocationHolidayMapper locationHolidayMapper;

    private final ErrorDetails errorDetails = new ErrorDetails();

    public LocationHolidayServiceImpl(OrgLocationRepository orgLocationRepository, LocationHolidayRepository locationHolidayRepository, LocationHolidayMapper locationHolidayMapper) {
        this.orgLocationRepository = orgLocationRepository;
        this.locationHolidayRepository = locationHolidayRepository;
        this.locationHolidayMapper = locationHolidayMapper;
    }

    /**
     * Save a locationHoliday.
     *
     * @param locationHolidayDTO the entity to save.
     * @return the persisted entity.
     */
    @Override
    public LocationHolidayDTO save(LocationHolidayDTO locationHolidayDTO) {
        log.debug("Request to save LocationHoliday : {}", locationHolidayDTO);
        validateIdDuringPostOperation(locationHolidayDTO);
        validateWhetherIdExists(locationHolidayDTO);
        try {
            LocationHoliday locationHoliday = locationHolidayMapper.toEntity(locationHolidayDTO);
            locationHoliday = locationHolidayRepository.saveAndFlush(locationHoliday);
            return locationHolidayMapper.toDto(locationHoliday);
        }catch (DataIntegrityViolationException e){
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails,e);
        }
        catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }
    }

    private void validateWhetherIdExists(LocationHolidayDTO locationHolidayDTO) {
        if (!orgLocationRepository.existsById(locationHolidayDTO.getHolidayId())) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
        }
    }

    private void validateIdDuringPostOperation(LocationHolidayDTO locationHolidayDTO) {
        if (null != locationHolidayDTO.getHolidayId() && !locationHolidayDTO.getHolidayId().isEmpty()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.AUTOGEN_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    @Override
    public LocationHolidayDTO update(LocationHolidayDTO locationHolidayDTO) {
        validateIdDuringPutOperation(locationHolidayDTO);
        validateWhetherIdExists(locationHolidayDTO);
        LocationHoliday locationHoliday;
        try {
            Optional<LocationHoliday> locationHolidayRepositoryById = locationHolidayRepository.findById(locationHolidayDTO.getHolidayId());
            if (locationHolidayRepositoryById.isPresent()) {
                locationHoliday = locationHolidayMapper.toEntity(locationHolidayDTO);
                if (locationHoliday.equals(locationHolidayRepositoryById.get())) {
                    throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NO_CHANGE_FOUND));
                } else {
                    locationHolidayRepository.save(locationHolidayMapper.toEntity(locationHolidayDTO));
                }
            } else {
                throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NOT_FOUND));
            }
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }
    return locationHolidayMapper.toDto(locationHoliday);
    }

    private void validateIdDuringPutOperation(LocationHolidayDTO locationHolidayDTO) {
        if (locationHolidayDTO.getHolidayId().isEmpty() && null == locationHolidayDTO.getHolidayId()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.PROVIDE_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * Get all the locationHolidays.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<LocationHolidayDTO> findAll(Pageable pageable) {
        log.debug("Request to get all LocationHolidays");
        return locationHolidayRepository.findAll(pageable)
                .map(locationHolidayMapper::toDto);
    }


    /**
     * Get one locationHoliday by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<LocationHolidayDTO> findOne(String id) {
        log.debug("Request to get LocationHoliday : {}", id);
        return locationHolidayRepository.findById(id)
                .map(locationHolidayMapper::toDto);
    }

    /**
     * Delete the locationHoliday by id.
     *
     * @param id the id of the entity.
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete LocationHoliday : {}", id);
        Optional<LocationHoliday> locationHolidayRepositoryById = locationHolidayRepository.findById(id);
        locationHolidayRepositoryById.ifPresent(locationHoliday -> locationHoliday.setActiveFlag(false));
    }

    /**
     * This method is used to fetch list of location holidays by location Id.
     *
     * @param locationId the id of the location
     * @return list of location holidays.
     */
    @Override
    public List<LocationHolidayDTO> findByLocationId(String locationId) {
        if (!locationHolidayRepository.existsByLocationId(locationId)) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }
        return locationHolidayMapper.toDto(locationHolidayRepository.findByLocationId(locationId));
    }
}
