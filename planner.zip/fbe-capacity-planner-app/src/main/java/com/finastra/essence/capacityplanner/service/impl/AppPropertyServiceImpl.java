package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
import com.finastra.essence.capacityplanner.domain.AppProperty;
import com.finastra.essence.capacityplanner.repository.AppPropertyRepository;
import com.finastra.essence.capacityplanner.service.AppPropertyService;
import com.finastra.essence.capacityplanner.service.dto.AppPropertyDTO;
import com.finastra.essence.capacityplanner.service.mapper.AppPropertyMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing AppProperty.
 */
@Service
@Transactional
public class AppPropertyServiceImpl implements AppPropertyService {

    private final Logger log = LoggerFactory.getLogger(AppPropertyServiceImpl.class);

    private final AppPropertyRepository appPropertyRepository;

    private final AppPropertyMapper appPropertyMapper;

    public AppPropertyServiceImpl(AppPropertyRepository appPropertyRepository, AppPropertyMapper appPropertyMapper) {
        this.appPropertyRepository = appPropertyRepository;
        this.appPropertyMapper = appPropertyMapper;
    }

    /**
     * Save a appProperty.
     *
     * @param appPropertyDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public AppPropertyDTO save(AppPropertyDTO appPropertyDTO) {
        log.debug("Request to save AppProperty : {}", appPropertyDTO);
        AppProperty appProperty = appPropertyMapper.toEntity(appPropertyDTO);
        appProperty = appPropertyRepository.save(appProperty);
        return appPropertyMapper.toDto(appProperty);
    }

    /**
     * Get all the appProperties.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<AppPropertyDTO> findAll(Pageable pageable) {
        log.debug("Request to get all AppProperties");
        return appPropertyRepository.findAll(pageable)
                .map(appPropertyMapper::toDto);
    }


    /**
     * Get one appProperty by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<AppPropertyDTO> findOne(String id) {
        log.debug("Request to get AppProperty : {}", id);
        return appPropertyRepository.findById(id)
                .map(appPropertyMapper::toDto);
    }

    /**
     * Delete the appProperty by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete AppProperty : {}", id);
        appPropertyRepository.deleteById(id);
    }
    
	@Override
	public AppPropertyDTO findByPropertyName(String propertyName) {
		log.debug("Request to get AppProperty details : {}", propertyName);
		return appPropertyMapper.toDto(appPropertyRepository.findByPropertyName(propertyName));
	}
}
