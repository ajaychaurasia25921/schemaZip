/**
 * Data Transfer Objects.
 */
package com.finastra.essence.capacityplanner.service.dto;
