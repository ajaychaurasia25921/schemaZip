package com.finastra.essence.capacityplanner.service;

import com.finastra.essence.capacityplanner.common.KeycloakDomainResponse;

public interface KeycloakAdminService {
    void update(KeycloakDomainResponse keycloakAdminDTO);

}
