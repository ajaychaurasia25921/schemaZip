package com.finastra.essence.capacityplanner;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.Iterator;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.domain.OrgJiraProject;
import com.finastra.essence.capacityplanner.domain.ProjectTask;
import com.finastra.essence.capacityplanner.repository.OrgJiraProjectRepository;
import com.finastra.essence.capacityplanner.repository.ProjectTaskRepository;
import com.finastra.essence.capacityplanner.service.AppUserService;
import com.finastra.essence.capacityplanner.service.ProjectTaskService;
import com.finastra.essence.capacityplanner.service.dto.AppUserDTO;
import com.finastra.essence.capacityplanner.service.dto.ProjectTaskDTO;
import com.finastra.essence.capacityplanner.service.mapper.ProjectTaskMapper;

@Component
public class JIRADataProcessor {
	private static final Logger log = LoggerFactory.getLogger(JIRADataProcessor.class);

	@Autowired
	public ProjectTaskService projectTaskService;

	@Autowired
	public AppUserService appUserService;
	
	@Autowired
	ProjectTaskMapper projectTaskMapper;
	
	@Autowired
	ProjectTaskRepository projectTaskRepository;
	
	@Autowired
	OrgJiraProjectRepository orgJiraProjectRepository;
	
	/**
	 * Created ErrorDetails instance for storing error details.
	 */
	private final ErrorDetails errorDetails = new ErrorDetails();

	public void processData(ResponseEntity<String> jiraResponse) {
		BigDecimal jiraIssueId = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode actualObj = mapper.readTree(jiraResponse.getBody());
			JsonNode jsonNode = actualObj.get("issues");
			Iterator<JsonNode> childNodes = jsonNode.iterator();
			
			while (childNodes.hasNext()) {
				JsonNode htNode = childNodes.next();
				JsonNode fields = htNode.get("fields");
				JsonNode assignee = fields.get("assignee");
				JsonNode status = fields.get("status");
				JsonNode issuetype = fields.get("issuetype");
				JsonNode project = fields.get("project");
				JsonNode reporter = fields.get("reporter");
				JsonNode priority = fields.get("priority");
				JsonNode resolution = fields.get("resolution");
				jiraIssueId = new BigDecimal(htNode.get("id").textValue());
				
				ProjectTaskDTO projectTaskDTO = new ProjectTaskDTO();
				projectTaskDTO.setJiraIssueId(jiraIssueId);
				projectTaskDTO.setJiraAssignee(
						assignee.findPath("name").textValue());
				projectTaskDTO.setJiraIssueNum(new BigDecimal(htNode.get("id").textValue()));
				projectTaskDTO.setJiraIssueStatus(status.findPath("name").textValue());
				projectTaskDTO.setJiraIssueType(issuetype.findPath("name").textValue());
				projectTaskDTO.setJiraPkey(htNode.get("key").textValue());
				projectTaskDTO.setJiraPriority(priority.findPath("name").textValue());
				projectTaskDTO.setJiraReporter(reporter.findPath("displayName").textValue());
				projectTaskDTO.setJiraResolution(resolution.findPath("name").textValue());
				projectTaskDTO.setJiraTimeEstimate(fields.findPath("timeestimate").decimalValue());
				projectTaskDTO.setJiraTimeOrgEstimate(fields.findPath("timeoriginalestimate").decimalValue());
				projectTaskDTO.setJiraTimeSpent(fields.findPath("timespent").decimalValue());
				log.info("JiraProjectId >>>" + project.findPath("id").textValue());
				
				projectTaskDTO.setJiraProject(BigDecimal.valueOf(project.findPath("id").asDouble()));
				projectTaskDTO.setProjectId(project.findPath("id").textValue());
				log.info("Summary>>>" + fields.findPath("summary").textValue());
				projectTaskDTO.setJiraSummary(fields.findPath("summary").textValue());
				String jiraPkey = project.findPath("key").textValue();
				Optional<OrgJiraProject> findbyJiraPkey = orgJiraProjectRepository.findByJiraPkey(jiraPkey);
				if(findbyJiraPkey.isPresent())
					projectTaskDTO.setJiraProjectId(findbyJiraPkey.get().getJiraProjectId());
				log.info("JiraUpdated >>>" + ZonedDateTime.parse(DateFormat(fields.findPath("updated").textValue())));
				log.info("JiraCreated >>>" + ZonedDateTime.parse(DateFormat(fields.findPath("created").textValue())));
				projectTaskDTO.setJiraCreated(ZonedDateTime.parse(DateFormat(fields.findPath("created").textValue())));
				Optional<AppUserDTO> appuserDetails = appUserService.findbyJiraId(jiraIssueId);
				if (appuserDetails.isPresent()) {
					projectTaskDTO.setAssigneeUserId(appuserDetails.get().getUserId());
					String productOrgId = appuserDetails.get().getProductOrgId();
					projectTaskDTO.setProductOrgId(productOrgId);
					projectTaskDTO.setProductCategoryId(appuserDetails.get().getProductCategoryId());
					projectTaskDTO.setProductFunctionId(appuserDetails.get().getProductFunctionId());
					projectTaskDTO.setTaskCategoryId("25d085dd-8614-40eb-be91-95131061647a");
					projectTaskDTO.setTaskTypeId("c3ede33b-721b-4fd9-acb9-2697c39ea6b4");
					projectTaskDTO.setComplexityId("25d085dd-8614-40eb-be91-95131061647a");
					Optional<ProjectTaskDTO> projectTask = projectTaskService.findByJiraIssueId(jiraIssueId);
					if (projectTask.isPresent()) {
						log.info(">>>>>>>>> Record sent for updated successfully >>>>>>>>>>>");
						projectTaskDTO.setProjectTaskId(projectTask.get().getProjectTaskId());
					}

					saveData(projectTaskDTO);
				}
			}
		} catch (Exception e) {
			errorDetails.setDetail("Error in JIRA DATA Class while inserting data for jira Id : " + jiraIssueId);
			throw new UserDefinedException(errorDetails, e);
		}
	}

	private String DateFormat(String date) {
		return date = date.substring(0, date.indexOf('+') + 3) + ":"
				+ date.substring(date.indexOf('+') + 3, date.length());
	}

	private void saveData(ProjectTaskDTO projectTaskDTO) {
		ProjectTask projectTask = projectTaskMapper.toEntity(projectTaskDTO);
        projectTask = projectTaskRepository.saveAndFlush(projectTask);
		log.info(">>>>>>>>> Record inserted successfully >>>>>>>>>>>");
	}
}
