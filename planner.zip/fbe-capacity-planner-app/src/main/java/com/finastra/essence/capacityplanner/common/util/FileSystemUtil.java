package com.finastra.essence.capacityplanner.common.util;

import org.slf4j.Logger;

import java.io.File;
import java.io.FilenameFilter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.slf4j.LoggerFactory.getLogger;

public class FileSystemUtil {
    private static final Logger logger = getLogger(FileSystemUtil.class);

    public static String readFile(Path path) {
        try {
            List<String> stringList = Files.readAllLines(path.normalize(), StandardCharsets.UTF_8);
            StringBuilder sb = new StringBuilder();
            for (String s : stringList) {
                sb.append(s);
                sb.append(System.lineSeparator());
            }
            return sb.toString();
            /*byte[] allBytes = Files.readAllBytes(path.normalize());
            LOGGER.debug("Read file [" + path.getFileName() + "].");
            byte[] endodedFileContents = ESAPI.validator().getValidFileContent("IPD_FileValidation",allBytes,3000000,true);
            return new String(endodedFileContents);*/
        } catch (Exception exception) {
            logger.error("I/O or Security exception on file [" + path.getFileName() + "]", exception);
        }

        return null;
    }

}
