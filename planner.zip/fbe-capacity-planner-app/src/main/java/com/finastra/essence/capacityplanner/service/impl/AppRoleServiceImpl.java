package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.AppRole;
import com.finastra.essence.capacityplanner.repository.AppRoleRepository;
import com.finastra.essence.capacityplanner.service.AppRoleService;
import com.finastra.essence.capacityplanner.service.dto.AppRoleDTO;
import com.finastra.essence.capacityplanner.service.mapper.AppRoleMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing AppRole.
 */
@Service
@Transactional
public class AppRoleServiceImpl implements AppRoleService {

    private final Logger log = LoggerFactory.getLogger(AppRoleServiceImpl.class);

    private final AppRoleRepository appRoleRepository;

    private final AppRoleMapper appRoleMapper;

    /**
     * Created ErrorDetails instance for storing error details.
     */
    private final ErrorDetails errorDetails = new ErrorDetails();

    public AppRoleServiceImpl(AppRoleRepository appRoleRepository, AppRoleMapper appRoleMapper) {
        this.appRoleRepository = appRoleRepository;
        this.appRoleMapper = appRoleMapper;
    }

    /**
     * Save a appRole.
     *
     * @param appRoleDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public AppRoleDTO save(AppRoleDTO appRoleDTO) {
        log.debug("Request to save AppRole : {}", appRoleDTO);
        AppRole appRole = appRoleMapper.toEntity(appRoleDTO);
        validateRoleIdDuringPostOperation(appRoleDTO);
        try {
            appRole = appRoleRepository.saveAndFlush(appRole);
            return appRoleMapper.toDto(appRole);
        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails, e);
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }
    }

    private void validateRoleIdDuringPostOperation(AppRoleDTO appRoleDTO) {
        if (null != appRoleDTO.getRoleId() && !appRoleDTO.getRoleId().isEmpty()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.AUTOGEN_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * This method is used to update the application role
     *
     * @param appRoleDTO the entity to update.
     * @return updated application role.
     */
    @Override
    public AppRoleDTO update(AppRoleDTO appRoleDTO) {
        validateRoleIdToUpdateRole(appRoleDTO);
        AppRole appRole;
        try {
            Optional<AppRole> appRoleRepositoryById = appRoleRepository.findById(appRoleDTO.getRoleId());
            if (appRoleRepositoryById.isPresent()) {
                appRole = appRoleMapper.toEntity(appRoleDTO);
                if (appRole.equals(appRoleRepositoryById.get())) {
                    throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NO_CHANGE_FOUND));
                } else {
                    appRoleRepository.save(appRoleMapper.toEntity(appRoleDTO));
                }
            } else {
                throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            }
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);

        }

        return appRoleMapper.toDto(appRole);
    }

    /**
     * This method is used to validate the id given by the role during update operation.
     *
     * @param appRoleDTO the entity to validate
     */
    private void validateRoleIdToUpdateRole(AppRoleDTO appRoleDTO) {
        if (appRoleDTO.getRoleId().isEmpty() && null == appRoleDTO.getRoleId()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.PROVIDE_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * This method is used to validate user id during post operation.
     *
     * @param appRoleDTO the entity to validate.
     */
    private void validateRoleId(AppRoleDTO appRoleDTO) {
        if (null != appRoleDTO.getRoleId() && !appRoleDTO.getRoleId().isEmpty()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.AUTOGEN_ID));
            throw new UserDefinedException(errorDetails);
        }
    }


    /**
     * Get all the appRoles.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<AppRoleDTO> findAll(Pageable pageable) {
        log.debug("Request to get all AppRoles");
        return appRoleRepository.findAll(pageable)
                .map(appRoleMapper::toDto);
    }


    /**
     * Get one appRole by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<AppRoleDTO> findOne(String id) {
        log.debug("Request to get AppRole : {}", id);
        return appRoleRepository.findById(id)
                .map(appRoleMapper::toDto);
    }

    /**
     * Delete the appRole by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete AppRole : {}", id);
        appRoleRepository.deleteById(id);
    }
}
