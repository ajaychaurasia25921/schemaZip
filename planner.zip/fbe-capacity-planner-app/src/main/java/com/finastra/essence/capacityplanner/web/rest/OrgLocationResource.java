package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.OrgLocationService;
import com.finastra.essence.capacityplanner.service.dto.OrgLocationDTO;
import com.finastra.essence.capacityplanner.web.rest.errors.BadRequestAlertException;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing OrgLocation.
 */
@RestController
@RequestMapping("/api")
public class OrgLocationResource {

    private final Logger log = LoggerFactory.getLogger(OrgLocationResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppOrgLocation";

    private final OrgLocationService orgLocationService;

    public OrgLocationResource(OrgLocationService orgLocationService) {
        this.orgLocationService = orgLocationService;
    }

    /**
     * POST  /org-locations : Create a new orgLocation.
     *
     * @param orgLocationDTO the orgLocationDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new orgLocationDTO, or with status 400 (Bad Request) if the orgLocation has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/org-locations")
    public ResponseEntity<OrgLocationDTO> createOrgLocation(@Valid @RequestBody OrgLocationDTO orgLocationDTO) throws URISyntaxException {
        log.debug("REST request to save OrgLocation : {}", orgLocationDTO);
        OrgLocationDTO result = orgLocationService.save(orgLocationDTO);
        return ResponseEntity.created(new URI("/api/org-locations/" + result.getLocationId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getLocationId()))
                .body(result);
    }

    /**
     * PUT  /org-locations : Updates an existing orgLocation.
     *
     * @param orgLocationDTO the orgLocationDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated orgLocationDTO,
     * or with status 400 (Bad Request) if the orgLocationDTO is not valid,
     * or with status 500 (Internal Server Error) if the orgLocationDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/org-locations")
    public ResponseEntity<OrgLocationDTO> updateOrgLocation(@Valid @RequestBody OrgLocationDTO orgLocationDTO) throws URISyntaxException {
        log.debug("REST request to update OrgLocation : {}", orgLocationDTO);
        if (orgLocationDTO.getLocationId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        OrgLocationDTO result = orgLocationService.save(orgLocationDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, orgLocationDTO.getLocationId()))
                .body(result);
    }

    /**
     * GET  /org-locations : get all the orgLocations.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of orgLocations in body
     */
    @GetMapping("/org-locations/")
    public ResponseEntity<List<OrgLocationDTO>> getAllOrgLocations(@RequestParam(required = false) String productOrgId, Pageable pageable) {
        if (null != productOrgId && !productOrgId.isEmpty()) {
            return ResponseEntity.ok().body(orgLocationService.findByProductOrgId(productOrgId));
        }
        Page<OrgLocationDTO> page = orgLocationService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/org-locations");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /org-locations/:id : get the "id" orgLocation.
     *
     * @param id the id of the orgLocationDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the orgLocationDTO, or with status 404 (Not Found)
     */
    @GetMapping("/org-locations/{id}")
    public ResponseEntity<OrgLocationDTO> getOrgLocation(@PathVariable String id) {
        log.debug("REST request to get OrgLocation : {}", id);
        Optional<OrgLocationDTO> orgLocationDTO = orgLocationService.findOne(id);
        return ResponseUtil.wrapOrNotFound(orgLocationDTO);
    }

    /**
     * DELETE  /org-locations/:id : delete the "id" orgLocation.
     *
     * @param id the id of the orgLocationDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/org-locations/{id}")
    public ResponseEntity<Void> deleteOrgLocation(@PathVariable String id) {
        log.debug("REST request to delete OrgLocation : {}", id);
        orgLocationService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
