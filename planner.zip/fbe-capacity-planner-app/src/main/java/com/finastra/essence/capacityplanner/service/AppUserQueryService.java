/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.capacityplanner.service;

import com.finastra.essence.capacityplanner.domain.AppProperty;
import com.finastra.essence.capacityplanner.domain.AppUser;
import com.finastra.essence.capacityplanner.domain.AppUser_;
import com.finastra.essence.capacityplanner.repository.AppUserRepository;
import com.finastra.essence.capacityplanner.service.dto.AppUserCriteria;
import com.finastra.essence.capacityplanner.service.dto.AppUserDTO;
import com.finastra.essence.capacityplanner.service.mapper.AppUserMapper;
import io.github.jhipster.service.QueryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional(readOnly = true)
public class AppUserQueryService extends QueryService<AppUser> {

    private final Logger log = LoggerFactory.getLogger(AppUserQueryService.class);

    private final AppUserRepository appUserRepository;

    private final AppUserMapper appUserMapper;

    public AppUserQueryService(AppUserRepository appUserRepository, AppUserMapper appUserMapper) {
        this.appUserRepository = appUserRepository;
        this.appUserMapper = appUserMapper;
    }


    @Transactional(readOnly = true)
    public Page<AppUserDTO> findByCriteria(AppUserCriteria filter, Pageable page) {
        log.debug("find by filter : {}, page: {}", filter, page);
        final Specification<AppUser> specification = createSpecification(filter);
        return appUserRepository.findAll(specification, page)
                .map(appUserMapper::toDto);
    }
    
    private Specification<AppUser> createSpecification(AppUserCriteria filter) {
        Specification<AppUser> specification = Specification.where(null);
        if (filter != null) {
            if (filter.getActiveFlag() != null) {
                specification = specification.and(buildSpecification(filter.getActiveFlag(), AppUser_.activeFlag));
            }
            if (filter.getUserId() != null) {
                specification = specification.and(buildStringSpecification(filter.getUserId(), AppUser_.userId));
            }
            if (filter.getJiraUserName() != null) {
                specification = specification.and(buildStringSpecification(filter.getJiraUserName(), AppUser_.jiraUserName));
            }
            if (filter.getUserName() != null) {
                specification = specification.and(buildStringSpecification(filter.getUserName(), AppUser_.userName));
            }
            if (filter.getUserEmail() != null) {
                specification = specification.and(buildStringSpecification(filter.getUserEmail(), AppUser_.userEmail));
            }
            if (filter.getUserMobile() != null) {
                specification = specification.and(buildStringSpecification(filter.getUserMobile(), AppUser_.userMobile));
            }
            if (filter.getProductCategoryId() != null) {
                specification = specification.and(buildStringSpecification(filter.getProductCategoryId(), AppUser_.productCategoryId));
            }
            if (filter.getProductFunctionId() != null) {
                specification = specification.and(buildStringSpecification(filter.getProductFunctionId(), AppUser_.productFunctionId));
            }
            if (filter.getProductOrgId() != null) {
                specification = specification.and(buildStringSpecification(filter.getProductOrgId(), AppUser_.productOrgId));
            }
            if (filter.getSkillLevelId() != null) {
                specification = specification.and(buildStringSpecification(filter.getSkillLevelId(), AppUser_.skillLevelId));
            }
            if (filter.getSkillSetId() != null) {
                specification = specification.and(buildStringSpecification(filter.getSkillSetId(), AppUser_.skillSetId));
            }
            if (filter.getLocationId() != null) {
                specification = specification.and(buildStringSpecification(filter.getLocationId(), AppUser_.locationId));
            }
            if (filter.getJobFunctionId() != null) {
                specification = specification.and(buildStringSpecification(filter.getJobFunctionId(), AppUser_.jobFunctionId));
            }if (filter.getEncryptedAccessCode() != null) {
                specification = specification.and(buildStringSpecification(filter.getEncryptedAccessCode(), AppUser_.encryptedAccessCode));
            }if (filter.getManagerId() != null) {
                specification = specification.and(buildStringSpecification(filter.getManagerId(), AppUser_.managerId));
            }
            if (filter.getContributorFlag() != null) {
                specification = specification.and(buildStringSpecification(filter.getContributorFlag(), AppUser_.contributorFlag));
            }
            if (filter.getJiraId() != null) {
                specification = specification.and(buildRangeSpecification(filter.getJiraId(), AppUser_.jiraId));
            }
            if (filter.getEmployeeId() != null) {
                specification = specification.and(buildRangeSpecification(filter.getEmployeeId(), AppUser_.employeeId));
            }
        }
        return specification;
    }
}
