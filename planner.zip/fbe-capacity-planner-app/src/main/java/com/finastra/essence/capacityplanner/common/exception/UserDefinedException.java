/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.capacityplanner.common.exception;



/**
 * This class is super exception in Digital Branch Application.
 * All the user defined exceptions should extends this class
 * Created by bnandima on 2/28/2019.
 */
public class UserDefinedException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    /**
     *Error details used to store the parameters of error response structure.
     */
    private ErrorDetails errorDetails = new ErrorDetails();
    /**
     *Exception used to store the exception stack trace.
     */
    private Exception exception;
    
    /**
     *  //Default Constructor
     */
    public UserDefinedException() {
        super();
    }

    /**
     * parameterized constructor
     * @param errorDetails the detailed error message.
     */
    public UserDefinedException(ErrorDetails errorDetails) {
        super();
        this.errorDetails = errorDetails;
    }

    /**
     * parameterized constructor
     * @param errorDetails the detailed error message
     * @param exception the exception details
     */
    public UserDefinedException(ErrorDetails errorDetails, Exception exception) {
        this.errorDetails = errorDetails;
        this.exception=exception;
    }

    
    /**
     * This is a getter which gets the attributes of the ErrorDetails
     * contains the information about respective user exception.
     *
     * @return the attributes of the user exceptions.
     */
    public ErrorDetails getErrorDetails() {
        return errorDetails;
    }

    /**
     * This is a setter which sets the attributes of the ErrorDetails
     * to respective user exception.
     *
     * @param errorDetails the user exception set to the ErrorDetails.
     */
    public void setErrorDetails(ErrorDetails errorDetails) {
        this.errorDetails = errorDetails;
    }
    
    /**
	 * @return the exception
	 */
	public Exception getException() {
		return exception;
	}


}
