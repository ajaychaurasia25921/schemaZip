/**
 * Service layer beans.
 */
package com.finastra.essence.capacityplanner.service;
