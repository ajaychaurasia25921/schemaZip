package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.ProjectTask;
import com.finastra.essence.capacityplanner.repository.*;
import com.finastra.essence.capacityplanner.service.ProjectTaskService;
import com.finastra.essence.capacityplanner.service.dto.ProjectTaskDTO;
import com.finastra.essence.capacityplanner.service.mapper.ProjectTaskMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing ProjectTask.
 */
@Service
@Transactional
public class ProjectTaskServiceImpl implements ProjectTaskService {

    private final Logger log = LoggerFactory.getLogger(ProjectTaskServiceImpl.class);

    private final ProjectTaskRepository projectTaskRepository;

    private final ProductOrgRepository productOrgRepository;

    private final ProductCategoryRepository productCategoryRepository;

    private final ProductFunctionRepository productFunctionRepository;

    private final OrgTaskTypeRepository orgTaskTypeRepository;

    private final OrgTaskCategoryRepository orgTaskCategoryRepository;

    private final OrgJiraProjectRepository orgJiraProjectRepository;

    private final OrgProjectRepository orgProjectRepository;

    private final TaskComplexityRepository taskComplexityRepository;

    private final AppUserRepository appUserRepository;

    private final ProjectTaskMapper projectTaskMapper;
    /**
     * Attribute holding the reference of the error details.
     */
    private final ErrorDetails errorDetails = new ErrorDetails();

    public ProjectTaskServiceImpl(ProjectTaskRepository projectTaskRepository, ProductOrgRepository productOrgRepository, ProductCategoryRepository productCategoryRepository, ProductFunctionRepository productFunctionRepository, OrgTaskTypeRepository orgTaskTypeRepository, OrgTaskCategoryRepository orgTaskCategoryRepository, OrgJiraProjectRepository orgJiraProjectRepository, OrgProjectRepository orgProjectRepository, TaskComplexityRepository taskComplexityRepository, AppUserRepository appUserRepository, ProjectTaskMapper projectTaskMapper) {
        this.projectTaskRepository = projectTaskRepository;
        this.productOrgRepository = productOrgRepository;
        this.productCategoryRepository = productCategoryRepository;
        this.productFunctionRepository = productFunctionRepository;
        this.orgTaskTypeRepository = orgTaskTypeRepository;
        this.orgTaskCategoryRepository = orgTaskCategoryRepository;
        this.orgJiraProjectRepository = orgJiraProjectRepository;
        this.orgProjectRepository = orgProjectRepository;
        this.taskComplexityRepository = taskComplexityRepository;
        this.appUserRepository = appUserRepository;
        this.projectTaskMapper = projectTaskMapper;
    }

    /**
     * Save a projectTask.
     *
     * @param projectTaskDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public ProjectTaskDTO save(ProjectTaskDTO projectTaskDTO) {
        log.debug("Request to save ProjectTask : {}", projectTaskDTO);
        validateIdDuringPostOperation(projectTaskDTO);
        //validateWhetherIdExists(projectTaskDTO);
        try {
            ProjectTask projectTask = projectTaskMapper.toEntity(projectTaskDTO);
            projectTask = projectTaskRepository.saveAndFlush(projectTask);
            return projectTaskMapper.toDto(projectTask);

        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails, e);
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * @param projectTaskDTO
     */
    private void validateWhetherIdExists(ProjectTaskDTO projectTaskDTO) {
        List<String> errorMessage = new ArrayList<>();
        if (!productOrgRepository.existsById(projectTaskDTO.getProductOrgId())) {
            errorMessage.add("productOrgId");
        }
        if (!productCategoryRepository.existsById(projectTaskDTO.getProductCategoryId())) {
            errorMessage.add("productCategoryId");
        }
        if (!productFunctionRepository.existsById(projectTaskDTO.getProductFunctionId())) {
            errorMessage.add("productFunctionId");
        }
        if (!orgTaskTypeRepository.existsByProductOrgId(projectTaskDTO.getTaskTypeId())) {
            errorMessage.add("orgTaskTypeId");
        }
        if (!orgTaskCategoryRepository.existsById(projectTaskDTO.getTaskCategoryId())) {
            errorMessage.add("taskCategoryId");
        }
        if (!orgProjectRepository.existsById(projectTaskDTO.getProjectId())) {
            errorMessage.add("projectId");
        }
        if (!orgJiraProjectRepository.existsById(projectTaskDTO.getJiraProjectId())) {
            errorMessage.add("jiraProjectId");
        }
        if (!taskComplexityRepository.existsById(projectTaskDTO.getComplexityId())) {
            errorMessage.add("taskComplexityId");
        }
        if (!appUserRepository.existsById(projectTaskDTO.getAssigneeUserId())) {
            errorMessage.add("assigneeUserId");
        }
        if (!errorMessage.isEmpty()) {
            errorDetails.setDetail("The dependency(s) doesn't exist :" + errorMessage);
            throw new UserDefinedException(errorDetails);

        }
    }

    /**
     * @param projectTaskDTO
     */
    private void validateIdDuringPostOperation(ProjectTaskDTO projectTaskDTO) {
        if (null != projectTaskDTO.getProjectTaskId() && !projectTaskDTO.getProjectTaskId().isEmpty()) {
            errorDetails.setDetail("ProjectTaskId " + FBECapacityPlannerConstants.AUTOGEN_ID);
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * @param projectTaskDTO the entity to update
     * @return
     */
    @Override
    public ProjectTaskDTO update(ProjectTaskDTO projectTaskDTO) {
        log.debug("Request to update ProjectTask : {}", projectTaskDTO);
        validateIdDuringPutOperation(projectTaskDTO);
        //validateWhetherIdExists(projectTaskDTO);
        try {
            Optional<ProjectTask> projectTaskRepositoryById = projectTaskRepository.findById(projectTaskDTO.getProjectTaskId());
            if (projectTaskRepositoryById.isPresent()) {
                ProjectTask projectTask = projectTaskMapper.toEntity(projectTaskDTO);
                if (projectTask.equals(projectTaskRepositoryById.get())) {
                    throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NO_CHANGE_FOUND));
                }
            } else {
                throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            }
        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails, e);
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }

        return projectTaskMapper.toDto(projectTaskRepository.save(projectTaskMapper.toEntity(projectTaskDTO)));
    }

    /**
     * @param projectTaskDTO
     */
    private void validateIdDuringPutOperation(ProjectTaskDTO projectTaskDTO) {
        if (projectTaskDTO.getProjectTaskId().isEmpty() && null == projectTaskDTO.getProjectTaskId()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.PROVIDE_ID));
            throw new UserDefinedException(errorDetails);
        }

    }


    /**
     * Get all the projectTasks.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<ProjectTaskDTO> findAll(Pageable pageable) {
        log.debug("Request to get all ProjectTasks");
        return projectTaskRepository.findAll(pageable)
                .map(projectTaskMapper::toDto);
    }

    /**
     * Get one projectTask by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<ProjectTaskDTO> findOne(String id) {
        log.debug("Request to get ProjectTask : {}", id);
        return projectTaskRepository.findById(id)
                .map(projectTaskMapper::toDto);
    }

    @Override
    public Optional<ProjectTaskDTO> findByJiraId(BigDecimal id) {
        log.debug("Request to get ProjectTask : {}", id);
        return projectTaskRepository.findByJiraIssueId(id)
                .map(projectTaskMapper::toDto);
    }


    /**
     * Delete the projectTask by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete ProjectTask : {}", id);
        Optional<ProjectTask> projectTaskRepositoryById = projectTaskRepository.findById(id);
      //  projectTaskRepositoryById.ifPresent(projectTask -> projectTask.setActiveFlag(false));
    }
    
    @Override
    public Optional<ProjectTaskDTO> findByJiraIssueId(BigDecimal jiraIssueId) {
        log.debug("Request to get ProjectTask : {}", jiraIssueId);
        return projectTaskRepository.findByJiraIssueId(jiraIssueId)
                .map(projectTaskMapper::toDto);
    }

}
