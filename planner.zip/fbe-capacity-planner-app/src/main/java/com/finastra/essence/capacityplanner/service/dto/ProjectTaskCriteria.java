package com.finastra.essence.capacityplanner.service.dto;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import io.github.jhipster.service.filter.BigDecimalFilter;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.StringFilter;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the ProjectTask entity.
 */
public class ProjectTaskCriteria  implements Serializable {

    private BooleanFilter activeFlag;

    private StringFilter projectTaskId;

    private StringFilter productOrgId;

    private StringFilter productCategoryId;

    private StringFilter productFunctionId;

    private StringFilter taskTypeId;

    private StringFilter taskCategoryId;

    private StringFilter projectId;

    private BigDecimalFilter jiraIssueId;

    private StringFilter jiraPkey;

    private BigDecimalFilter jiraIssueNum;

    private BigDecimalFilter jiraProject;

    private StringFilter jiraProjectId;

    private StringFilter jiraReporter;

    private StringFilter jiraAssignee;

    private StringFilter jiraIssueType;

    private StringFilter jiraPriority;

    private StringFilter jiraResolution;

    private StringFilter jiraIssueStatus;

    private BigDecimalFilter jiraTimeOrgEstimate;

    private BigDecimalFilter jiraTimeEstimate;

    private BigDecimalFilter jiraTimeSpent;

    private StringFilter jiraSummary;

    public StringFilter getJiraProjectId() {
        return jiraProjectId;
    }

    public void setJiraProjectId(StringFilter jiraProjectId) {
        this.jiraProjectId = jiraProjectId;
    }

    public StringFilter getJiraSummary() {
        return jiraSummary;
    }

    public void setJiraSummary(StringFilter jiraSummary) {
        this.jiraSummary = jiraSummary;
    }

    public StringFilter getProjectTaskId() {
        return projectTaskId;
    }

    public void setProjectTaskId(StringFilter projectTaskId) {
        this.projectTaskId = projectTaskId;
    }

    public StringFilter getProductOrgId() {
        return productOrgId;
    }

    public void setProductOrgId(StringFilter productOrgId) {
        this.productOrgId = productOrgId;
    }

    public StringFilter getProductCategoryId() {
        return productCategoryId;
    }

    public void setProductCategoryId(StringFilter productCategoryId) {
        this.productCategoryId = productCategoryId;
    }

    public StringFilter getProductFunctionId() {
        return productFunctionId;
    }

    public void setProductFunctionId(StringFilter productFunctionId) {
        this.productFunctionId = productFunctionId;
    }

    public StringFilter getTaskTypeId() {
        return taskTypeId;
    }

    public void setTaskTypeId(StringFilter taskTypeId) {
        this.taskTypeId = taskTypeId;
    }

    public StringFilter getTaskCategoryId() {
        return taskCategoryId;
    }

    public void setTaskCategoryId(StringFilter taskCategoryId) {
        this.taskCategoryId = taskCategoryId;
    }

    public StringFilter getProjectId() {
        return projectId;
    }

    public void setProjectId(StringFilter projectId) {
        this.projectId = projectId;
    }

    public BigDecimalFilter getJiraIssueId() {
        return jiraIssueId;
    }

    public void setJiraIssueId(BigDecimalFilter jiraIssueId) {
        this.jiraIssueId = jiraIssueId;
    }

    public StringFilter getJiraPkey() {
        return jiraPkey;
    }

    public void setJiraPkey(StringFilter jiraPkey) {
        this.jiraPkey = jiraPkey;
    }

    public BigDecimalFilter getJiraIssueNum() {
        return jiraIssueNum;
    }

    public void setJiraIssueNum(BigDecimalFilter jiraIssueNum) {
        this.jiraIssueNum = jiraIssueNum;
    }

    public BigDecimalFilter getJiraProject() {
        return jiraProject;
    }

    public void setJiraProject(BigDecimalFilter jiraProject) {
        this.jiraProject = jiraProject;
    }

    public StringFilter getJiraReporter() {
        return jiraReporter;
    }

    public void setJiraReporter(StringFilter jiraReporter) {
        this.jiraReporter = jiraReporter;
    }

    public StringFilter getJiraAssignee() {
        return jiraAssignee;
    }

    public void setJiraAssignee(StringFilter jiraAssignee) {
        this.jiraAssignee = jiraAssignee;
    }

    public StringFilter getJiraIssueType() {
        return jiraIssueType;
    }

    public void setJiraIssueType(StringFilter jiraIssueType) {
        this.jiraIssueType = jiraIssueType;
    }

    public StringFilter getJiraPriority() {
        return jiraPriority;
    }

    public void setJiraPriority(StringFilter jiraPriority) {
        this.jiraPriority = jiraPriority;
    }

    public StringFilter getJiraResolution() {
        return jiraResolution;
    }

    public void setJiraResolution(StringFilter jiraResolution) {
        this.jiraResolution = jiraResolution;
    }

    public StringFilter getJiraIssueStatus() {
        return jiraIssueStatus;
    }

    public void setJiraIssueStatus(StringFilter jiraIssueStatus) {
        this.jiraIssueStatus = jiraIssueStatus;
    }

    public BigDecimalFilter getJiraTimeOrgEstimate() {
        return jiraTimeOrgEstimate;
    }

    public void setJiraTimeOrgEstimate(BigDecimalFilter jiraTimeOrgEstimate) {
        this.jiraTimeOrgEstimate = jiraTimeOrgEstimate;
    }

    public BigDecimalFilter getJiraTimeEstimate() {
        return jiraTimeEstimate;
    }

    public void setJiraTimeEstimate(BigDecimalFilter jiraTimeEstimate) {
        this.jiraTimeEstimate = jiraTimeEstimate;
    }

    public BigDecimalFilter getJiraTimeSpent() {
        return jiraTimeSpent;
    }

    public void setJiraTimeSpent(BigDecimalFilter jiraTimeSpent) {
        this.jiraTimeSpent = jiraTimeSpent;
    }

    public BooleanFilter getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(BooleanFilter activeFlag) {
        this.activeFlag = activeFlag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProjectTaskCriteria that = (ProjectTaskCriteria) o;
        return Objects.equals(activeFlag, that.activeFlag) &&
            Objects.equals(projectTaskId, that.projectTaskId) &&
            Objects.equals(productOrgId, that.productOrgId) &&
            Objects.equals(productCategoryId, that.productCategoryId) &&
            Objects.equals(productFunctionId, that.productFunctionId) &&
            Objects.equals(taskTypeId, that.taskTypeId) &&
            Objects.equals(taskCategoryId, that.taskCategoryId) &&
            Objects.equals(projectId, that.projectId) &&
            Objects.equals(jiraIssueId, that.jiraIssueId) &&
            Objects.equals(jiraPkey, that.jiraPkey) &&
            Objects.equals(jiraIssueNum, that.jiraIssueNum) &&
            Objects.equals(jiraProject, that.jiraProject) &&
            Objects.equals(jiraProjectId, that.jiraProjectId) &&
            Objects.equals(jiraReporter, that.jiraReporter) &&
            Objects.equals(jiraAssignee, that.jiraAssignee) &&
            Objects.equals(jiraIssueType, that.jiraIssueType) &&
            Objects.equals(jiraPriority, that.jiraPriority) &&
            Objects.equals(jiraResolution, that.jiraResolution) &&
            Objects.equals(jiraIssueStatus, that.jiraIssueStatus) &&
            Objects.equals(jiraTimeOrgEstimate, that.jiraTimeOrgEstimate) &&
            Objects.equals(jiraTimeEstimate, that.jiraTimeEstimate) &&
            Objects.equals(jiraTimeSpent, that.jiraTimeSpent) &&
            Objects.equals(jiraSummary, that.jiraSummary);
    }

    @Override
    public int hashCode() {
        return Objects.hash(activeFlag, projectTaskId, productOrgId, productCategoryId, productFunctionId, taskTypeId, taskCategoryId, projectId, jiraIssueId, jiraPkey, jiraIssueNum, jiraProject, jiraProjectId, jiraReporter, jiraAssignee, jiraIssueType, jiraPriority, jiraResolution, jiraIssueStatus, jiraTimeOrgEstimate, jiraTimeEstimate, jiraTimeSpent, jiraSummary);
    }

    @Override
    public String toString() {
        return "ProjectTaskCriteria{" +
            "activeFlag=" + activeFlag +
            ", projectTaskId=" + projectTaskId +
            ", productOrgId=" + productOrgId +
            ", productCategoryId=" + productCategoryId +
            ", productFunctionId=" + productFunctionId +
            ", taskTypeId=" + taskTypeId +
            ", taskCategoryId=" + taskCategoryId +
            ", projectId=" + projectId +
            ", jiraIssueId=" + jiraIssueId +
            ", jiraPkey=" + jiraPkey +
            ", jiraIssueNum=" + jiraIssueNum +
            ", jiraProject=" + jiraProject +
            ", jiraProjectId=" + jiraProjectId +
            ", jiraReporter=" + jiraReporter +
            ", jiraAssignee=" + jiraAssignee +
            ", jiraIssueType=" + jiraIssueType +
            ", jiraPriority=" + jiraPriority +
            ", jiraResolution=" + jiraResolution +
            ", jiraIssueStatus=" + jiraIssueStatus +
            ", jiraTimeOrgEstimate=" + jiraTimeOrgEstimate +
            ", jiraTimeEstimate=" + jiraTimeEstimate +
            ", jiraTimeSpent=" + jiraTimeSpent +
            ", jiraSummary=" + jiraSummary +
            '}';
    }
}
