package com.finastra.essence.capacityplanner.domain;


/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * A AppProperty.
 */
@Entity
@Table(name = "app_property")
public class AppProperty extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "property_id", columnDefinition = "char(36)", unique = true)
    private String propertyId;

    @NotNull
    @Size(max = 80)
    @Column(name = "property_name", length = 80, nullable = false)
    private String propertyName;

    @Size(max = 240)
    @Column(name = "property_desc", length = 240)
    private String propertyDesc;

    @NotNull
    @Size(max = 1)
    @Column(name = "property_value_data_type", length = 1, nullable = false)
    private String propertyValueDataType;

    @Size(max = 240)
    @Column(name = "property_value_text", length = 240)
    private String propertyValueText;

    @Column(name = "property_value_integer")
    private Integer propertyValueInteger;


    @Column(name = "property_value_decimal", precision = 10, scale = 2)
    private BigDecimal propertyValueDecimal;

    @Size(max = 1)
    @Column(name = "property_value_flag", length = 1)
    private String propertyValueFlag;


    @Column(name = "property_value_date")
    private LocalDate propertyValueDate;


    @Column(name = "property_value_datetime")
    private ZonedDateTime propertyValueDatetime;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String  getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(String propertyId) {
        this.propertyId = propertyId;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public AppProperty propertyName(String propertyName) {
        this.propertyName = propertyName;
        return this;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getPropertyDesc() {
        return propertyDesc;
    }

    public AppProperty propertyDesc(String propertyDesc) {
        this.propertyDesc = propertyDesc;
        return this;
    }

    public void setPropertyDesc(String propertyDesc) {
        this.propertyDesc = propertyDesc;
    }

    @JsonIgnore
    public String getPropertyValueDataType() {
        return propertyValueDataType;
    }

    public AppProperty propertyValueDataType(String propertyValueDataType) {
        this.propertyValueDataType = propertyValueDataType;
        return this;
    }

    public void setPropertyValueDataType(String propertyValueDataType) {
        this.propertyValueDataType = propertyValueDataType;
    }

    public String getPropertyValueText() {
        return propertyValueText;
    }

    public AppProperty propertyValueText(String propertyValueText) {
        this.propertyValueText = propertyValueText;
        return this;
    }

    public void setPropertyValueText(String propertyValueText) {
        this.propertyValueText = propertyValueText;
    }

    public Integer getPropertyValueInteger() {
        return propertyValueInteger;
    }

    public AppProperty propertyValueInteger(Integer propertyValueInteger) {
        this.propertyValueInteger = propertyValueInteger;
        return this;
    }

    public void setPropertyValueInteger(Integer propertyValueInteger) {
        this.propertyValueInteger = propertyValueInteger;
    }

    public BigDecimal getPropertyValueDecimal() {
        return propertyValueDecimal;
    }

    public AppProperty propertyValueDecimal(BigDecimal propertyValueDecimal) {
        this.propertyValueDecimal = propertyValueDecimal;
        return this;
    }

    public void setPropertyValueDecimal(BigDecimal propertyValueDecimal) {
        this.propertyValueDecimal = propertyValueDecimal;
    }

    public String getPropertyValueFlag() {
        return propertyValueFlag;
    }

    public AppProperty propertyValueFlag(String propertyValueFlag) {
        this.propertyValueFlag = propertyValueFlag;
        return this;
    }

    public void setPropertyValueFlag(String propertyValueFlag) {
        this.propertyValueFlag = propertyValueFlag;
    }

    public LocalDate getPropertyValueDate() {
        return propertyValueDate;
    }

    public AppProperty propertyValueDate(LocalDate propertyValueDate) {
        this.propertyValueDate = propertyValueDate;
        return this;
    }

    public void setPropertyValueDate(LocalDate propertyValueDate) {
        this.propertyValueDate = propertyValueDate;
    }

    public ZonedDateTime getPropertyValueDatetime() {
        return propertyValueDatetime;
    }

    public AppProperty propertyValueDatetime(ZonedDateTime propertyValueDatetime) {
        this.propertyValueDatetime = propertyValueDatetime;
        return this;
    }

    public void setPropertyValueDatetime(ZonedDateTime propertyValueDatetime) {
        this.propertyValueDatetime = propertyValueDatetime;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AppProperty appProperty = (AppProperty) o;
        if (appProperty.getPropertyId() == null || getPropertyId() == null) {
            return false;
        }
        return Objects.equals(getPropertyId(), appProperty.getPropertyId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getPropertyId());
    }

    @Override
    public String toString() {
        return "AppProperty{" +
            "propertyId=" + getPropertyId() +
            ", propertyName='" + getPropertyName() + "'" +
            ", propertyDesc='" + getPropertyDesc() + "'" +
            ", propertyValueDataType='" + getPropertyValueDataType() + "'" +
            ", propertyValueText='" + getPropertyValueText() + "'" +
            ", propertyValueInteger=" + getPropertyValueInteger() +
            ", propertyValueDecimal=" + getPropertyValueDecimal() +
            ", propertyValueFlag='" + getPropertyValueFlag() + "'" +
            ", propertyValueDate='" + getPropertyValueDate() + "'" +
            ", propertyValueDatetime='" + getPropertyValueDatetime() + "'" +
            "}";
    }
}
