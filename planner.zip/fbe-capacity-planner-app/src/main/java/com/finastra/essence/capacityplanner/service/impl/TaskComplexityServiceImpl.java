package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.domain.TaskComplexity;
import com.finastra.essence.capacityplanner.repository.TaskComplexityRepository;
import com.finastra.essence.capacityplanner.service.TaskComplexityService;
import com.finastra.essence.capacityplanner.service.dto.TaskComplexityDTO;
import com.finastra.essence.capacityplanner.service.mapper.TaskComplexityMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 * Service Implementation for managing {@link TaskComplexity}.
 */
@Service
@Transactional
public class TaskComplexityServiceImpl implements TaskComplexityService {

    private final Logger log = LoggerFactory.getLogger(TaskComplexityServiceImpl.class);

    private final TaskComplexityRepository taskComplexityRepository;

    private final TaskComplexityMapper taskComplexityMapper;

    public TaskComplexityServiceImpl(TaskComplexityRepository taskComplexityRepository, TaskComplexityMapper taskComplexityMapper) {
        this.taskComplexityRepository = taskComplexityRepository;
        this.taskComplexityMapper = taskComplexityMapper;
    }

    /**
     * Save a taskComplexity.
     *
     * @param taskComplexityDTO the entity to save.
     * @return the persisted entity.
     */
    @Override
    public TaskComplexityDTO save(TaskComplexityDTO taskComplexityDTO) {
        log.debug("Request to save TaskComplexity : {}", taskComplexityDTO);
        TaskComplexity taskComplexity = taskComplexityMapper.toEntity(taskComplexityDTO);
        taskComplexity = taskComplexityRepository.save(taskComplexity);
        return taskComplexityMapper.toDto(taskComplexity);
    }

    /**
     * Get all the taskComplexities.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<TaskComplexityDTO> findAll(Pageable pageable) {
        log.debug("Request to get all TaskComplexities");
        return taskComplexityRepository.findAll(pageable)
                .map(taskComplexityMapper::toDto);
    }


    /**
     * Get one taskComplexity by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<TaskComplexityDTO> findOne(String id) {
        log.debug("Request to get TaskComplexity : {}", id);
        return taskComplexityRepository.findById(id)
                .map(taskComplexityMapper::toDto);
    }

    /**
     * Delete the taskComplexity by id.
     *
     * @param id the id of the entity.
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete TaskComplexity : {}", id);
        Optional<TaskComplexity> taskComplexityRepositoryById = taskComplexityRepository.findById(id);
        taskComplexityRepositoryById.ifPresent(taskComplexity -> taskComplexity.setActiveFlag(false));
    }
}
