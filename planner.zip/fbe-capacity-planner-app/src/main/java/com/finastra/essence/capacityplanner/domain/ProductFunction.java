package com.finastra.essence.capacityplanner.domain;


/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * A ProductFunction.
 */
@Entity
@Table(name = "product_function")
public class ProductFunction extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "product_function_id", columnDefinition = "char(36)", unique = true)
    private String productFunctionId;

    @NotNull
    @Size(max = 80)
    @Column(name = "product_function_name", length = 80, nullable = false)
    private String productFunctionName;

    @Size(max = 240)
    @Column(name = "product_function_desc", length = 240)
    private String productFunctionDesc;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "product_function_id")
    private List<AppUser> appUsers;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove


    public List<AppUser> getAppUsers() {
        return appUsers;
    }

    public void setAppUsers(List<AppUser> appUsers) {
        this.appUsers = appUsers;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getProductFunctionId() {
        return productFunctionId;
    }

    public void setProductFunctionId(String productFunctionId) {
        this.productFunctionId = productFunctionId;
    }

    public String getProductFunctionName() {
        return productFunctionName;
    }

    public ProductFunction productFunctionName(String productFunctionName) {
        this.productFunctionName = productFunctionName;
        return this;
    }

    public void setProductFunctionName(String productFunctionName) {
        this.productFunctionName = productFunctionName;
    }

    public String getProductFunctionDesc() {
        return productFunctionDesc;
    }

    public ProductFunction productFunctionDesc(String productFunctionDesc) {
        this.productFunctionDesc = productFunctionDesc;
        return this;
    }

    public void setProductFunctionDesc(String productFunctionDesc) {
        this.productFunctionDesc = productFunctionDesc;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ProductFunction productFunction = (ProductFunction) o;
        if (productFunction.getProductFunctionId() == null || getProductFunctionId() == null) {
            return false;
        }
        return Objects.equals(getProductFunctionId(), productFunction.getProductFunctionId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getProductFunctionId());
    }

    @Override
    public String toString() {
        return "ProductFunction{" +
                "productFunctionId=" + getProductFunctionId() +
                ", productFunctionName='" + getProductFunctionName() + "'" +
                ", productFunctionDesc='" + getProductFunctionDesc() + "'" +
                "}";
    }
}
