package com.finastra.essence.capacityplanner.domain;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A UserCapacity.
 */
@Entity
@Table(name = "user_capacity")
public class UserCapacity extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "capacity_id", columnDefinition = "char(36)", unique = true)
    private String capacityId;

    @NotNull
    @Size(max = 36)
    @Column(name = "user_id", length = 36, nullable = false)
    private String userId;

    @NotNull
    @Size(max = 8)
    @Column(name = "month_code", length = 8, nullable = false)
    private String monthCode;

    @NotNull
    @Column(name = "available_hours", nullable = false)
    private Integer availableHours;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    public String getCapacityId() {
        return capacityId;
    }

    public UserCapacity capacityId(String capacityId) {
        this.capacityId = capacityId;
        return this;
    }

    public void setCapacityId(String capacityId) {
        this.capacityId = capacityId;
    }

    public String getUserId() {
        return userId;
    }

    public UserCapacity userId(String userId) {
        this.userId = userId;
        return this;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMonthCode() {
        return monthCode;
    }

    public UserCapacity monthCode(String monthCode) {
        this.monthCode = monthCode;
        return this;
    }

    public void setMonthCode(String monthCode) {
        this.monthCode = monthCode;
    }

    public Integer getAvailableHours() {
        return availableHours;
    }

    public UserCapacity availableHours(Integer availableHours) {
        this.availableHours = availableHours;
        return this;
    }

    public void setAvailableHours(Integer availableHours) {
        this.availableHours = availableHours;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        UserCapacity that = (UserCapacity) o;
        return Objects.equals(capacityId, that.capacityId) &&
                Objects.equals(userId, that.userId) &&
                Objects.equals(monthCode, that.monthCode) &&
                Objects.equals(availableHours, that.availableHours);
    }

    @Override
    public int hashCode() {
        return Objects.hash(capacityId, userId, monthCode, availableHours);
    }

    @Override
    public String toString() {
        return "UserCapacity{" +
                "capacityId='" + capacityId + '\'' +
                ", userId='" + userId + '\'' +
                ", monthCode='" + monthCode + '\'' +
                ", availableHours=" + availableHours +
                '}';
    }
}
