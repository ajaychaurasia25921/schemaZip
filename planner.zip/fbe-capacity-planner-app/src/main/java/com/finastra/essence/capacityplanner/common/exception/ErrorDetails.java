/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.capacityplanner.common.exception;


import java.io.Serializable;
import java.util.List;

public class ErrorDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * The URL path of the Error type
     */
    private String type = "";
    /**
     * Gist/Summary of the validation
     */
    private String title;
    /**
     * The HTTP status code.
     */
    private Integer status;
    /**
     * Additional information that can help consumers to resolve the issue
     */
    private String detail;

    /**
     * Contains all the field validation contents
     */
    public List<FieldError> causes;

    /**
     * Default constructor
     */
    public ErrorDetails() {
        //Default constructor
    }

    /**
     * Parameterised Constructor with param detail
     *
     * @param detail the detail of the message.
     */
    public ErrorDetails(String detail) {
        this.detail = detail;
    }

    /**
     * This is a getter method returns the type
     *
     * @return type
     */
    public String getType() {
        return type;
    }

    /**
     * This is setter method sets type
     *
     * @param type the type of an error.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * This is a getter method returns the title
     *
     * @return title the title of the error
     */
    public String getTitle() {
        return title;
    }

    /**
     * This is setter method which sets the title of the error
     *
     * @param title sets the appropriate title to the error
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * This is a getter method that returns the HTTP status code
     *
     * @return status the HTTP status code
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * This is setter method that sets the HTTP status code
     *
     * @param status the HTTP status code
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * This is a getter method that returns the detail of the error
     *
     * @return detail the detailed error
     */
    public String getDetail() {
        return detail;
    }

    /**
     * This is setter method that sets the detail of the error
     *
     * @param detail the detailed error
     */
    public void setDetail(String detail) {
        this.detail = detail;
    }

    /**
     * This is a getter method returns the causes
     *
     * @return causes the list of validation errors
     */
    public List<FieldError> getCauses() {
        return causes;
    }

    /**
     * This is setter method that sets the validation errors
     *
     * @param causes the list of validation errors
     */
    public void setCauses(List<FieldError> causes) {
        this.causes = causes;
    }

}
