package com.finastra.essence.capacityplanner.domain;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A LocationHoliday.
 */
@Entity
@Table(name = "location_holiday")
public class LocationHoliday extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;


    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "holiday_id", columnDefinition = "char(36)", unique = true)
    private String holidayId;

    @NotNull
    @Size(max = 36)
    @Column(name = "location_id", length = 36, nullable = false)
    private String locationId;

    @NotNull
    @Column(name = "holiday_date", nullable = false)
    private LocalDate holidayDate;

    @NotNull
    @Size(max = 60)
    @Column(name = "holiday_name", length = 60, nullable = false)
    private String holidayName;

    @NotNull
    @Size(max = 1)
    @Column(name = "half_day_flag", length = 1, nullable = false)
    private String halfDayFlag;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    public String getHolidayId() {
        return holidayId;
    }

    public LocationHoliday holidayId(String holidayId) {
        this.holidayId = holidayId;
        return this;
    }

    public void setHolidayId(String holidayId) {
        this.holidayId = holidayId;
    }

    public String getLocationId() {
        return locationId;
    }

    public LocationHoliday locationId(String locationId) {
        this.locationId = locationId;
        return this;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public LocalDate getHolidayDate() {
        return holidayDate;
    }

    public LocationHoliday holidayDate(LocalDate holidayDate) {
        this.holidayDate = holidayDate;
        return this;
    }

    public void setHolidayDate(LocalDate holidayDate) {
        this.holidayDate = holidayDate;
    }

    public String getHolidayName() {
        return holidayName;
    }

    public LocationHoliday holidayName(String holidayName) {
        this.holidayName = holidayName;
        return this;
    }

    public void setHolidayName(String holidayName) {
        this.holidayName = holidayName;
    }

    public String getHalfDayFlag() {
        return halfDayFlag;
    }

    public LocationHoliday halfDayFlag(String halfDayFlag) {
        this.halfDayFlag = halfDayFlag;
        return this;
    }

    public void setHalfDayFlag(String halfDayFlag) {
        this.halfDayFlag = halfDayFlag;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        LocationHoliday that = (LocationHoliday) o;
        return Objects.equals(holidayId, that.holidayId) &&
                Objects.equals(locationId, that.locationId) &&
                Objects.equals(holidayDate, that.holidayDate) &&
                Objects.equals(holidayName, that.holidayName) &&
                Objects.equals(halfDayFlag, that.halfDayFlag);
    }

    @Override
    public int hashCode() {
        return Objects.hash(holidayId, locationId, holidayDate, holidayName, halfDayFlag);
    }

    @Override
    public String toString() {
        return "LocationHoliday{" +
                "holidayId='" + holidayId + '\'' +
                ", locationId='" + locationId + '\'' +
                ", holidayDate=" + holidayDate +
                ", holidayName='" + holidayName + '\'' +
                ", halfDayFlag='" + halfDayFlag + '\'' +
                '}';
    }
}
