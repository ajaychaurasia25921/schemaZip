package com.finastra.essence.capacityplanner.service.dto;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import io.github.jhipster.service.filter.BigDecimalFilter;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.IntegerFilter;
import io.github.jhipster.service.filter.StringFilter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A DTO for the AppUser entity.
 */
public class AppUserCriteria implements Serializable {

    private BooleanFilter activeFlag;

    private StringFilter userId;

    private BigDecimalFilter jiraId;

    private StringFilter jiraUserName;

    private StringFilter userName;

    private StringFilter userEmail;

    private StringFilter userMobile;

    private StringFilter locationId;

    private IntegerFilter employeeId;

    private StringFilter productOrgId;

    private StringFilter productCategoryId;

    private StringFilter productFunctionId;

    private StringFilter skillSetId;

    private StringFilter skillLevelId;

    private StringFilter jobFunctionId;

    private StringFilter encryptedAccessCode;

    private StringFilter managerId;

    private StringFilter contributorFlag;

    public BooleanFilter getActiveFlag() {
        return activeFlag;
    }

    public void setActiveFlag(BooleanFilter activeFlag) {
        this.activeFlag = activeFlag;
    }

    public StringFilter getUserId() {
        return userId;
    }

    public void setUserId(StringFilter userId) {
        this.userId = userId;
    }

    public BigDecimalFilter getJiraId() {
        return jiraId;
    }

    public void setJiraId(BigDecimalFilter jiraId) {
        this.jiraId = jiraId;
    }

    public StringFilter getJiraUserName() {
        return jiraUserName;
    }

    public void setJiraUserName(StringFilter jiraUserName) {
        this.jiraUserName = jiraUserName;
    }

    public StringFilter getUserName() {
        return userName;
    }

    public void setUserName(StringFilter userName) {
        this.userName = userName;
    }

    public StringFilter getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(StringFilter userEmail) {
        this.userEmail = userEmail;
    }

    public StringFilter getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(StringFilter userMobile) {
        this.userMobile = userMobile;
    }

    public StringFilter getLocationId() {
        return locationId;
    }

    public void setLocationId(StringFilter locationId) {
        this.locationId = locationId;
    }

    public IntegerFilter getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(IntegerFilter employeeId) {
        this.employeeId = employeeId;
    }

    public StringFilter getProductOrgId() {
        return productOrgId;
    }

    public void setProductOrgId(StringFilter productOrgId) {
        this.productOrgId = productOrgId;
    }

    public StringFilter getProductCategoryId() {
        return productCategoryId;
    }

    public void setProductCategoryId(StringFilter productCategoryId) {
        this.productCategoryId = productCategoryId;
    }

    public StringFilter getProductFunctionId() {
        return productFunctionId;
    }

    public void setProductFunctionId(StringFilter productFunctionId) {
        this.productFunctionId = productFunctionId;
    }

    public StringFilter getSkillSetId() {
        return skillSetId;
    }

    public void setSkillSetId(StringFilter skillSetId) {
        this.skillSetId = skillSetId;
    }

    public StringFilter getSkillLevelId() {
        return skillLevelId;
    }

    public void setSkillLevelId(StringFilter skillLevelId) {
        this.skillLevelId = skillLevelId;
    }

    public StringFilter getJobFunctionId() {
        return jobFunctionId;
    }

    public void setJobFunctionId(StringFilter jobFunctionId) {
        this.jobFunctionId = jobFunctionId;
    }

    public StringFilter getEncryptedAccessCode() {
        return encryptedAccessCode;
    }

    public void setEncryptedAccessCode(StringFilter encryptedAccessCode) {
        this.encryptedAccessCode = encryptedAccessCode;
    }

    public StringFilter getManagerId() {
        return managerId;
    }

    public void setManagerId(StringFilter managerId) {
        this.managerId = managerId;
    }

    public StringFilter getContributorFlag() {
        return contributorFlag;
    }

    public void setContributorFlag(StringFilter contributorFlag) {
        this.contributorFlag = contributorFlag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AppUserCriteria that = (AppUserCriteria) o;
        return Objects.equals(activeFlag, that.activeFlag) &&
                Objects.equals(userId, that.userId) &&
                Objects.equals(jiraId, that.jiraId) &&
                Objects.equals(jiraUserName, that.jiraUserName) &&
                Objects.equals(userName, that.userName) &&
                Objects.equals(userEmail, that.userEmail) &&
                Objects.equals(userMobile, that.userMobile) &&
                Objects.equals(locationId, that.locationId) &&
                Objects.equals(employeeId, that.employeeId) &&
                Objects.equals(productOrgId, that.productOrgId) &&
                Objects.equals(productCategoryId, that.productCategoryId) &&
                Objects.equals(productFunctionId, that.productFunctionId) &&
                Objects.equals(skillSetId, that.skillSetId) &&
                Objects.equals(skillLevelId, that.skillLevelId) &&
                Objects.equals(jobFunctionId, that.jobFunctionId) &&
                Objects.equals(encryptedAccessCode, that.encryptedAccessCode) &&
                Objects.equals(managerId, that.managerId) &&
                Objects.equals(contributorFlag, that.contributorFlag);
    }

    @Override
    public int hashCode() {
        return Objects.hash(activeFlag, userId, jiraId, jiraUserName, userName, userEmail, userMobile, locationId, employeeId, productOrgId, productCategoryId, productFunctionId, skillSetId, skillLevelId, jobFunctionId, encryptedAccessCode, managerId, contributorFlag);
    }

    @Override
    public String toString() {
        return "AppUserCriteria{" +
                "activeFlag=" + activeFlag +
                ", userId=" + userId +
                ", jiraId=" + jiraId +
                ", jiraUserName=" + jiraUserName +
                ", userName=" + userName +
                ", userEmail=" + userEmail +
                ", userMobile=" + userMobile +
                ", locationId=" + locationId +
                ", employeeId=" + employeeId +
                ", productOrgId=" + productOrgId +
                ", productCategoryId=" + productCategoryId +
                ", productFunctionId=" + productFunctionId +
                ", skillSetId=" + skillSetId +
                ", skillLevelId=" + skillLevelId +
                ", jobFunctionId=" + jobFunctionId +
                ", encryptedAccessCode=" + encryptedAccessCode +
                ", managerId=" + managerId +
                ", contributorFlag=" + contributorFlag +
                '}';
    }
}