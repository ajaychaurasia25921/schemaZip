/**
 * Spring Data JPA repositories.
 */
package com.finastra.essence.capacityplanner.repository;
