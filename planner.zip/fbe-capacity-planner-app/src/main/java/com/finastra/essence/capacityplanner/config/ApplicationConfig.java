package com.finastra.essence.capacityplanner.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * @author mdongala
 *
 */
@Configuration
public class ApplicationConfig {

	@Value(value = "${config.quartz.cronExpressionTime}")
	private String cronExpressionTime;
	
	@Value(value = "${config.jira.url}")
	private String url;

	@Value(value = "${config.jira.username}")
	private String username;

	@Value(value = "${config.jira.password}")
	private String password;

	@Value(value = "${config.jira.jqlPagination.requstFileds}")
	private String requstFileds;

	@Value(value = "${config.jira.jqlPagination.startAt}")
	private float startAt;

	@Value(value = "${config.jira.jqlPagination.maxResults}")
	private float maxResults;

	public String getCronExpressionTime() {
		return cronExpressionTime;
	}

	public void setCronExpressionTime(String cronExpressionTime) {
		this.cronExpressionTime = cronExpressionTime;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRequstFileds() {
		return requstFileds;
	}

	public void setRequstFileds(String requstFileds) {
		this.requstFileds = requstFileds;
	}

	public float getStartAt() {
		return startAt;
	}

	public void setStartAt(float startAt) {
		this.startAt = startAt;
	}

	public float getMaxResults() {
		return maxResults;
	}

	public void setMaxResults(float maxResults) {
		this.maxResults = maxResults;
	}

}
