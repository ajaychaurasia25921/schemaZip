package com.finastra.essence.capacityplanner.repository;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.domain.LocationCapacity;
import com.finastra.essence.capacityplanner.domain.LocationHoliday;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * Spring Data  repository for the LocationCapacity entity.
 */
@SuppressWarnings("unused")
@Repository
public interface LocationCapacityRepository extends JpaRepository<LocationCapacity, String> {

    /**
     * This method is used to fetch the location capacity list
     *
     * @param locationId the id of the location
     * @return list of location capacity
     */
    List<LocationCapacity> findByLocationId(String locationId);
    /**
     * This method is used to check whether Location Id exists or not
     *
     * @param locationId the id of the location.
     * @return true if location exists
     * false if location does not exists.
     */
    boolean existsByLocationId(String locationId);

    /**
     * This function is used to fetch list of location capacities.
     * @param activeFlag Flag to denote whether the entity is marked as active or inactive.
     * @return fetch list of location capacities.
     */
    List<LocationCapacity> findByActiveFlag(boolean activeFlag);
	 /**
     * This function is used to fetch location capacity by location id and month code
     * @param locationId the id of the location.
     * @param monthCode the month code value
     * @return the location capacity by location id and month code.
     */
    LocationCapacity findByLocationIdAndMonthCode(String locationId, String monthCode);
}
