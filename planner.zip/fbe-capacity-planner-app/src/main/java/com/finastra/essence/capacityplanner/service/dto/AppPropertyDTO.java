package com.finastra.essence.capacityplanner.service.dto;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.finastra.essence.capacityplanner.domain.AbstractAuditingEntity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * A DTO for the AppProperty entity.
 */
public class AppPropertyDTO extends AbstractAuditingEntity implements Serializable {

    private String propertyId;

    @NotNull(message = "{}")
    @Size(max = 80)
    private String propertyName;

    @Size(max = 240)
    private String propertyDesc;

    @NotNull
    @Size(max = 1)
    @JsonIgnore
    private String propertyValueDataType;

    @Size(max = 240)
    @JsonIgnore
    private String propertyValueText;

    @JsonIgnore
    private Integer propertyValueInteger;

    @JsonIgnore
    private BigDecimal propertyValueDecimal;

    @Size(max = 1)
    @JsonIgnore
    private String propertyValueFlag;

    @JsonIgnore
    private LocalDate propertyValueDate;

    @JsonIgnore
    private ZonedDateTime propertyValueDatetime;

    public String getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(String propertyId) {
        this.propertyId = propertyId;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getPropertyDesc() {
        return propertyDesc;
    }

    public void setPropertyDesc(String propertyDesc) {
        this.propertyDesc = propertyDesc;
    }

    public String getPropertyValueDataType() {
        return propertyValueDataType;
    }

    public void setPropertyValueDataType(String propertyValueDataType) {
        this.propertyValueDataType = propertyValueDataType;
    }

    public String getPropertyValueText() {
        return propertyValueText;
    }

    public void setPropertyValueText(String propertyValueText) {
        this.propertyValueText = propertyValueText;
    }

    public Integer getPropertyValueInteger() {
        return propertyValueInteger;
    }

    public void setPropertyValueInteger(Integer propertyValueInteger) {
        this.propertyValueInteger = propertyValueInteger;
    }

    public BigDecimal getPropertyValueDecimal() {
        return propertyValueDecimal;
    }

    public void setPropertyValueDecimal(BigDecimal propertyValueDecimal) {
        this.propertyValueDecimal = propertyValueDecimal;
    }

    public String getPropertyValueFlag() {
        return propertyValueFlag;
    }

    public void setPropertyValueFlag(String propertyValueFlag) {
        this.propertyValueFlag = propertyValueFlag;
    }

    public LocalDate getPropertyValueDate() {
        return propertyValueDate;
    }

    public void setPropertyValueDate(LocalDate propertyValueDate) {
        this.propertyValueDate = propertyValueDate;
    }

    public ZonedDateTime getPropertyValueDatetime() {
        return propertyValueDatetime;
    }

    public void setPropertyValueDatetime(ZonedDateTime propertyValueDatetime) {
        this.propertyValueDatetime = propertyValueDatetime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AppPropertyDTO appPropertyDTO = (AppPropertyDTO) o;
        if (appPropertyDTO.getPropertyId() == null || getPropertyId() == null) {
            return false;
        }
        return Objects.equals(getPropertyId(), appPropertyDTO.getPropertyId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getPropertyId());
    }

    @Override
    public String toString() {
        return "AppPropertyDTO{" +
                "id=" + getPropertyId() +
                ", propertyName='" + getPropertyName() + "'" +
                ", propertyDesc='" + getPropertyDesc() + "'" +
                ", propertyValueDataType='" + getPropertyValueDataType() + "'" +
                ", propertyValueText='" + getPropertyValueText() + "'" +
                ", propertyValueInteger=" + getPropertyValueInteger() +
                ", propertyValueDecimal=" + getPropertyValueDecimal() +
                ", propertyValueFlag='" + getPropertyValueFlag() + "'" +
                ", propertyValueDate='" + getPropertyValueDate() + "'" +
                ", propertyValueDatetime='" + getPropertyValueDatetime() + "'" +
                "}";
    }
}
