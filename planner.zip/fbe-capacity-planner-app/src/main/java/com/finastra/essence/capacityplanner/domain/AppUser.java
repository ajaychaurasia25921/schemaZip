package com.finastra.essence.capacityplanner.domain;

/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

/**
 * This class is used to maintain the details of the users
 */
@Entity
@Table(name = "app_user")
public class AppUser extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * Attribute holding the id of the user
     */
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "user_id", columnDefinition = "char(36)", unique = true)
    private String userId;
    /**
     * Attribute holding the id of the jira.
     */
    @NotNull
    @Column(name = "jira_id", precision = 10, scale = 2, nullable = false, unique = true)
    private BigDecimal jiraId;
    /**
     * Attribute holding the user name in jira.
     */
    @NotNull
    @Size(max = 255)
    @Column(name = "jira_user_name", length = 255, nullable = false)
    private String jiraUserName;
    /**
     * Attribute holding the name of the user
     */
    @NotNull
    @Size(max = 80)
    @Column(name = "user_name", length = 80, nullable = false, unique = true)
    private String userName;
    /**
     * Attribute holding the email of the user
     */
    @NotNull
    @Size(max = 80)
    @Column(name = "user_email", length = 80, nullable = false)
    private String userEmail;
    /**
     * Attribute holding the mobile number of the user
     */
    @Size(max = 15)
    @Column(name = "user_mobile", length = 15)
    private String userMobile;
    /**
     * Attribute holding the id of the location
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "location_id", length = 36, nullable = false)
    private String locationId;
    /**
     * Attribute holding the id of an employee
     */
    @NotNull
    @Column(name = "employee_id", nullable = false)
    private Integer employeeId;
    /**
     * Attribute holding the id of an product organization.
     *
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "product_org_id", length = 36, nullable = false)
    private String productOrgId;
    /**
     * Attribute holding the id of the product category.
     */
    @Size(max = 36)
    @Column(name = "product_category_id", length = 36)
    private String productCategoryId;
    /**
     * Attribute holding the id of the product function
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "product_function_id", length = 36, nullable = false)
    private String productFunctionId;
    /**
     * Attribute holding the id of the skill set.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "skill_set_id", length = 36, nullable = false)
    private String skillSetId;
    /**
     * Attribute holding the sid of an skill level.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "skill_level_id", length = 36, nullable = false)
    private String skillLevelId;
    /**
     * Attribute holding the id of the job function.
     */
    @NotNull
    @Size(max = 36)
    @Column(name = "job_function_id", length = 36, nullable = false)
    private String jobFunctionId;
    /**
     * Attribute holding the encrypted access code of the user.
     */
    @NotNull
    @Size(max = 512)
    @Column(name = "encrypted_access_code", length = 512, nullable = false)
    private String encryptedAccessCode;
    /**
     * Attribute holding the id of an manager
     */
    @Size(max = 36)
    @Column(name = "manager_id", length = 36)
    private String managerId;
    /**
     * Attribute holding the user contributions
     */
    @NotNull
    @Size(max = 1)
    @Column(name = "contributor_flag", length = 1, nullable = false)
    private String contributorFlag;
    /**
     * Attribute holding the joining date of an user
     */
    @Column(name = "joined_date")
    private LocalDate joinedDate;
    /**
     * Many to One Mapping between AppUser and Product Organization
     *
     */
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "product_org_id", insertable = false, updatable = false)
    private ProductOrg productOrg;
    /**
     * Many to One Mapping between AppUser and Product Function
     */
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "product_function_id", insertable = false, updatable = false)
    private ProductFunction productFunction;
    /**
     * Many to One Mapping between AppUser and Product Category
     */
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "product_category_id", insertable = false, updatable = false)
    private ProductCategory productCategory;
    /**
     * Many to One Mapping between AppUser and Skill Level
     */
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "skill_level_id", insertable = false, updatable = false)
    private SkillLevel skillLevel;
    /**
     * Many to One Mapping between AppUser and Skill Set
     */
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "skill_set_id", insertable = false, updatable = false)
    private SkillSet skillSet;
    /**
     * Many to One Mapping between AppUser and Job Function
     */
    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "job_function_id", insertable = false, updatable = false)
    private JobFunction jobFunction;

    /**
     * This method is used to get the skill level of an user.
     * @return
     */
    public SkillLevel getSkillLevel() {
        return skillLevel;
    }

    /**
     * This meth
     * @param skillLevel
     */
    public void setSkillLevel(SkillLevel skillLevel) {
        this.skillLevel = skillLevel;
    }

    public SkillSet getSkillSet() {
        return skillSet;
    }

    public void setSkillSet(SkillSet skillSet) {
        this.skillSet = skillSet;
    }

    public JobFunction getJobFunction() {
        return jobFunction;
    }

    public void setJobFunction(JobFunction jobFunction) {
        this.jobFunction = jobFunction;
    }

    public ProductOrg getProductOrg() {
        return productOrg;
    }

    public void setProductOrg(ProductOrg productOrg) {
        this.productOrg = productOrg;
    }

    public ProductFunction getProductFunction() {
        return productFunction;
    }

    public void setProductFunction(ProductFunction productFunction) {
        this.productFunction = productFunction;
    }

    public ProductCategory getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(ProductCategory productCategory) {
        this.productCategory = productCategory;
    }

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public BigDecimal getJiraId() {
        return jiraId;
    }

    public AppUser jiraId(BigDecimal jiraId) {
        this.jiraId = jiraId;
        return this;
    }

    public void setJiraId(BigDecimal jiraId) {
        this.jiraId = jiraId;
    }

    public String getJiraUserName() {
        return jiraUserName;
    }

    public AppUser jiraUserName(String jiraUserName) {
        this.jiraUserName = jiraUserName;
        return this;
    }

    public void setJiraUserName(String jiraUserName) {
        this.jiraUserName = jiraUserName;
    }

    public String getUserName() {
        return userName;
    }

    public AppUser userName(String userName) {
        this.userName = userName;
        return this;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public AppUser userEmail(String userEmail) {
        this.userEmail = userEmail;
        return this;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public AppUser userMobile(String userMobile) {
        this.userMobile = userMobile;
        return this;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getLocationId() {
        return locationId;
    }

    public AppUser locationId(String locationId) {
        this.locationId = locationId;
        return this;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public AppUser employeeId(Integer employeeId) {
        this.employeeId = employeeId;
        return this;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getProductOrgId() {
        return productOrgId;
    }

    public AppUser productOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
        return this;
    }

    public void setProductOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
    }

    public String getProductCategoryId() {
        return productCategoryId;
    }

    public AppUser productCategoryId(String productCategoryId) {
        this.productCategoryId = productCategoryId;
        return this;
    }

    public void setProductCategoryId(String productCategoryId) {
        this.productCategoryId = productCategoryId;
    }

    public String getProductFunctionId() {
        return productFunctionId;
    }

    public AppUser productFunctionId(String productFunctionId) {
        this.productFunctionId = productFunctionId;
        return this;
    }

    public void setProductFunctionId(String productFunctionId) {
        this.productFunctionId = productFunctionId;
    }

    public String getSkillSetId() {
        return skillSetId;
    }

    public AppUser skillSetId(String skillSetId) {
        this.skillSetId = skillSetId;
        return this;
    }

    public void setSkillSetId(String skillSetId) {
        this.skillSetId = skillSetId;
    }

    public String getSkillLevelId() {
        return skillLevelId;
    }

    public AppUser skillLevelId(String skillLevelId) {
        this.skillLevelId = skillLevelId;
        return this;
    }

    public void setSkillLevelId(String skillLevelId) {
        this.skillLevelId = skillLevelId;
    }

    public String getJobFunctionId() {
        return jobFunctionId;
    }

    public AppUser jobFunctionId(String jobFunctionId) {
        this.jobFunctionId = jobFunctionId;
        return this;
    }

    public void setJobFunctionId(String jobFunctionId) {
        this.jobFunctionId = jobFunctionId;
    }

    public String getEncryptedAccessCode() {
        return encryptedAccessCode;
    }

    public AppUser encryptedAccessCode(String encryptedAccessCode) {
        this.encryptedAccessCode = encryptedAccessCode;
        return this;
    }

    public void setEncryptedAccessCode(String encryptedAccessCode) {
        this.encryptedAccessCode = encryptedAccessCode;
    }

    public String getManagerId() {
        return managerId;
    }

    public AppUser managerId(String managerId) {
        this.managerId = managerId;
        return this;
    }

    public void setManagerId(String managerId) {
        this.managerId = managerId;
    }

    public String getContributorFlag() {
        return contributorFlag;
    }

    public AppUser contributorFlag(String contributorFlag) {
        this.contributorFlag = contributorFlag;
        return this;
    }

    public void setContributorFlag(String contributorFlag) {
        this.contributorFlag = contributorFlag;
    }

    public LocalDate getJoinedDate() {
        return joinedDate;
    }

    public AppUser joinedDate(LocalDate joinedDate) {
        this.joinedDate = joinedDate;
        return this;
    }

    public void setJoinedDate(LocalDate joinedDate) {
        this.joinedDate = joinedDate;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AppUser appUser = (AppUser) o;
        if (appUser.getUserId() == null || getUserId() == null) {
            return false;
        }
        return Objects.equals(getUserId(), appUser.getUserId())
                && Objects.equals(getContributorFlag(), appUser.getContributorFlag())
                && Objects.equals(getEmployeeId(), appUser.getEmployeeId())
                && Objects.equals(getContributorFlag(), appUser.getContributorFlag())
                && Objects.equals(getEncryptedAccessCode(), appUser.getEncryptedAccessCode())
                && Objects.equals(getJiraId(), appUser.getJiraId())
                && Objects.equals(getJiraUserName(), appUser.getJiraUserName())
                && Objects.equals(getJobFunctionId(), appUser.getJobFunctionId())
                && Objects.equals(getJoinedDate(), appUser.getJoinedDate())
                && Objects.equals(getLocationId(), appUser.getLocationId())
                && Objects.equals(getManagerId(), appUser.getManagerId())
                && Objects.equals(getProductCategoryId(), appUser.getProductCategoryId())
                && Objects.equals(getProductOrgId(), appUser.getProductOrgId())
                && Objects.equals(getSkillLevelId(), appUser.getSkillLevelId())
                && Objects.equals(getSkillSetId(), appUser.getSkillSetId())
                && Objects.equals(getUserEmail(), appUser.getUserEmail())
                && Objects.equals(getUserMobile(), appUser.getUserMobile())
                && Objects.equals(getProductFunctionId(), appUser.getProductFunctionId())
                ;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getUserId());
    }

    @Override
    public String toString() {
        return "AppUser{" +
                "userId=" + getUserId() +
                ", jiraId=" + getJiraId() +
                ", jiraUserName='" + getJiraUserName() + "'" +
                ", userName='" + getUserName() + "'" +
                ", userEmail='" + getUserEmail() + "'" +
                ", userMobile='" + getUserMobile() + "'" +
                ", locationId='" + getLocationId() + "'" +
                ", employeeId=" + getEmployeeId() +
                ", productOrgId='" + getProductOrgId() + "'" +
                ", productCategoryId='" + getProductCategoryId() + "'" +
                ", productFunctionId='" + getProductFunctionId() + "'" +
                ", skillSetId='" + getSkillSetId() + "'" +
                ", skillLevelId='" + getSkillLevelId() + "'" +
                ", jobFunctionId='" + getJobFunctionId() + "'" +
                ", encryptedAccessCode='" + getEncryptedAccessCode() + "'" +
                ", managerId='" + getManagerId() + "'" +
                ", contributorFlag='" + getContributorFlag() + "'" +
                ", joinedDate='" + getJoinedDate() + "'" +
                "}";
    }
}
