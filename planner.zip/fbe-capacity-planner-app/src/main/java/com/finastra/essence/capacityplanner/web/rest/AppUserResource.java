package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.AppUserQueryService;
import com.finastra.essence.capacityplanner.service.AppUserService;
import com.finastra.essence.capacityplanner.service.dto.AppUserCriteria;
import com.finastra.essence.capacityplanner.service.dto.AppUserDTO;
import com.finastra.essence.capacityplanner.web.rest.errors.BadRequestAlertException;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing AppUser.
 */
@RestController
@RequestMapping("/api")
public class AppUserResource {

    private final Logger log = LoggerFactory.getLogger(AppUserResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppAppUser";

    private final AppUserService appUserService;

    private final AppUserQueryService appUserQueryService;

    public AppUserResource(AppUserService appUserService, AppUserQueryService appUserQueryService) {
        this.appUserService = appUserService;
        this.appUserQueryService = appUserQueryService;
    }

    /**
     * POST  /app-users : Create a new appUser.
     *
     * @param appUserDTO the appUserDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new appUserDTO, or with status 400 (Bad Request) if the appUser has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/users")
    @ApiOperation(value = "create a application user")
    public ResponseEntity<AppUserDTO> createAppUser(@Valid @RequestBody AppUserDTO appUserDTO) throws URISyntaxException {
        log.debug("REST request to save AppUser : {}", appUserDTO);
        AppUserDTO result = appUserService.save(appUserDTO);
        return ResponseEntity.created(new URI("/api/app-users/" + result.getUserId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getUserId())).build();
    }

    /**
     * PUT  /app-users : Updates an existing appUser.
     *
     * @param appUserDTO the appUserDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated appUserDTO,
     * or with status 400 (Bad Request) if the appUserDTO is not valid,
     * or with status 500 (Internal Server Error) if the appUserDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/users")
    @ApiOperation(value = "update a application user")
    public ResponseEntity<AppUserDTO> updateAppUser(@Valid @RequestBody AppUserDTO appUserDTO) throws URISyntaxException {
        log.debug("REST request to update AppUser : {}", appUserDTO);
        if (appUserDTO.getUserId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        AppUserDTO result = appUserService.update(appUserDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, appUserDTO.getUserId()))
                .build();
    }

    /**
     * {@code POST  /users/filter} : get all the projectTasks.
     *
     * @param pageable the pagination information.
     * @param filter the criteria which the requested entities should match.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of AppUser in body.
     */
    @PostMapping("/users/filter")
    public ResponseEntity<List<AppUserDTO>> getAllAppUser(@RequestBody AppUserCriteria filter, Pageable pageable) {
        log.debug("REST request to get AppUser by criteria: {}", filter);
        Page<AppUserDTO> page = appUserQueryService.findByCriteria(filter, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page,"/api/users/filter");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }


    /**
     * @return
     */
    @GetMapping("/users/uniqueUserNames")
    @ApiOperation(value = "retrieve a list of unique user names")
    public ResponseEntity<List<Object>> getAllJiraUserNames() {
        log.debug("REST request to get a page of AppUsers");
        List<Object> jiraUserNames = appUserService.getJiraUserNames();
        return ResponseEntity.ok().body(jiraUserNames);
    }

    /**
     * GET  /app-users : get all the appUsers.
     *

     * @return the ResponseEntity with status 200 (OK) and the list of appUsers in body
     */
    @GetMapping("/users")
    @ApiOperation(value = "retrieve a list of application users")
    public ResponseEntity<List<AppUserDTO>> getAllAppUsers(@RequestParam(required = false) boolean activeFlag) {
        log.debug("REST request to get a page of AppUsers");
        List<AppUserDTO> appUsersByActiveFlag = appUserService.findByActiveFlag(activeFlag);
        return ResponseEntity.ok().body(appUsersByActiveFlag);
    }

    /**
     * GET  /app-users/:id : get the "id" appUser.
     *
     * @param id the id of the appUserDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the appUserDTO, or with status 404 (Not Found)
     */
    @GetMapping("/users/{id}")
    @ApiOperation(value = "retrieve a application user by id")
    public ResponseEntity<AppUserDTO> getAppUser(@PathVariable String id) {
        log.debug("REST request to get AppUser : {}", id);
        Optional<AppUserDTO> appUserDTO = appUserService.findOne(id);
        return ResponseUtil.wrapOrNotFound(appUserDTO);
    }

    /**
     * GET  /app-users/:id : get the "id" appUser.
     *
     * @param jiraUserName the id of the appUserDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the appUserDTO, or with status 404 (Not Found)
     */
    @GetMapping("/users/username/{jiraUserName}")
    @ApiOperation(value = "retrieve a application user by id")
    public ResponseEntity<AppUserDTO> getByJiraUserName(@PathVariable String jiraUserName) {
        log.debug("REST request to get AppUser : {}", jiraUserName);
        Optional<AppUserDTO> appUserDTO = appUserService.findByJiraUserName(jiraUserName);
        return ResponseUtil.wrapOrNotFound(appUserDTO);
    }

    /**
     * DELETE  /app/users/:id : delete the "id" appUser.
     *
     * @param id the id of the appUserDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/users/{id}")
    @ApiOperation(value = "delete a application user")
    public ResponseEntity<Void> deleteAppUser(@PathVariable String id) {
        log.debug("REST request to delete AppUser : {}", id);
        appUserService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
