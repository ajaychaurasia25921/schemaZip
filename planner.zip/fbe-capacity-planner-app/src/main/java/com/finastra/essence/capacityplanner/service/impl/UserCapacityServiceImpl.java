package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.AppUser;
import com.finastra.essence.capacityplanner.domain.LocationHoliday;
import com.finastra.essence.capacityplanner.domain.UserCapacity;
import com.finastra.essence.capacityplanner.domain.UserHoliday;
import com.finastra.essence.capacityplanner.repository.*;
import com.finastra.essence.capacityplanner.service.UserCapacityService;
import com.finastra.essence.capacityplanner.service.dto.UserCapacityDTO;
import com.finastra.essence.capacityplanner.service.mapper.UserCapacityMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing {@link UserCapacity}.
 */
@Service
@Transactional
public class UserCapacityServiceImpl implements UserCapacityService {

    private final Logger log = LoggerFactory.getLogger(UserCapacityServiceImpl.class);
    /**
     * Attribute holding the reference of user capacity repository.
     */
    private final UserCapacityRepository userCapacityRepository;
    /**
     * Attribute holding the reference of app user repository.
     */
    private final AppUserRepository appUserRepository;
    /**
     * Attribute holding the reference of app property repository.
     */
    @Autowired
    AppPropertyRepository appPropertyRepository;
    /**
     * Attribute holding the reference of user holiday repository.
     */
    @Autowired
    UserHolidayRepository userHolidayRepository;

    /**
     * Attribute holding the reference of user holiday repository.
     */
    @Autowired
    LocationHolidayRepository locationHolidayRepository;

    /**
     * Attribute holding the reference for the error details.
     */
    private final ErrorDetails errorDetails = new ErrorDetails();
    /**
     * Attribute holding the reference of user capacity mapper.
     */
    private final UserCapacityMapper userCapacityMapper;

    /**
     * This is used to initialize the repositories and mapper.
     *
     * @param userCapacityRepository the user capacity repository.
     * @param appUserRepository      the application user repository.
     * @param userCapacityMapper     the user capacity mapper.
     */
    public UserCapacityServiceImpl(UserCapacityRepository userCapacityRepository, AppUserRepository appUserRepository, UserCapacityMapper userCapacityMapper) {
        this.userCapacityRepository = userCapacityRepository;
        this.appUserRepository = appUserRepository;
        this.userCapacityMapper = userCapacityMapper;
    }

    /**
     * Save a userCapacity.
     *
     * @param userCapacityDTO the entity to save.
     * @return the persisted entity.
     */
    @Override
    public UserCapacityDTO save(UserCapacityDTO userCapacityDTO) {
        log.debug("Request to save UserCapacity : {}", userCapacityDTO);
        validateIdDuringPostOperation(userCapacityDTO);
        validateWhetherIdExists(userCapacityDTO);
        try {
            UserCapacity userCapacity = userCapacityMapper.toEntity(userCapacityDTO);
            userCapacity = userCapacityRepository.saveAndFlush(userCapacity);
            return userCapacityMapper.toDto(userCapacity);

        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails, e);
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }
    }

    /**
     * This function is used to fetch capacity of the user by id of the user.
     *
     * @param userId the id of the user.
     * @return list of capacity users by user id.
     */
    @Override
    public List<UserCapacityDTO> findByUserId(String userId) {
        if (!userCapacityRepository.existsByUserId(userId)) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }
        return userCapacityMapper.toDto(userCapacityRepository.findByUserId(userId));
    }

    /**
     * This method is used to validate whether the particular id exists.
     *
     * @param userCapacityDTO the entity to validate.
     */
    private void validateWhetherIdExists(UserCapacityDTO userCapacityDTO) {
        if (!appUserRepository.existsById(userCapacityDTO.getUserId())) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
        }
    }

    /**
     * This method is used to validate id during POST operation.
     *
     * @param userCapacityDTO the entity to validate.
     */
    private void validateIdDuringPostOperation(UserCapacityDTO userCapacityDTO) {
        if (null != userCapacityDTO.getCapacityId() && !userCapacityDTO.getCapacityId().isEmpty()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.AUTOGEN_ID));
            throw new UserDefinedException(errorDetails);
        }

    }

    /**
     * update a userCapacity.
     *
     * @param userCapacityDTO the entity to update.
     * @return the updated entity.
     */
    @Override
    public UserCapacityDTO update(UserCapacityDTO userCapacityDTO) {
        validateIdDuringPutOperation(userCapacityDTO);
        validateWhetherIdExists(userCapacityDTO);
        UserCapacity userCapacity;
        try {
            Optional<UserCapacity> userCapacityRepositoryById = userCapacityRepository.findById(userCapacityDTO.getCapacityId());
            if (userCapacityRepositoryById.isPresent()) {
                userCapacity = userCapacityMapper.toEntity(userCapacityDTO);
                if (userCapacity.equals(userCapacityRepositoryById.get())) {
                    throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NO_CHANGE_FOUND));
                } else {
                    userCapacityRepository.save(userCapacityMapper.toEntity(userCapacityDTO));
                }
            } else {
                throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            }
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);

        }

        return userCapacityMapper.toDto(userCapacity);
    }

    /**
     * This method is used to validate id during PUT operation.
     *
     * @param userCapacityDTO the entity to validate.
     */
    private void validateIdDuringPutOperation(UserCapacityDTO userCapacityDTO) {
        if (userCapacityDTO.getCapacityId().isEmpty() && null == userCapacityDTO.getCapacityId()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.PROVIDE_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * Get all the userCapacities.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<UserCapacityDTO> findAll(Pageable pageable) {
        log.debug("Request to get all UserCapacities");
        return userCapacityRepository.findAll(pageable)
                .map(userCapacityMapper::toDto);
    }


    /**
     * Get one userCapacity by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<UserCapacityDTO> findOne(String id) {
        log.debug("Request to get UserCapacity : {}", id);
        return userCapacityRepository.findById(id)
                .map(userCapacityMapper::toDto);
    }

    /**
     * Delete the userCapacity by id.
     *
     * @param id the id of the entity.
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete UserCapacity : {}", id);
        Optional<UserCapacity> userCapacityRepositoryById = userCapacityRepository.findById(id);
        userCapacityRepositoryById.ifPresent(userCapacity -> userCapacity.setActiveFlag(false));
    }

    private static int workingDaysPerMonth(int year, int month) {
        int count = 0;
        Calendar cal = new GregorianCalendar(year, month, 1);
        do {
            int day = cal.get(Calendar.DAY_OF_WEEK);
            if (!(day == Calendar.SATURDAY || day == Calendar.SUNDAY)) {
                count++;
            }
            cal.add(Calendar.DAY_OF_YEAR, 1);
        } while (cal.get(Calendar.MONTH) == month);
        return count;
    }

    private HashMap<String, Integer> getMonthValue() {
        HashMap<String, Integer> monthMap = new HashMap<String, Integer>();
        monthMap.put("JAN-2019", 1);
        monthMap.put("FEB-2019", 2);
        monthMap.put("MAR-2019", 3);
        monthMap.put("APR-2019", 4);
        monthMap.put("MAY-2019", 5);
        monthMap.put("JUN-2019", 6);
        monthMap.put("JUL-2019", 7);
        monthMap.put("AUG-2019", 8);
        monthMap.put("SEP-2019", 9);
        monthMap.put("OCT-2019", 10);
        monthMap.put("NOV-2019", 11);
        monthMap.put("DEC-2019", 12);
        return monthMap;
    }


    public void calculateUserCapacity() {
        Integer workingHoursPerDay = appPropertyRepository.findByPropertyName("WORK_DAY_DURATION_IN_HOURS")
                .getPropertyValueInteger();
        List<String> usersList = appUserRepository.findAll().parallelStream().map(AppUser::getUserId)
                .collect(Collectors.toList());
        for (String userId : usersList) {
            List<String> monthCodes = userCapacityRepository.findByUserId(userId).parallelStream()
                    .map(UserCapacity::getMonthCode).collect(Collectors.toList());
            List<LocalDate> userHolidayList = userHolidayRepository.findByUserIdAndActiveFlag(userId, true)
                    .parallelStream().map(UserHoliday::getHolidayDate).collect(Collectors.toList());
            List<LocalDate> locationHolidaysList = locationHolidayRepository.findAll().parallelStream()
                    .map(LocationHoliday::getHolidayDate).collect(Collectors.toList());
            for (String monthCode : monthCodes) {
                log.debug("monthCode: " + monthCode);
                int workingDaysPerMonth = workingDaysPerMonth(2019, getMonthValue().get(monthCode));
                int userHolidaysPerMonth = userHolidaysPerMonth(monthCode, userHolidayList);
                int locationHolidaysPerMonth = userHolidaysPerMonth(monthCode, locationHolidaysList);
                int totalWorkingDay = workingDaysPerMonth - userHolidaysPerMonth - locationHolidaysPerMonth;
                int available_hours = workingHoursPerDay * totalWorkingDay;
                log.debug("Working Days per month:" + workingDaysPerMonth + "userHolidaysPerMonth:" + userHolidaysPerMonth + "locationHolidaysPerMonth" + locationHolidaysPerMonth
                        + "totalWorkingDay:" + totalWorkingDay + "");

                UserCapacity findbyUserIdAndMonth = userCapacityRepository.findByUserIdAndMonthCode(userId, monthCode);
                if (findbyUserIdAndMonth != null) {
                    findbyUserIdAndMonth.setMonthCode(monthCode);
                    findbyUserIdAndMonth.setAvailableHours(available_hours);
                    userCapacityRepository.save(findbyUserIdAndMonth);
                }

            }

        }
    }


    private int userHolidaysPerMonth(String monthCode, List<LocalDate> userHolidayList) {
        int count = 0;
        for (LocalDate date : userHolidayList) {
            if (date.getMonthValue() == getMonthValue().get(monthCode)) {
                count++;
            }
        }
        return count;


    }
}




