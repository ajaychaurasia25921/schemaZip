package com.finastra.essence.capacityplanner.domain;


/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A OrgProject.
 */
@Entity
@Table(name = "org_project")
public class OrgProject extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "project_id", columnDefinition = "char(36)", unique = true)
    private String projectId;

    @NotNull
    @Size(max = 36)
    @Column(name = "product_org_id", length = 36, nullable = false)
    private String productOrgId;

    @NotNull
    @Size(max = 80)
    @Column(name = "project_name", length = 80, nullable = false)
    private String projectName;

    @Size(max = 240)
    @Column(name = "project_desc", length = 240)
    private String projectDesc;

    @NotNull
    @Size(max = 36)
    @Column(name = "project_owner_id", length = 36, nullable = false)
    private String projectOwnerId;

    @Column(name = "est_pm_start_date")
    private LocalDate estPmStartDate;

    @Column(name = "est_pm_end_date")
    private LocalDate estPmEndDate;

    @Column(name = "est_dev_start_date")
    private LocalDate estDevStartDate;

    @Column(name = "est_dev_end_date")
    private LocalDate estDevEndDate;

    @Column(name = "est_test_start_date")
    private LocalDate estTestStartDate;

    @Column(name = "est_test_end_date")
    private LocalDate estTestEndDate;

    @Column(name = "est_release_date")
    private LocalDate estReleaseDate;

    @Column(name = "act_pm_start_date")
    private LocalDate actPmStartDate;

    @Column(name = "act_pm_end_date")
    private LocalDate actPmEndDate;

    @Column(name = "act_dev_start_date")
    private LocalDate actDevStartDate;

    @Column(name = "act_dev_end_date")
    private LocalDate actDevEndDate;

    @Column(name = "act_test_start_date")
    private LocalDate actTestStartDate;

    @Column(name = "act_test_end_date")
    private LocalDate actTestEndDate;

    @Column(name = "act_release_date")
    private LocalDate actReleaseDate;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    public String getProductOrgId() {
        return productOrgId;
    }

    public OrgProject productOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
        return this;
    }

    public void setProductOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
    }

    public String getProjectName() {
        return projectName;
    }

    public OrgProject projectName(String projectName) {
        this.projectName = projectName;
        return this;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectDesc() {
        return projectDesc;
    }

    public OrgProject projectDesc(String projectDesc) {
        this.projectDesc = projectDesc;
        return this;
    }

    public void setProjectDesc(String projectDesc) {
        this.projectDesc = projectDesc;
    }

    public String getProjectOwnerId() {
        return projectOwnerId;
    }

    public OrgProject projectOwnerId(String projectOwnerId) {
        this.projectOwnerId = projectOwnerId;
        return this;
    }

    public void setProjectOwnerId(String projectOwnerId) {
        this.projectOwnerId = projectOwnerId;
    }

    public LocalDate getEstPmStartDate() {
        return estPmStartDate;
    }

    public OrgProject estPmStartDate(LocalDate estPmStartDate) {
        this.estPmStartDate = estPmStartDate;
        return this;
    }

    public void setEstPmStartDate(LocalDate estPmStartDate) {
        this.estPmStartDate = estPmStartDate;
    }

    public LocalDate getEstPmEndDate() {
        return estPmEndDate;
    }

    public OrgProject estPmEndDate(LocalDate estPmEndDate) {
        this.estPmEndDate = estPmEndDate;
        return this;
    }

    public void setEstPmEndDate(LocalDate estPmEndDate) {
        this.estPmEndDate = estPmEndDate;
    }

    public LocalDate getEstDevStartDate() {
        return estDevStartDate;
    }

    public OrgProject estDevStartDate(LocalDate estDevStartDate) {
        this.estDevStartDate = estDevStartDate;
        return this;
    }

    public void setEstDevStartDate(LocalDate estDevStartDate) {
        this.estDevStartDate = estDevStartDate;
    }

    public LocalDate getEstDevEndDate() {
        return estDevEndDate;
    }

    public OrgProject estDevEndDate(LocalDate estDevEndDate) {
        this.estDevEndDate = estDevEndDate;
        return this;
    }

    public void setEstDevEndDate(LocalDate estDevEndDate) {
        this.estDevEndDate = estDevEndDate;
    }

    public LocalDate getEstTestStartDate() {
        return estTestStartDate;
    }

    public OrgProject estTestStartDate(LocalDate estTestStartDate) {
        this.estTestStartDate = estTestStartDate;
        return this;
    }

    public void setEstTestStartDate(LocalDate estTestStartDate) {
        this.estTestStartDate = estTestStartDate;
    }

    public LocalDate getEstTestEndDate() {
        return estTestEndDate;
    }

    public OrgProject estTestEndDate(LocalDate estTestEndDate) {
        this.estTestEndDate = estTestEndDate;
        return this;
    }

    public void setEstTestEndDate(LocalDate estTestEndDate) {
        this.estTestEndDate = estTestEndDate;
    }

    public LocalDate getEstReleaseDate() {
        return estReleaseDate;
    }

    public OrgProject estReleaseDate(LocalDate estReleaseDate) {
        this.estReleaseDate = estReleaseDate;
        return this;
    }

    public void setEstReleaseDate(LocalDate estReleaseDate) {
        this.estReleaseDate = estReleaseDate;
    }

    public LocalDate getActPmStartDate() {
        return actPmStartDate;
    }

    public OrgProject actPmStartDate(LocalDate actPmStartDate) {
        this.actPmStartDate = actPmStartDate;
        return this;
    }

    public void setActPmStartDate(LocalDate actPmStartDate) {
        this.actPmStartDate = actPmStartDate;
    }

    public LocalDate getActPmEndDate() {
        return actPmEndDate;
    }

    public OrgProject actPmEndDate(LocalDate actPmEndDate) {
        this.actPmEndDate = actPmEndDate;
        return this;
    }

    public void setActPmEndDate(LocalDate actPmEndDate) {
        this.actPmEndDate = actPmEndDate;
    }

    public LocalDate getActDevStartDate() {
        return actDevStartDate;
    }

    public OrgProject actDevStartDate(LocalDate actDevStartDate) {
        this.actDevStartDate = actDevStartDate;
        return this;
    }

    public void setActDevStartDate(LocalDate actDevStartDate) {
        this.actDevStartDate = actDevStartDate;
    }

    public LocalDate getActDevEndDate() {
        return actDevEndDate;
    }

    public OrgProject actDevEndDate(LocalDate actDevEndDate) {
        this.actDevEndDate = actDevEndDate;
        return this;
    }

    public void setActDevEndDate(LocalDate actDevEndDate) {
        this.actDevEndDate = actDevEndDate;
    }

    public LocalDate getActTestStartDate() {
        return actTestStartDate;
    }

    public OrgProject actTestStartDate(LocalDate actTestStartDate) {
        this.actTestStartDate = actTestStartDate;
        return this;
    }

    public void setActTestStartDate(LocalDate actTestStartDate) {
        this.actTestStartDate = actTestStartDate;
    }

    public LocalDate getActTestEndDate() {
        return actTestEndDate;
    }

    public OrgProject actTestEndDate(LocalDate actTestEndDate) {
        this.actTestEndDate = actTestEndDate;
        return this;
    }

    public void setActTestEndDate(LocalDate actTestEndDate) {
        this.actTestEndDate = actTestEndDate;
    }

    public LocalDate getActReleaseDate() {
        return actReleaseDate;
    }

    public OrgProject actReleaseDate(LocalDate actReleaseDate) {
        this.actReleaseDate = actReleaseDate;
        return this;
    }

    public void setActReleaseDate(LocalDate actReleaseDate) {
        this.actReleaseDate = actReleaseDate;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        OrgProject that = (OrgProject) o;
        return Objects.equals(projectId, that.projectId) &&
                Objects.equals(productOrgId, that.productOrgId) &&
                Objects.equals(projectName, that.projectName) &&
                Objects.equals(projectDesc, that.projectDesc) &&
                Objects.equals(projectOwnerId, that.projectOwnerId) &&
                Objects.equals(estPmStartDate, that.estPmStartDate) &&
                Objects.equals(estPmEndDate, that.estPmEndDate) &&
                Objects.equals(estDevStartDate, that.estDevStartDate) &&
                Objects.equals(estDevEndDate, that.estDevEndDate) &&
                Objects.equals(estTestStartDate, that.estTestStartDate) &&
                Objects.equals(estTestEndDate, that.estTestEndDate) &&
                Objects.equals(estReleaseDate, that.estReleaseDate) &&
                Objects.equals(actPmStartDate, that.actPmStartDate) &&
                Objects.equals(actPmEndDate, that.actPmEndDate) &&
                Objects.equals(actDevStartDate, that.actDevStartDate) &&
                Objects.equals(actDevEndDate, that.actDevEndDate) &&
                Objects.equals(actTestStartDate, that.actTestStartDate) &&
                Objects.equals(actTestEndDate, that.actTestEndDate) &&
                Objects.equals(actReleaseDate, that.actReleaseDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(projectId, productOrgId, projectName, projectDesc, projectOwnerId, estPmStartDate, estPmEndDate, estDevStartDate, estDevEndDate, estTestStartDate, estTestEndDate, estReleaseDate, actPmStartDate, actPmEndDate, actDevStartDate, actDevEndDate, actTestStartDate, actTestEndDate, actReleaseDate);
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    @Override
    public String toString() {
        return "OrgProject{" +
                "projectId='" + projectId + '\'' +
                ", productOrgId='" + productOrgId + '\'' +
                ", projectName='" + projectName + '\'' +
                ", projectDesc='" + projectDesc + '\'' +
                ", projectOwnerId='" + projectOwnerId + '\'' +
                ", estPmStartDate=" + estPmStartDate +
                ", estPmEndDate=" + estPmEndDate +
                ", estDevStartDate=" + estDevStartDate +
                ", estDevEndDate=" + estDevEndDate +
                ", estTestStartDate=" + estTestStartDate +
                ", estTestEndDate=" + estTestEndDate +
                ", estReleaseDate=" + estReleaseDate +
                ", actPmStartDate=" + actPmStartDate +
                ", actPmEndDate=" + actPmEndDate +
                ", actDevStartDate=" + actDevStartDate +
                ", actDevEndDate=" + actDevEndDate +
                ", actTestStartDate=" + actTestStartDate +
                ", actTestEndDate=" + actTestEndDate +
                ", actReleaseDate=" + actReleaseDate +
                '}';
    }
}
