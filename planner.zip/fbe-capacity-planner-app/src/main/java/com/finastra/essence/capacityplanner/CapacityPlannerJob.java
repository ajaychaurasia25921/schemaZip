package com.finastra.essence.capacityplanner;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.finastra.essence.capacityplanner.config.ApplicationConfig;

@Component
public class CapacityPlannerJob {

	@Autowired
	private ApplicationConfig quartzConfig;
	
	@Bean
	public JobDetail sampleJobDetail() {
		return JobBuilder.newJob(CapacityPlannerJobProcessor.class).withIdentity("jiraJob").usingJobData("name", "World").storeDurably()
				.build();
	}

	@Bean
	public Trigger sampleJobTrigger() {
		return TriggerBuilder.newTrigger().forJob(sampleJobDetail()).withIdentity("sampleTrigger")
				.withSchedule(CronScheduleBuilder.cronSchedule(quartzConfig.getCronExpressionTime())).build();
	}
	
	
	
}
