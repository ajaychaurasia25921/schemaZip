package com.finastra.essence.capacityplanner.domain;

/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * This class is used to set the roles.
 */
@Entity
@Table(name = "app_role")
public class AppRole extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * Attribute holding the id of an application role.
     */
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "role_id", columnDefinition = "char(36)", unique = true)
    private String roleId;
    /**
     * Attribute holding the name of the application role.
     */
    @NotNull
    @Size(max = 80)
    @Column(name = "role_name", length = 80, nullable = false)
    private String roleName;
    /**
     * Attribute holding the description of the application role.
     */
    @Size(max = 240)
    @Column(name = "role_desc", length = 240)
    private String roleDesc;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    /**
     * This is used to set the serial version ID.
     * @return the serial version of ID.
     */
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    /**
     * This method is used to get the id of the application role
     * @return the id of the application role
     */
    public String getRoleId() {
        return roleId;
    }

    /**
     * This method is used to set the application role
     * @param roleId the id of the application role
     */
    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    /**
     * This method is used to get the name of the application role
     * @return the name of the application role
     */
    public String getRoleName() {
        return roleName;
    }


    /**
     * This method is used to set the name of the application role
     * @param roleName the name of the application role
     */
    public AppRole roleName(String roleName) {
        this.roleName = roleName;
        return this;
    }

    /**
     * This method is used to set the name of the application role
     * @param roleName the name of the application role
     */
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    /**
     * Thie method is used to get the description of the application role
     * @return the description of the application role
     */
    public String getRoleDesc() {
        return roleDesc;
    }
    /**
     * This method is used to set the description of the application role.
     * @param roleDesc the description of the application role
     */
    public AppRole roleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
        return this;
    }

    /**
     * This method is used to set the description of the application role.
     * @param roleDesc the description of the application role
     */
    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AppRole appRole = (AppRole) o;
        return Objects.equals(roleId, appRole.roleId) &&
                Objects.equals(roleName, appRole.roleName) &&
                Objects.equals(roleDesc, appRole.roleDesc);
    }

    @Override
    public int hashCode() {
        return Objects.hash(roleId, roleName, roleDesc);
    }

    @Override
    public String toString() {
        return "AppRole{" +
                "roleId='" + roleId + '\'' +
                ", roleName='" + roleName + '\'' +
                ", roleDesc='" + roleDesc + '\'' +
                '}';
    }
}
