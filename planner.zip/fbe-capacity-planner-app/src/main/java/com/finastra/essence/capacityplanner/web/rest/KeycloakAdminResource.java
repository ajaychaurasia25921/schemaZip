package com.finastra.essence.capacityplanner.web.rest;

import com.finastra.essence.capacityplanner.common.KeycloakDomainResponse;
import com.finastra.essence.capacityplanner.service.KeycloakAdminService;
import org.apache.http.HttpResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * REST controller for managing KeycloakAdmin.
 */
@RestController
@RequestMapping("/api")
public class KeycloakAdminResource {

    private final Logger log = LoggerFactory.getLogger(KeycloakAdminResource.class);

    private static final String ENTITY_NAME = "keycloakAdmin";

    private final KeycloakAdminService keycloakAdminService;

    public KeycloakAdminResource(KeycloakAdminService keycloakAdminService) {
        this.keycloakAdminService = keycloakAdminService;
    }

    @PutMapping("/user")
    public ResponseEntity<HttpResponse> update(@Valid @RequestBody KeycloakDomainResponse keycloakDomainResponse) {
        log.debug("REST request to update Users: {}", keycloakDomainResponse);
        keycloakAdminService.update(keycloakDomainResponse);
        return new ResponseEntity<HttpResponse>(HttpStatus.OK);
    }

}
