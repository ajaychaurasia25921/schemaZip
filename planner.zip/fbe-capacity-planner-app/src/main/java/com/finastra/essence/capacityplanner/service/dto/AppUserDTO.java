package com.finastra.essence.capacityplanner.service.dto;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.finastra.essence.capacityplanner.domain.AbstractAuditingEntity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A DTO for the AppUser entity.
 */
public class AppUserDTO extends AbstractAuditingEntity implements Serializable {

    @Size(max = 36)
    private String userId;

    @NotNull(message = "${jiraId.notnull}")
    private BigDecimal jiraId;

    @NotNull(message = "${jiraUserName.notnull}")
    @Size(max = 255)
    private String jiraUserName;

    @NotNull(message = "{userName.notnull}")
    @Size(max = 80)
    private String userName;

    @NotNull(message = "{userEmail.notnull}")
    @Pattern(regexp = "^[[[\\s]*[A-Za-z.][1-9]?[\\s]]]+@finastra.com$", message = "{userEmail.notvalid}")
    @Size(max = 80)
    private String userEmail;

    @Size(max = 15)
    @Pattern(regexp = "^[0]?[1-9]\\d{9}$", message = "{userMobile.notvalid}")
    private String userMobile;

    @NotNull(message = "{locationId.notnull}")
    @Size(max = 36)
    private String locationId;

    @NotNull(message = "{employeeId.notnull}")
    private Integer employeeId;

    @NotNull(message = "{productOrgId.notnull}")
    @Size(max = 36)
    private String productOrgId;

    @Size(max = 36)
    private String productCategoryId;

    @NotNull(message = "{productFunctionId.notnull}")
    @Size(max = 36)
    private String productFunctionId;

    @NotNull(message = "{skillSetId.notnull}")
    @Size(max = 36)
    private String skillSetId;

    @NotNull(message = "{skillLevelId.notnull}")
    @Size(max = 36)
    private String skillLevelId;

    @NotNull(message = "{jobFunctionId.notnull}")
    @Size(max = 36)
    private String jobFunctionId;

    @NotNull
    @Size(max = 512)
    private String encryptedAccessCode;

    @Size(max = 36)
    private String managerId;

    @NotNull(message = "{contributorFlag.notnull}")
    @Size(max = 1)
    private String contributorFlag;

    private LocalDate joinedDate;


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public BigDecimal getJiraId() {
        return jiraId;
    }

    public void setJiraId(BigDecimal jiraId) {
        this.jiraId = jiraId;
    }

    public String getJiraUserName() {
        return jiraUserName;
    }

    public void setJiraUserName(String jiraUserName) {
        this.jiraUserName = jiraUserName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getProductOrgId() {
        return productOrgId;
    }

    public void setProductOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
    }

    public String getProductCategoryId() {
        return productCategoryId;
    }

    public void setProductCategoryId(String productCategoryId) {
        this.productCategoryId = productCategoryId;
    }

    public String getProductFunctionId() {
        return productFunctionId;
    }

    public void setProductFunctionId(String productFunctionId) {
        this.productFunctionId = productFunctionId;
    }

    public String getSkillSetId() {
        return skillSetId;
    }

    public void setSkillSetId(String skillSetId) {
        this.skillSetId = skillSetId;
    }

    public String getSkillLevelId() {
        return skillLevelId;
    }

    public void setSkillLevelId(String skillLevelId) {
        this.skillLevelId = skillLevelId;
    }

    public String getJobFunctionId() {
        return jobFunctionId;
    }

    public void setJobFunctionId(String jobFunctionId) {
        this.jobFunctionId = jobFunctionId;
    }

    public String getEncryptedAccessCode() {
        return encryptedAccessCode;
    }

    public void setEncryptedAccessCode(String encryptedAccessCode) {
        this.encryptedAccessCode = encryptedAccessCode;
    }

    public String getManagerId() {
        return managerId;
    }

    public void setManagerId(String managerId) {
        this.managerId = managerId;
    }

    public String getContributorFlag() {
        return contributorFlag;
    }

    public void setContributorFlag(String contributorFlag) {
        this.contributorFlag = contributorFlag;
    }

    public LocalDate getJoinedDate() {
        return joinedDate;
    }

    public void setJoinedDate(LocalDate joinedDate) {
        this.joinedDate = joinedDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AppUserDTO appUserDTO = (AppUserDTO) o;
        if (appUserDTO.getUserId() == null || getUserId() == null) {
            return false;
        }
        return Objects.equals(getUserId(), appUserDTO.getUserId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getUserId());
    }

    @Override
    public String toString() {
        return "AppUserDTO{" +
                "userId=" + getUserId() +
                ", jiraId=" + getJiraId() +
                ", jiraUserName='" + getJiraUserName() + "'" +
                ", userName='" + getUserName() + "'" +
                ", userEmail='" + getUserEmail() + "'" +
                ", userMobile='" + getUserMobile() + "'" +
                ", locationId='" + getLocationId() + "'" +
                ", employeeId=" + getEmployeeId() +
                ", productOrgId='" + getProductOrgId() + "'" +
                ", productCategoryId='" + getProductCategoryId() + "'" +
                ", productFunctionId='" + getProductFunctionId() + "'" +
                ", skillSetId='" + getSkillSetId() + "'" +
                ", skillLevelId='" + getSkillLevelId() + "'" +
                ", jobFunctionId='" + getJobFunctionId() + "'" +
                ", encryptedAccessCode='" + getEncryptedAccessCode() + "'" +
                ", managerId='" + getManagerId() + "'" +
                ", contributorFlag='" + getContributorFlag() + "'" +
                ", joinedDate='" + getJoinedDate() + "'" +
                "}";
    }
}
