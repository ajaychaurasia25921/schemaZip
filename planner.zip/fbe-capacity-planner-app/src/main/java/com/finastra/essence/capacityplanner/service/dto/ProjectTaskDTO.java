package com.finastra.essence.capacityplanner.service.dto;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Objects;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.finastra.essence.capacityplanner.domain.AbstractAuditingCustomEntity;

/**
 * A DTO for the ProjectTask entity.
 */
public class ProjectTaskDTO extends AbstractAuditingCustomEntity implements Serializable {

    private String projectTaskId;

    @NotNull
    @Size(max = 36)
    private String productOrgId;

    @NotNull
    @Size(max = 36)
    private String productCategoryId;

    @NotNull
    @Size(max = 36)
    private String productFunctionId;

    @NotNull
    @Size(max = 36)
    private String taskTypeId;

    @NotNull
    @Size(max = 36)
    private String taskCategoryId;

    @NotNull
    @Size(max = 36)
    private String projectId;

    @NotNull
    private BigDecimal jiraIssueId;

    @NotNull
    @Size(max = 255)
    private String jiraPkey;

    @NotNull
    private BigDecimal jiraIssueNum;

    @NotNull
    private BigDecimal jiraProject;

    @Size(max = 255)
    private String jiraReporter;

    @Size(max = 255)
    private String jiraAssignee;

    @Size(max = 255)
    private String jiraIssueType;

    @Size(max = 255)
    private String jiraPriority;

    @Size(max = 255)
    private String jiraResolution;

    @Size(max = 255)
    private String jiraIssueStatus;

    @Size(max = 255)
    private String jiraSummary;

    @Size(max = 36)
    private String jiraProjectId;

    @Size(max = 36)
    private String complexityId;

    @Size(max = 36)
    private String assigneeUserId;

    public String getJiraProjectId() {
        return jiraProjectId;
    }

    public void setJiraProjectId(String jiraProjectId) {
        this.jiraProjectId = jiraProjectId;
    }

    public String getComplexityId() {
        return complexityId;
    }

    public void setComplexityId(String complexityId) {
        this.complexityId = complexityId;
    }

    public String getAssigneeUserId() {
        return assigneeUserId;
    }

    public void setAssigneeUserId(String assigneeUserId) {
        this.assigneeUserId = assigneeUserId;
    }

    private LocalDate jiraEstEndDate;

    private LocalDate jiraEstStartDate;

    private ZonedDateTime jiraUpdated;

    private ZonedDateTime jiraCreated;

    private BigDecimal jiraTimeOrgEstimate;

    private BigDecimal jiraTimeEstimate;

    private BigDecimal jiraTimeSpent;

    public String getProjectTaskId() {
        return projectTaskId;
    }

    public void setProjectTaskId(String projectTaskId) {
        this.projectTaskId = projectTaskId;
    }

    public String getProductOrgId() {
        return productOrgId;
    }

    public void setProductOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
    }

    public String getProductCategoryId() {
        return productCategoryId;
    }

    public void setProductCategoryId(String productCategoryId) {
        this.productCategoryId = productCategoryId;
    }

    public String getProductFunctionId() {
        return productFunctionId;
    }

    public void setProductFunctionId(String productFunctionId) {
        this.productFunctionId = productFunctionId;
    }

    public String getTaskTypeId() {
        return taskTypeId;
    }

    public void setTaskTypeId(String taskTypeId) {
        this.taskTypeId = taskTypeId;
    }

    public String getTaskCategoryId() {
        return taskCategoryId;
    }

    public void setTaskCategoryId(String taskCategoryId) {
        this.taskCategoryId = taskCategoryId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public BigDecimal getJiraIssueId() {
        return jiraIssueId;
    }

    public void setJiraIssueId(BigDecimal jiraIssueId) {
        this.jiraIssueId = jiraIssueId;
    }

    public String getJiraPkey() {
        return jiraPkey;
    }

    public void setJiraPkey(String jiraPkey) {
        this.jiraPkey = jiraPkey;
    }

    public BigDecimal getJiraIssueNum() {
        return jiraIssueNum;
    }

    public void setJiraIssueNum(BigDecimal jiraIssueNum) {
        this.jiraIssueNum = jiraIssueNum;
    }

    public BigDecimal getJiraProject() {
        return jiraProject;
    }

    public void setJiraProject(BigDecimal jiraProject) {
        this.jiraProject = jiraProject;
    }

    public String getJiraReporter() {
        return jiraReporter;
    }

    public void setJiraReporter(String jiraReporter) {
        this.jiraReporter = jiraReporter;
    }

    public String getJiraAssignee() {
        return jiraAssignee;
    }

    public void setJiraAssignee(String jiraAssignee) {
        this.jiraAssignee = jiraAssignee;
    }

    public String getJiraIssueType() {
        return jiraIssueType;
    }

    public void setJiraIssueType(String jiraIssueType) {
        this.jiraIssueType = jiraIssueType;
    }

    public String getJiraPriority() {
        return jiraPriority;
    }

    public void setJiraPriority(String jiraPriority) {
        this.jiraPriority = jiraPriority;
    }

    public String getJiraResolution() {
        return jiraResolution;
    }

    public void setJiraResolution(String jiraResolution) {
        this.jiraResolution = jiraResolution;
    }

    public String getJiraIssueStatus() {
        return jiraIssueStatus;
    }

    public void setJiraIssueStatus(String jiraIssueStatus) {
        this.jiraIssueStatus = jiraIssueStatus;
    }

    public LocalDate getJiraEstEndDate() {
        return jiraEstEndDate;
    }

    public void setJiraEstEndDate(LocalDate jiraEstEndDate) {
        this.jiraEstEndDate = jiraEstEndDate;
    }

    public LocalDate getJiraEstStartDate() {
        return jiraEstStartDate;
    }

    public void setJiraEstStartDate(LocalDate jiraEstStartDate) {
        this.jiraEstStartDate = jiraEstStartDate;
    }

    public ZonedDateTime getJiraUpdated() {
        return jiraUpdated;
    }

    public void setJiraUpdated(ZonedDateTime jiraUpdated) {
        this.jiraUpdated = jiraUpdated;
    }

    public ZonedDateTime getJiraCreated() {
        return jiraCreated;
    }

    public void setJiraCreated(ZonedDateTime jiraCreated) {
        this.jiraCreated = jiraCreated;
    }

    public BigDecimal getJiraTimeOrgEstimate() {
        return jiraTimeOrgEstimate;
    }

    public void setJiraTimeOrgEstimate(BigDecimal jiraTimeOrgEstimate) {
        this.jiraTimeOrgEstimate = jiraTimeOrgEstimate;
    }

    public BigDecimal getJiraTimeEstimate() {
        return jiraTimeEstimate;
    }

    public void setJiraTimeEstimate(BigDecimal jiraTimeEstimate) {
        this.jiraTimeEstimate = jiraTimeEstimate;
    }

    public BigDecimal getJiraTimeSpent() {
        return jiraTimeSpent;
    }

    public void setJiraTimeSpent(BigDecimal jiraTimeSpent) {
        this.jiraTimeSpent = jiraTimeSpent;
    }

    public String getJiraSummary() {
        return jiraSummary;
    }

    public void setJiraSummary(String jiraSummary) {
        this.jiraSummary = jiraSummary;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProjectTaskDTO that = (ProjectTaskDTO) o;
        return Objects.equals(projectTaskId, that.projectTaskId) &&
                Objects.equals(productOrgId, that.productOrgId) &&
                Objects.equals(productCategoryId, that.productCategoryId) &&
                Objects.equals(productFunctionId, that.productFunctionId) &&
                Objects.equals(taskTypeId, that.taskTypeId) &&
                Objects.equals(taskCategoryId, that.taskCategoryId) &&
                Objects.equals(projectId, that.projectId) &&
                Objects.equals(jiraIssueId, that.jiraIssueId) &&
                Objects.equals(jiraPkey, that.jiraPkey) &&
                Objects.equals(jiraIssueNum, that.jiraIssueNum) &&
                Objects.equals(jiraProject, that.jiraProject) &&
                Objects.equals(jiraReporter, that.jiraReporter) &&
                Objects.equals(jiraAssignee, that.jiraAssignee) &&
                Objects.equals(jiraIssueType, that.jiraIssueType) &&
                Objects.equals(jiraPriority, that.jiraPriority) &&
                Objects.equals(jiraResolution, that.jiraResolution) &&
                Objects.equals(jiraIssueStatus, that.jiraIssueStatus) &&
                Objects.equals(jiraSummary, that.jiraSummary) &&
                Objects.equals(jiraProjectId, that.jiraProjectId) &&
                Objects.equals(complexityId, that.complexityId) &&
                Objects.equals(assigneeUserId, that.assigneeUserId) &&
                Objects.equals(jiraEstEndDate, that.jiraEstEndDate) &&
                Objects.equals(jiraEstStartDate, that.jiraEstStartDate) &&
                Objects.equals(jiraUpdated, that.jiraUpdated) &&
                Objects.equals(jiraCreated, that.jiraCreated) &&
                Objects.equals(jiraTimeOrgEstimate, that.jiraTimeOrgEstimate) &&
                Objects.equals(jiraTimeEstimate, that.jiraTimeEstimate) &&
                Objects.equals(jiraTimeSpent, that.jiraTimeSpent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(projectTaskId, productOrgId, productCategoryId, productFunctionId, taskTypeId, taskCategoryId, projectId, jiraIssueId, jiraPkey, jiraIssueNum, jiraProject, jiraReporter, jiraAssignee, jiraIssueType, jiraPriority, jiraResolution, jiraIssueStatus, jiraSummary, jiraProjectId, complexityId, assigneeUserId, jiraEstEndDate, jiraEstStartDate, jiraUpdated, jiraCreated, jiraTimeOrgEstimate, jiraTimeEstimate, jiraTimeSpent);
    }

    @Override
    public String toString() {
        return "ProjectTaskDTO{" +
                "projectTaskId='" + projectTaskId + '\'' +
                ", productOrgId='" + productOrgId + '\'' +
                ", productCategoryId='" + productCategoryId + '\'' +
                ", productFunctionId='" + productFunctionId + '\'' +
                ", taskTypeId='" + taskTypeId + '\'' +
                ", taskCategoryId='" + taskCategoryId + '\'' +
                ", projectId='" + projectId + '\'' +
                ", jiraIssueId=" + jiraIssueId +
                ", jiraPkey='" + jiraPkey + '\'' +
                ", jiraIssueNum=" + jiraIssueNum +
                ", jiraProject=" + jiraProject +
                ", jiraReporter='" + jiraReporter + '\'' +
                ", jiraAssignee='" + jiraAssignee + '\'' +
                ", jiraIssueType='" + jiraIssueType + '\'' +
                ", jiraPriority='" + jiraPriority + '\'' +
                ", jiraResolution='" + jiraResolution + '\'' +
                ", jiraIssueStatus='" + jiraIssueStatus + '\'' +
                ", jiraSummary='" + jiraSummary + '\'' +
                ", jiraProjectId='" + jiraProjectId + '\'' +
                ", complexityId='" + complexityId + '\'' +
                ", assigneeUser='" + assigneeUserId + '\'' +
                ", jiraEstEndDate=" + jiraEstEndDate +
                ", jiraEstStartDate=" + jiraEstStartDate +
                ", jiraUpdated=" + jiraUpdated +
                ", jiraCreated=" + jiraCreated +
                ", jiraTimeOrgEstimate=" + jiraTimeOrgEstimate +
                ", jiraTimeEstimate=" + jiraTimeEstimate +
                ", jiraTimeSpent=" + jiraTimeSpent +
                '}';
    }
}