/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.finastra.essence.capacityplanner.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.EmailingService;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.AppUser;
import com.finastra.essence.capacityplanner.domain.ProjectTask;
import com.finastra.essence.capacityplanner.domain.ProjectTask_;
import com.finastra.essence.capacityplanner.repository.AppUserRepository;
import com.finastra.essence.capacityplanner.repository.ProjectTaskRepository;
import com.finastra.essence.capacityplanner.service.dto.ProjectTaskCriteria;
import com.finastra.essence.capacityplanner.service.dto.ProjectTaskDTO;
import com.finastra.essence.capacityplanner.service.mapper.ProjectTaskMapper;
import io.github.jhipster.service.QueryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.CompletableFuture;

/**
 * Service for executing complex queries for {@link ProjectTask} entities in the database.
 * The main input is a {@link ProjectTaskCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link ProjectTaskDTO} or a {@link Page} of {@link ProjectTaskDTO} which fulfills the filter.
 */
@Service
@Transactional(readOnly = true)
@RefreshScope
public class ProjectTaskQueryService extends QueryService<ProjectTask> {

    @Value("${filePath}")
    private String filePath;

    @Value("${host}")
    private String host;

    @Value("${port}")
    private String port;

    @Value("${sender}")
    private String from;

    @Value("${templatePath}")
    private String templatePath;

    private final Logger log = LoggerFactory.getLogger(ProjectTaskQueryService.class);

    private final ProjectTaskRepository projectTaskRepository;

    private final AppUserRepository appUserRepository;

    private final ProjectTaskMapper projectTaskMapper;

    private final EmailingService emailingService = new EmailingService();

    private final ErrorDetails errorDetails = new ErrorDetails();

    public ProjectTaskQueryService(ProjectTaskRepository projectTaskRepository, AppUserRepository appUserRepository, ProjectTaskMapper projectTaskMapper) {
        this.projectTaskRepository = projectTaskRepository;
        this.appUserRepository = appUserRepository;
        this.projectTaskMapper = projectTaskMapper;
    }


    /**
     * Return a {@link Page} of {@link ProjectTaskDTO} which matches the filter from the database.
     *
     * @param filter The object which holds all the filters, which the entities should match.
     * @param page   The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<ProjectTaskDTO> findByCriteria(ProjectTaskCriteria filter, Pageable page) {
        log.debug("find by filter : {}, page: {} , findPath: {}", filter, page , filePath);
        final Specification<ProjectTask> specification = createSpecification(filter);
        return projectTaskRepository.findAll(specification, page)
                .map(projectTaskMapper::toDto);
    }

    /**
     * Function to convert ProjectTaskCriteria to a {@link Specification}.
     */
    private Specification<ProjectTask> createSpecification(ProjectTaskCriteria filter) {
        Specification<ProjectTask> specification = Specification.where(null);
        if (filter != null) {
            if (filter.getProjectTaskId() != null) {
                specification = specification.and(buildStringSpecification(filter.getProjectTaskId(), ProjectTask_.projectTaskId));
            }
            if (filter.getProductOrgId() != null) {
                specification = specification.and(buildStringSpecification(filter.getProductOrgId(), ProjectTask_.productOrgId));
            }
            if (filter.getProductCategoryId() != null) {
                specification = specification.and(buildStringSpecification(filter.getProductCategoryId(), ProjectTask_.productCategoryId));
            }
            if (filter.getProductFunctionId() != null) {
                specification = specification.and(buildStringSpecification(filter.getProductFunctionId(), ProjectTask_.productFunctionId));
            }
            if (filter.getTaskTypeId() != null) {
                specification = specification.and(buildStringSpecification(filter.getTaskTypeId(), ProjectTask_.taskTypeId));
            }
            if (filter.getTaskCategoryId() != null) {
                specification = specification.and(buildStringSpecification(filter.getTaskCategoryId(), ProjectTask_.taskCategoryId));
            }
            if (filter.getProjectId() != null) {
                specification = specification.and(buildStringSpecification(filter.getProjectId(), ProjectTask_.projectId));
            }
            if (filter.getJiraIssueId() != null) {
                specification = specification.and(buildRangeSpecification(filter.getJiraIssueId(), ProjectTask_.jiraIssueId));
            }
            if (filter.getJiraPkey() != null) {
                specification = specification.and(buildStringSpecification(filter.getJiraPkey(), ProjectTask_.jiraPkey));
            }
            if (filter.getJiraIssueNum() != null) {
                specification = specification.and(buildRangeSpecification(filter.getJiraIssueNum(), ProjectTask_.jiraIssueNum));
            }
            if (filter.getJiraProject() != null) {
                specification = specification.and(buildRangeSpecification(filter.getJiraProject(), ProjectTask_.jiraProject));
            }
            if (filter.getJiraReporter() != null) {
                specification = specification.and(buildStringSpecification(filter.getJiraReporter(), ProjectTask_.jiraReporter));
            }
            if (filter.getJiraAssignee() != null) {
                specification = specification.and(buildStringSpecification(filter.getJiraAssignee(), ProjectTask_.jiraAssignee));
            }
            if (filter.getJiraIssueType() != null) {
                specification = specification.and(buildStringSpecification(filter.getJiraIssueType(), ProjectTask_.jiraIssueType));
            }
            if (filter.getJiraPriority() != null) {
                specification = specification.and(buildStringSpecification(filter.getJiraPriority(), ProjectTask_.jiraPriority));
            }
            if (filter.getJiraResolution() != null) {
                specification = specification.and(buildStringSpecification(filter.getJiraResolution(), ProjectTask_.jiraResolution));
            }
            if (filter.getJiraIssueStatus() != null) {
                specification = specification.and(buildStringSpecification(filter.getJiraIssueStatus(), ProjectTask_.jiraIssueStatus));
            }
            if (filter.getJiraTimeOrgEstimate() != null) {
                specification = specification.and(buildRangeSpecification(filter.getJiraTimeOrgEstimate(), ProjectTask_.jiraTimeOrgEstimate));
            }
            if (filter.getJiraTimeEstimate() != null) {
                specification = specification.and(buildRangeSpecification(filter.getJiraTimeEstimate(), ProjectTask_.jiraTimeEstimate));
            }
            if (filter.getJiraTimeSpent() != null) {
                specification = specification.and(buildRangeSpecification(filter.getJiraTimeSpent(), ProjectTask_.jiraTimeSpent));
            }
            if (filter.getJiraProjectId() != null) {
                specification = specification.and(buildStringSpecification(filter.getJiraProjectId(), ProjectTask_.jiraProjectId));
            }
        }
        return specification;
    }

    private String getUTCDateTime(){
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        return dateFormat.format(date).replace(" ","-").replace(":","-");
    }

    public void JsonToCSV(List<ProjectTaskDTO> content,String username) {
        CompletableFuture.runAsync(() -> {
            CsvMapper csvMapper = new CsvMapper();
            csvMapper.findAndRegisterModules();
            csvMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
            try {
                CsvSchema schema = csvMapper.schemaFor(ProjectTaskDTO.class).withHeader();
                ObjectWriter objectWriter = csvMapper.writer(schema);
                AppUser recipient= appUserRepository.findByJiraUserName(username).get();
                String csvFile = filePath+""+recipient.getUserName()+"-capacity-planner-report-"+getUTCDateTime()+".csv";
                File tempFile = new File(csvFile);
                FileOutputStream tempFileOutputStream = new FileOutputStream(tempFile);
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(tempFileOutputStream, 1024);
                OutputStreamWriter writerOutputStream = new OutputStreamWriter(bufferedOutputStream, "UTF-8");
                objectWriter.writeValue(writerOutputStream, content);
                 emailingService.sentMailTo(csvFile,recipient,host,port,from,templatePath);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
