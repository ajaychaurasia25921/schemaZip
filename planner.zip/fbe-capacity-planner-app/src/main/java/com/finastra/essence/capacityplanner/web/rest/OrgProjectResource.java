package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.OrgProjectService;
import com.finastra.essence.capacityplanner.service.dto.OrgProjectDTO;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing OrgProject.
 */
@RestController
@RequestMapping("/api")
public class OrgProjectResource {

    private final Logger log = LoggerFactory.getLogger(OrgProjectResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppOrgProject";

    private final OrgProjectService orgProjectService;

    public OrgProjectResource(OrgProjectService orgProjectService) {
        this.orgProjectService = orgProjectService;
    }

    /**
     * POST  /org-projects : Create a new orgProject.
     *
     * @param orgProjectDTO the orgProjectDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new orgProjectDTO, or with status 400 (Bad Request) if the orgProject has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/org-projects")
    public ResponseEntity<OrgProjectDTO> createOrgProject(@Valid @RequestBody OrgProjectDTO orgProjectDTO) throws URISyntaxException {
        log.debug("REST request to save OrgProject : {}", orgProjectDTO);
        OrgProjectDTO result = orgProjectService.save(orgProjectDTO);
        return ResponseEntity.created(new URI("/api/org-projects/" + result.getProjectId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getProjectId()))
                .body(result);
    }

    /**
     * PUT  /org-projects : Updates an existing orgProject.
     *
     * @param orgProjectDTO the orgProjectDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated orgProjectDTO,
     * or with status 400 (Bad Request) if the orgProjectDTO is not valid,
     * or with status 500 (Internal Server Error) if the orgProjectDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/org-projects")
    public ResponseEntity<OrgProjectDTO> updateOrgProject(@Valid @RequestBody OrgProjectDTO orgProjectDTO) throws URISyntaxException {
        log.debug("REST request to update OrgProject : {}", orgProjectDTO);
        OrgProjectDTO result = orgProjectService.update(orgProjectDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, orgProjectDTO.getProjectId())).build();
    }

    /**
     * GET  /org-projects : get all the orgProjects.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of orgProjects in body
     */
    @GetMapping("/org-projects")
    public ResponseEntity<List<OrgProjectDTO>> getAllOrgProjects(@RequestParam(required = false) String productOrgId, Pageable pageable) {
        log.debug("REST request to get a page of OrgProjects");
        if (null != productOrgId && !productOrgId.isEmpty()) {
            return ResponseEntity.ok().body(orgProjectService.findByProductOrgId(productOrgId));
        }
        Page<OrgProjectDTO> page = orgProjectService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/org-projects");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /org-projects/:id : get the "id" orgProject.
     *
     * @param id the id of the orgProjectDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the orgProjectDTO, or with status 404 (Not Found)
     */
    @GetMapping("/org-projects/{id}")
    public ResponseEntity<OrgProjectDTO> getOrgProject(@PathVariable String id) {
        log.debug("REST request to get OrgProject : {}", id);
        Optional<OrgProjectDTO> orgProjectDTO = orgProjectService.findOne(id);
        return ResponseUtil.wrapOrNotFound(orgProjectDTO);
    }

    /**
     * DELETE  /org-projects/:id : delete the "id" orgProject.
     *
     * @param id the id of the orgProjectDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/org-projects/{id}")
    public ResponseEntity<Void> deleteOrgProject(@PathVariable String id) {
        log.debug("REST request to delete OrgProject : {}", id);
        orgProjectService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
