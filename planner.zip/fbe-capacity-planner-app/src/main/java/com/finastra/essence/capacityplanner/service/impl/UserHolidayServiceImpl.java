package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.UserHoliday;
import com.finastra.essence.capacityplanner.repository.AppUserRepository;
import com.finastra.essence.capacityplanner.repository.UserHolidayRepository;
import com.finastra.essence.capacityplanner.service.UserHolidayService;
import com.finastra.essence.capacityplanner.service.dto.UserHolidayDTO;
import com.finastra.essence.capacityplanner.service.mapper.UserHolidayMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing {@link UserHoliday}.
 */
@Service
@Transactional
public class UserHolidayServiceImpl implements UserHolidayService {

    private final Logger log = LoggerFactory.getLogger(UserHolidayServiceImpl.class);

    private final UserHolidayRepository userHolidayRepository;

    private final UserHolidayMapper userHolidayMapper;
    /**
     * Attribute holding the reference of error details.
     */
    private final ErrorDetails errorDetails = new ErrorDetails();
    /**
     * Attribute holding the reference of app user repository.
     */
    private final AppUserRepository appUserRepository;

    public UserHolidayServiceImpl(AppUserRepository appUserRepository, UserHolidayRepository userHolidayRepository, UserHolidayMapper userHolidayMapper) {
        this.appUserRepository = appUserRepository;
        this.userHolidayRepository = userHolidayRepository;
        this.userHolidayMapper = userHolidayMapper;
    }

   /**
     * This function is used to fetch list of holidays taken by user by userId
     * @param userId the id of the user
     * @return fetch list of holidays taken by user.
     */
    @Override
    public List<UserHolidayDTO> findByUserIdAndActiveFlag(String userId,boolean activeFlag) {
        if (!appUserRepository.existsById(userId)) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }
        return userHolidayMapper.toDto(userHolidayRepository.findByUserIdAndActiveFlag(userId,activeFlag));
    }
	/**
     * This function is used to fetch list of active holidays.
     *
     * @param activeFlag the active holidays.
     * @return fetch list of active holidays.
     */
 @Override
    public List<UserHolidayDTO> findByActiveFlag(boolean activeFlag) {
        return userHolidayMapper.toDto(userHolidayRepository.findByActiveFlag(activeFlag));
    }
    /**
     * Save a userHoliday.
     *
     * @param userHolidayDTO the entity to save.
     * @return the persisted entity.
     */
    @Override
    public UserHolidayDTO save(UserHolidayDTO userHolidayDTO) {
        log.debug("Request to save UserHoliday : {}", userHolidayDTO);
        validateIdDuringPostOperation(userHolidayDTO);
        validateWhetherIdExists(userHolidayDTO);
        try{
            UserHoliday userHoliday = userHolidayMapper.toEntity(userHolidayDTO);
            userHoliday = userHolidayRepository.saveAndFlush(userHoliday);
            return userHolidayMapper.toDto(userHoliday);
        }catch (DataIntegrityViolationException e){
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails,e);
        }catch (Exception e){
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails,e);
        }
       }

    private void validateIdDuringPostOperation(UserHolidayDTO userHolidayDTO) {
        if (null != userHolidayDTO.getHolidayId() && !userHolidayDTO.getHolidayId().isEmpty()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.AUTOGEN_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    @Override
    public UserHolidayDTO update(UserHolidayDTO userHolidayDTO) {
        validateIdDuringPutOperation(userHolidayDTO);
        validateWhetherIdExists(userHolidayDTO);
        UserHoliday userHoliday;
        try {
            Optional<UserHoliday> userHolidayRepositoryById = userHolidayRepository.findById(userHolidayDTO.getHolidayId());
            if (userHolidayRepositoryById.isPresent()) {
                userHoliday = userHolidayMapper.toEntity(userHolidayDTO);
                if (userHoliday.equals(userHolidayRepositoryById.get())) {
                    throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NO_CHANGE_FOUND));
                } else {
                    userHolidayRepository.save(userHolidayMapper.toEntity(userHolidayDTO));
                }
            } else {
                throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            }
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);

        }

        return userHolidayMapper.toDto(userHoliday);
    }

    private void validateIdDuringPutOperation(UserHolidayDTO userHolidayDTO) {
        if (userHolidayDTO.getHolidayId().isEmpty() && null == userHolidayDTO.getHolidayId()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.PROVIDE_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    private void validateWhetherIdExists(UserHolidayDTO userHolidayDTO) {
        if (!appUserRepository.existsById(userHolidayDTO.getUserId())) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
        }
    }

    /**
     * Get all the userHolidays.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<UserHolidayDTO> findAll(Pageable pageable) {
        log.debug("Request to get all UserHolidays");
        return userHolidayRepository.findAll(pageable)
                .map(userHolidayMapper::toDto);
    }


    /**
     * Get one userHoliday by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<UserHolidayDTO> findOne(String id) {
        log.debug("Request to get UserHoliday : {}", id);
        return userHolidayRepository.findById(id)
                .map(userHolidayMapper::toDto);
    }

    /**
     * Delete the userHoliday by id.
     *
     * @param id the id of the entity.
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete UserHoliday : {}", id);
        Optional<UserHoliday> userHolidayRepositoryById = userHolidayRepository.findById(id);
        userHolidayRepositoryById.ifPresent(userHoliday -> userHoliday.setActiveFlag(false));
    }
}
