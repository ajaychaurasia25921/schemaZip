package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.OrgProject;
import com.finastra.essence.capacityplanner.repository.AppUserRepository;
import com.finastra.essence.capacityplanner.repository.OrgProjectRepository;
import com.finastra.essence.capacityplanner.service.OrgProjectService;
import com.finastra.essence.capacityplanner.service.dto.OrgProjectDTO;
import com.finastra.essence.capacityplanner.service.mapper.OrgProjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing OrgProject.
 */
@Service
@Transactional
public class OrgProjectServiceImpl implements OrgProjectService {

    private final Logger log = LoggerFactory.getLogger(OrgProjectServiceImpl.class);
    /**
     * Attribute holding the reference of org project repository.
     */
    private final OrgProjectRepository orgProjectRepository;
    /**
     * Attribute holding the reference of app user repository.
     */
    private final AppUserRepository appUserRepository;
    /**
     * Attribute holding the reference of org project mapper.
     */
    private final OrgProjectMapper orgProjectMapper;
    /**
     * Attribute holding the reference of error details.
     */
    private final ErrorDetails errorDetails = new ErrorDetails();

    /**
     * This is used to initialize the repository and mapper.
     *
     * @param orgProjectRepository org project repository.
     * @param orgProjectMapper     org project mapper.
     */
    public OrgProjectServiceImpl(OrgProjectRepository orgProjectRepository, AppUserRepository appUserRepository, OrgProjectMapper orgProjectMapper) {
        this.orgProjectRepository = orgProjectRepository;
        this.appUserRepository = appUserRepository;
        this.orgProjectMapper = orgProjectMapper;
    }

    /**
     * Save a orgProject.
     *
     * @param orgProjectDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public OrgProjectDTO save(OrgProjectDTO orgProjectDTO) {
        log.debug("Request to save OrgProject : {}", orgProjectDTO);
        validateIdDuringPostOperation(orgProjectDTO);
        validateWhetherIdExists(orgProjectDTO);
        validateActDevDate(orgProjectDTO);
        validateActTestDate(orgProjectDTO);
        validateActPmDate(orgProjectDTO);
        validateEstPmDate(orgProjectDTO);
        validateEstDevDate(orgProjectDTO);
        validateEstTestDate(orgProjectDTO);
        try {
            OrgProject orgProject = orgProjectMapper.toEntity(orgProjectDTO);
            orgProject = orgProjectRepository.saveAndFlush(orgProject);
            return orgProjectMapper.toDto(orgProject);
        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails, e);
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }
    }

    @Override
    public OrgProjectDTO update(OrgProjectDTO orgProjectDTO) {
        log.debug("Request to update OrgProject : {}", orgProjectDTO);
        validateIdDuringPutOperation(orgProjectDTO);
        validateWhetherIdExists(orgProjectDTO);
        OrgProject orgProject;
        try {
            Optional<OrgProject> orgProjectRepositoryById = orgProjectRepository.findById(orgProjectDTO.getProjectId());
            if (orgProjectRepositoryById.isPresent()) {
                orgProject = orgProjectMapper.toEntity(orgProjectDTO);

                if (orgProject.equals(orgProjectRepositoryById.get())) {
                    throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NO_CHANGE_FOUND));
                } else {
                    orgProjectRepository.save(orgProjectMapper.toEntity(orgProjectDTO));
                }
            } else {
                throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            }
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }

        return orgProjectMapper.toDto(orgProject);
    }

    private void validateIdDuringPutOperation(OrgProjectDTO orgProjectDTO) {
        if (orgProjectDTO.getProjectId().isEmpty() && null == orgProjectDTO.getProjectId()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.PROVIDE_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    private void validateWhetherIdExists(OrgProjectDTO orgProjectDTO) {
        List<String> errorMessage = new ArrayList<>();
        if (!orgProjectRepository.existsByProductOrgId(orgProjectDTO.getProductOrgId())) {
            errorMessage.add("ProductOrgId");
        }
        if (!appUserRepository.existsById(orgProjectDTO.getProjectOwnerId())) {
            errorMessage.add("ProjectOwnerId");
        }
        if (!errorMessage.isEmpty()) {
            errorDetails.setDetail("The dependency(s) doesn't exist :" + errorMessage);
            throw new UserDefinedException(errorDetails);

        }
    }

    private void validateIdDuringPostOperation(OrgProjectDTO orgProjectDTO) {
        if (null != orgProjectDTO.getProjectId() && !orgProjectDTO.getProjectId().isEmpty()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.AUTOGEN_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * This method is used to validate the act pm date.
     *
     * @param orgProjectDTO the entity to validate.
     */
    private void validateActPmDate(OrgProjectDTO orgProjectDTO) {
        if (orgProjectDTO.getActPmEndDate().isBefore(orgProjectDTO.getActPmStartDate())) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ACT_PM_DATE));
        }

    }

    /**
     * This method is used to validate the estimated test date.
     *
     * @param orgProjectDTO the entity to validate.
     */
    private void validateEstTestDate(OrgProjectDTO orgProjectDTO) {
        if (orgProjectDTO.getEstTestEndDate().isBefore(orgProjectDTO.getEstTestStartDate())) {
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_EST_TEST_DEV_DATE));
        }

    }

    /**
     * This method is used to validate the estimated development date.
     *
     * @param orgProjectDTO the entity to validate
     */
    private void validateEstDevDate(OrgProjectDTO orgProjectDTO) {
        if (orgProjectDTO.getEstDevEndDate().isBefore(orgProjectDTO.getEstDevStartDate())) {
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_EST_DEV_DATE));
        }

    }

    /**
     * This method is used to validate the estimated pm date.
     *
     * @param orgProjectDTO the entity to validate
     */
    private void validateEstPmDate(OrgProjectDTO orgProjectDTO) {
        if (orgProjectDTO.getEstPmEndDate().isBefore(orgProjectDTO.getEstPmStartDate())) {
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_EST_PM_DATE));
        }

    }

    /**
     * This method is used to validate the act test date.
     *
     * @param orgProjectDTO the entity to validate.
     */
    private void validateActTestDate(OrgProjectDTO orgProjectDTO) {
        if (orgProjectDTO.getActTestEndDate().isBefore(orgProjectDTO.getActTestStartDate())) {
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ACT_TEST_DATE));
        }

    }

    /**
     * This method is used to validate the act dev date.
     *
     * @param orgProjectDTO the entity to validate.
     */
    private void validateActDevDate(OrgProjectDTO orgProjectDTO) {
        if (orgProjectDTO.getActDevEndDate().isBefore(orgProjectDTO.getActDevStartDate())) {
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ACT_DEV_DATE));
        }

    }

    /**
     * Get all the orgProjects.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<OrgProjectDTO> findAll(Pageable pageable) {
        log.debug("Request to get all OrgProjects");
        return orgProjectRepository.findAll(pageable)
                .map(orgProjectMapper::toDto);
    }

    @Override
    public List<OrgProjectDTO> findByProductOrgId(String productOrgId) {
        if (!orgProjectRepository.existsByProductOrgId(productOrgId)) {
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }
        return orgProjectMapper.toDto(orgProjectRepository.findByProductOrgId(productOrgId));
    }


    /**
     * Get one orgProject by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<OrgProjectDTO> findOne(String id) {
        log.debug("Request to get OrgProject : {}", id);
        return orgProjectRepository.findById(id)
                .map(orgProjectMapper::toDto);
    }

    /**
     * Delete the orgProject by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete OrgProject : {}", id);
        Optional<OrgProject> orgProjectRepositoryById = orgProjectRepository.findById(id);
        orgProjectRepositoryById.ifPresent(orgProject -> orgProject.setActiveFlag(false));
    }
}
