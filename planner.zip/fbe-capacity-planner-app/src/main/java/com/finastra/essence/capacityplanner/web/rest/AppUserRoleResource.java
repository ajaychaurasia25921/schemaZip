package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.AppUserRoleService;
import com.finastra.essence.capacityplanner.service.dto.AppUserRoleDTO;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing AppUserRole.
 */
@RestController
@RequestMapping("/api")
public class AppUserRoleResource {

    private final Logger log = LoggerFactory.getLogger(AppUserRoleResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppAppUserRole";

    private final AppUserRoleService appUserRoleService;

    public AppUserRoleResource(AppUserRoleService appUserRoleService) {
        this.appUserRoleService = appUserRoleService;
    }

    /**
     * POST  /app-user-roles : Create a new appUserRole.
     *
     * @param appUserRoleDTO the appUserRoleDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new appUserRoleDTO, or with status 400 (Bad Request) if the appUserRole has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/app-user-roles")
    public ResponseEntity<AppUserRoleDTO> createAppUserRole(@Valid @RequestBody AppUserRoleDTO appUserRoleDTO) throws URISyntaxException {
        log.debug("REST request to save AppUserRole : {}", appUserRoleDTO);
        AppUserRoleDTO result = appUserRoleService.save(appUserRoleDTO);
        return ResponseEntity.created(new URI("/api/app-user-roles/" + result.getUserRoleId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getUserRoleId()))
                .body(result);
    }

    /**
     * PUT  /app-user-roles : Updates an existing appUserRole.
     *
     * @param appUserRoleDTO the appUserRoleDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated appUserRoleDTO,
     * or with status 400 (Bad Request) if the appUserRoleDTO is not valid,
     * or with status 500 (Internal Server Error) if the appUserRoleDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/app-user-roles")
    public ResponseEntity<AppUserRoleDTO> updateAppUserRole(@Valid @RequestBody AppUserRoleDTO appUserRoleDTO) throws URISyntaxException {
        log.debug("REST request to update AppUserRole : {}", appUserRoleDTO);
        AppUserRoleDTO result = appUserRoleService.update(appUserRoleDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, appUserRoleDTO.getUserRoleId()))
                .body(result);
    }

    /**
     * GET  /app-user-roles : get all the appUserRoles.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of appUserRoles in body
     */
    @GetMapping("/app-user-roles")
    public ResponseEntity<List<AppUserRoleDTO>> getAllAppUserRoles(@RequestParam(required = false) String roleId, Pageable pageable) {
        log.debug("REST request to get a page of AppUserRoles");
        if (null != roleId && !roleId.isEmpty()) {
            return ResponseEntity.ok().body(appUserRoleService.findByRoleId(roleId));
        }
        Page<AppUserRoleDTO> page = appUserRoleService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/app-user-roles");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /app-user-roles/:id : get the "id" appUserRole.
     *
     * @param id the id of the appUserRoleDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the appUserRoleDTO, or with status 404 (Not Found)
     */
    @GetMapping("/app-user-roles/{id}")
    public ResponseEntity<AppUserRoleDTO> getAppUserRole(@PathVariable String id) {
        log.debug("REST request to get AppUserRole : {}", id);
        Optional<AppUserRoleDTO> appUserRoleDTO = appUserRoleService.findOne(id);
        return ResponseUtil.wrapOrNotFound(appUserRoleDTO);
    }

    /**
     * GET  /app-user-roles/:username : get the "username" appUserRole.
     *
     * @param username the username of the appUserRoleDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the appUserRoleDTO, or with status 404 (Not Found)
     */
    @GetMapping("/app-user-roles/username/{username}")
    public List<String> getAppUserRoleByUserName(@PathVariable String username) {
        log.debug("REST request to get AppUserRole by username : {}", username);
        List<String> appUserRoleDTO = appUserRoleService.findByUserName(username);
        return appUserRoleDTO;
    }

    /**
     * DELETE  /app-user-roles/:id : delete the "id" appUserRole.
     *
     * @param id the id of the appUserRoleDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/app-user-roles/{id}")
    public ResponseEntity<Void> deleteAppUserRole(@PathVariable String id) {
        log.debug("REST request to delete AppUserRole : {}", id);
        appUserRoleService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
