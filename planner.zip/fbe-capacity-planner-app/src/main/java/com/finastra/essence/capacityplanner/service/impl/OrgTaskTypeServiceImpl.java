package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.OrgTaskType;
import com.finastra.essence.capacityplanner.repository.OrgTaskTypeRepository;
import com.finastra.essence.capacityplanner.service.OrgTaskTypeService;
import com.finastra.essence.capacityplanner.service.dto.OrgTaskTypeDTO;
import com.finastra.essence.capacityplanner.service.mapper.OrgTaskTypeMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing OrgTaskType.
 */
@Service
@Transactional
public class OrgTaskTypeServiceImpl implements OrgTaskTypeService {

    private final Logger log = LoggerFactory.getLogger(OrgTaskTypeServiceImpl.class);
    /**
     * Attribute holding the reference for the org task type repository.
     */
    private final OrgTaskTypeRepository orgTaskTypeRepository;
    /**
     * Attribute holding the reference for the org task type mapper.
     */
    private final OrgTaskTypeMapper orgTaskTypeMapper;
    /**
     * This is used to initialize the repository and mapper.
     * @param orgTaskTypeRepository org task type repository.
     * @param orgTaskTypeMapper org task type mapper.
     */
    public OrgTaskTypeServiceImpl(OrgTaskTypeRepository orgTaskTypeRepository, OrgTaskTypeMapper orgTaskTypeMapper) {
        this.orgTaskTypeRepository = orgTaskTypeRepository;
        this.orgTaskTypeMapper = orgTaskTypeMapper;
    }

    /**
     * Save a orgTaskType.
     *
     * @param orgTaskTypeDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public OrgTaskTypeDTO save(OrgTaskTypeDTO orgTaskTypeDTO) {
        log.debug("Request to save OrgTaskType : {}", orgTaskTypeDTO);
        OrgTaskType orgTaskType = orgTaskTypeMapper.toEntity(orgTaskTypeDTO);
        orgTaskType = orgTaskTypeRepository.save(orgTaskType);
        return orgTaskTypeMapper.toDto(orgTaskType);
    }
    /**
     * This method is used to check whether Product Org Id exists or not
     *
     * @param productOrgId the id of the product Organization
     * @return true if Product Organization exists
     * false if Product Organization does not exists.
     */
    @Override
    public boolean existsByProductOrgId(String productOrgId) {
        return orgTaskTypeRepository.existsByProductOrgId(productOrgId);
    }

    /**
     * Get all the orgTaskTypes.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<OrgTaskTypeDTO> findAll(Pageable pageable) {
        log.debug("Request to get all OrgTaskTypes");
        return orgTaskTypeRepository.findAll(pageable)
                .map(orgTaskTypeMapper::toDto);
    }

    /**
     * This method is used to fetch a list of Product Organizations by Product Org Id.
     *
     * @param productOrgId the id of the Product Organization.
     * @return fetches the list of job functions by Product Org Id.
     */
    @Override
    public List<OrgTaskTypeDTO> findByProductOrgId(String productOrgId) {
        if (!orgTaskTypeRepository.existsByProductOrgId(productOrgId)) {
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }
        return orgTaskTypeMapper.toDto(orgTaskTypeRepository.findByProductOrgId(productOrgId));
    }


    /**
     * Get one orgTaskType by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<OrgTaskTypeDTO> findOne(String id) {
        log.debug("Request to get OrgTaskType : {}", id);
        return orgTaskTypeRepository.findById(id)
                .map(orgTaskTypeMapper::toDto);
    }

    /**
     * Delete the orgTaskType by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete OrgTaskType : {}", id);
        Optional<OrgTaskType> orgTaskTypeRepositoryById = orgTaskTypeRepository.findById(id);
        orgTaskTypeRepositoryById.ifPresent(tasktype->tasktype.setActiveFlag(false));
    }
}
