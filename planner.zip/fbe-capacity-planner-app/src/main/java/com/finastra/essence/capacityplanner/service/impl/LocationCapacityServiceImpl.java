package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.AppUser;
import com.finastra.essence.capacityplanner.domain.LocationCapacity;
import com.finastra.essence.capacityplanner.domain.OrgLocation;
import com.finastra.essence.capacityplanner.repository.AppUserRepository;
import com.finastra.essence.capacityplanner.repository.LocationCapacityRepository;
import com.finastra.essence.capacityplanner.repository.OrgLocationRepository;
import com.finastra.essence.capacityplanner.repository.UserCapacityRepository;
import com.finastra.essence.capacityplanner.service.LocationCapacityService;
import com.finastra.essence.capacityplanner.service.dto.LocationCapacityDTO;
import com.finastra.essence.capacityplanner.service.mapper.LocationCapacityMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing {@link LocationCapacity}.
 */
@Service
@Transactional
public class LocationCapacityServiceImpl implements LocationCapacityService {

    private final Logger log = LoggerFactory.getLogger(LocationCapacityServiceImpl.class);
    /**
     * Attribute holding the reference of location capacity repository.
     */
    private final LocationCapacityRepository locationCapacityRepository;
    /**
     * Attribute holding the reference of org location repository.
     */
    private final OrgLocationRepository orgLocationRepository;
    /**
     * Attribute holding the reference of application user repository.
     */
    @Autowired
    AppUserRepository appUserRepository;
    /**
     *
     */
    @Autowired
    UserCapacityRepository userCapacityRepository;
    /**
     * Attribute holding the reference of error details.
     */
    private final ErrorDetails errorDetails = new ErrorDetails();
    /**
     * Attribute holding the reference of location capacity mapper.
     */
    private final LocationCapacityMapper locationCapacityMapper;

    /**
     * This method is used to initialize the repositories and mapper.
     *
     * @param locationCapacityRepository the location capacity repository.
     * @param orgLocationRepository      the location repository.
     * @param locationCapacityMapper     the location capacity mapper.
     */
    public LocationCapacityServiceImpl(LocationCapacityRepository locationCapacityRepository, OrgLocationRepository orgLocationRepository, LocationCapacityMapper locationCapacityMapper) {
        this.locationCapacityRepository = locationCapacityRepository;
        this.orgLocationRepository = orgLocationRepository;
        this.locationCapacityMapper = locationCapacityMapper;
    }

    /**
     * Save a locationCapacity.
     *
     * @param locationCapacityDTO the entity to save.
     * @return the persisted entity.
     */
    @Override
    public LocationCapacityDTO save(LocationCapacityDTO locationCapacityDTO) {
        log.debug("Request to save LocationCapacity : {}", locationCapacityDTO);
        validateIdDuringPostOperation(locationCapacityDTO);
        validateWhetherIdExists(locationCapacityDTO);
        try {
            LocationCapacity locationCapacity = locationCapacityMapper.toEntity(locationCapacityDTO);
            locationCapacity = locationCapacityRepository.saveAndFlush(locationCapacity);
            return locationCapacityMapper.toDto(locationCapacity);
        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails, e);
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }
    }

    /**
     * This method is used to validate id during POST operation
     *
     * @param locationCapacityDTO the entity to validate.
     */
    private void validateIdDuringPostOperation(LocationCapacityDTO locationCapacityDTO) {
        if (null != locationCapacityDTO.getCapacityId() && !locationCapacityDTO.getCapacityId().isEmpty()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.AUTOGEN_ID));
            throw new UserDefinedException(errorDetails);
        }

    }

    /**
     * update a locationCapacity.
     *
     * @param locationCapacityDTO the entity to update.
     * @return the updated entity.
     */
    @Override
    public LocationCapacityDTO update(LocationCapacityDTO locationCapacityDTO) {
        validateIdDuringPutOperation(locationCapacityDTO);
        validateWhetherIdExists(locationCapacityDTO);
        LocationCapacity locationCapacity;
        try {
            Optional<LocationCapacity> locationCapacityRepositoryById = locationCapacityRepository.findById(locationCapacityDTO.getCapacityId());
            if (locationCapacityRepositoryById.isPresent()) {
                locationCapacity = locationCapacityMapper.toEntity(locationCapacityDTO);
                if (locationCapacity.equals(locationCapacityRepositoryById.get())) {
                    throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NO_CHANGE_FOUND));
                } else {
                    locationCapacityRepository.save(locationCapacityMapper.toEntity(locationCapacityDTO));
                }
            } else {
                throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            }
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);

        }

        return locationCapacityMapper.toDto(locationCapacity);
    }

    /**
     * This method is used to validate id during PUT operation
     *
     * @param locationCapacityDTO the entity to validate.
     */
    private void validateIdDuringPutOperation(LocationCapacityDTO locationCapacityDTO) {
        if (locationCapacityDTO.getCapacityId().isEmpty() && null == locationCapacityDTO.getCapacityId()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.PROVIDE_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * This method is used to validate whether the particular id exists.
     *
     * @param locationCapacityDTO the entity to validate.
     */
    private void validateWhetherIdExists(LocationCapacityDTO locationCapacityDTO) {
        if (!orgLocationRepository.existsById(locationCapacityDTO.getLocationId())) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * This method is used to fetch the location capacity list
     *
     * @param locationId the id of the location
     * @return list of location capacity
     */
    @Override
    public List<LocationCapacityDTO> findByLocationId(String locationId) {
        if (!locationCapacityRepository.existsByLocationId(locationId)) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }
        return locationCapacityMapper.toDto(locationCapacityRepository.findByLocationId(locationId));
    }

    /**
     * Get all the locationCapacities.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<LocationCapacityDTO> findAll(Pageable pageable) {
        log.debug("Request to get all LocationCapacities");
        return locationCapacityRepository.findAll(pageable)
                .map(locationCapacityMapper::toDto);
    }


    /**
     * Get one locationCapacity by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<LocationCapacityDTO> findOne(String id) {
        log.debug("Request to get LocationCapacity : {}", id);
        return locationCapacityRepository.findById(id)
                .map(locationCapacityMapper::toDto);
    }

    /**
     * Delete the locationCapacity by id.
     *
     * @param id the id of the entity.
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete LocationCapacity : {}", id);
        Optional<LocationCapacity> locationCapacityRepositoryById = locationCapacityRepository.findById(id);
        locationCapacityRepositoryById.ifPresent(locationCapacity -> locationCapacity.setActiveFlag(false));
    }

    private LinkedHashMap<Integer, String> getMonthValue() {
        LinkedHashMap<Integer, String> monthMap = new LinkedHashMap<Integer, String>();
        monthMap.put(1, "JAN-2019");
        monthMap.put(2, "FEB-2019");
        monthMap.put(3, "MAR-2019");
        monthMap.put(4, "APR-2019");
        monthMap.put(5, "MAY-2019");
        monthMap.put(6, "JUN-2019");
        monthMap.put(7, "JUL-2019");
        monthMap.put(8, "AUG-2019");
        monthMap.put(9, "SEP-2019");
        monthMap.put(10, "OCT-2019");
        monthMap.put(11, "NOV-2019");
        monthMap.put(12, "DEC-2019");
        return monthMap;
    }

    @Override
    public void calculateLocationCapacity() {
        Integer sumHours = 0;
        List<String> locationIds = orgLocationRepository.findAll().parallelStream().map(OrgLocation::getLocationId).collect(Collectors.toList());
       log.debug("List of locationIds:"+locationIds);
        for (String locationId : locationIds) {
            List<String> usersList = appUserRepository.findByLocationId(locationId).parallelStream().map(AppUser::getUserId).collect(Collectors.toList());
            log.debug("List of users by locationId:" + usersList);
            if (usersList.size() > 0) {
                for (int i = 0; i < getMonthValue().size(); i++) {
                    for (String usersId : usersList) {
                        sumHours += userCapacityRepository.findByUserIdAndMonthCode(usersId, getMonthValue().get(i)).getAvailableHours();

                        log.debug("sumHours:" + sumHours + "For month: " + getMonthValue().get(i));
                    }
                }
            }
        }
    }
}


