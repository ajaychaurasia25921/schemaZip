/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
package com.finastra.essence.capacityplanner.common.util;

import com.finastra.essence.capacityplanner.domain.AppUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Properties;

public class EmailingService {

    private static final Logger LOG = LoggerFactory.getLogger(EmailingService.class);

    public static void sentMailTo(String filePath,AppUser recipient,String host,String port,String from,String templatePath) {
        LOG.info("Email Sending started host : " + host + " port :" + port + " sender : " + from +" templatePath : "+templatePath);
        Properties props = new Properties();
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", port);
        // Get the Session object.
        Session session = Session.getInstance(props);

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));

            // Set To: header field of the header.
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient.getUserEmail()));
            // Subject
            message.setSubject("Capacity Planner Reports");
            String htmlEmailTemplate = FileSystemUtil.readFile(Paths.get(templatePath));
            htmlEmailTemplate = htmlEmailTemplate.replace("{{headeFooterModel.CustomerName}}", recipient.getUserName());
            htmlEmailTemplate = htmlEmailTemplate.replace("{{headeFooterModel.OfferName}}", "New report is generated.<br> Please check the attachment CSV file");
            // Body message
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(htmlEmailTemplate, "text/html");
            MimeBodyPart attachBodyPart = new MimeBodyPart();
            attachBodyPart.attachFile(new File(filePath));
            Multipart multipart = new MimeMultipart();
            // Set text message part
            multipart.addBodyPart(messageBodyPart);
            // Attachment addition
            multipart.addBodyPart(attachBodyPart);
            // Send the complete message parts
            message.setContent(multipart);
            Thread.currentThread().setContextClassLoader(EmailingService.class.getClassLoader());
            MailcapCommandMap mc = (MailcapCommandMap) CommandMap.getDefaultCommandMap();
            mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
            mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
            mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
            mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
            mc.addMailcap("message/rfc822;; x-java-content- handler=com.sun.mail.handlers.message_rfc822");
            Transport.send(message);
            LOG.info("Sent mail successfully....");
        } catch (MessagingException e) {
            LOG.error("Send mail failed....", e);
        } catch (IOException e) {
            e.printStackTrace();
            LOG.error("Send mail failed....", e);
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Send mail failed....", e);
        }
        LOG.info("Email Sending ended");
    }
}