package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.SkillSet;
import com.finastra.essence.capacityplanner.repository.SkillSetRepository;
import com.finastra.essence.capacityplanner.service.SkillSetService;
import com.finastra.essence.capacityplanner.service.dto.SkillSetDTO;
import com.finastra.essence.capacityplanner.service.mapper.SkillSetMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing SkillSet.
 */
@Service
@Transactional
public class SkillSetServiceImpl implements SkillSetService {

    private final Logger log = LoggerFactory.getLogger(SkillSetServiceImpl.class);
    /**
     * Attribute holding the reference for the skill set repository.
     */
    private final SkillSetRepository skillSetRepository;
    /**
     * Attribute holding the reference for the skill set mapper.
     */
    private final SkillSetMapper skillSetMapper;
    /**
     * This is used to initialize the repository and mapper.
     * @param skillSetRepository skill set repository.
     * @param skillSetMapper skill set mapper.
     */
    public SkillSetServiceImpl(SkillSetRepository skillSetRepository, SkillSetMapper skillSetMapper) {
        this.skillSetRepository = skillSetRepository;
        this.skillSetMapper = skillSetMapper;
    }

    /**
     * Save a skillSet.
     *
     * @param skillSetDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public SkillSetDTO save(SkillSetDTO skillSetDTO) {
        log.debug("Request to save SkillSet : {}", skillSetDTO);
        SkillSet skillSet = skillSetMapper.toEntity(skillSetDTO);
        skillSet = skillSetRepository.save(skillSet);
        return skillSetMapper.toDto(skillSet);
    }
    /**
     * This method is used to check whether Product Function Id exists or not
     *
     * @param productFunctionId the id of the product Function
     * @return true if Product Function exists
     * false if Product Function does not exists.
     */
    @Override
    public boolean existsByProductFunctionId(String productFunctionId) {
        return skillSetRepository.existsByProductFunctionId(productFunctionId);
    }

    /**
     * Get all the skillSets.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<SkillSetDTO> findAll(Pageable pageable) {
        log.debug("Request to get all SkillSets");
        return skillSetRepository.findAll(pageable)
                .map(skillSetMapper::toDto);
    }

    /**
     * This method is used to fetch a list of job functions by Product Function Id.
     *
     * @param productFunctionId the id of the Product Function.
     * @return fetches the list of job functions by Product function Id.
     */
    @Override
    public List<SkillSetDTO> findByProductFunctionId(String productFunctionId) {

        if (!skillSetRepository.existsByProductFunctionId(productFunctionId)) {
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }
        List<SkillSet> byProductFunctionId = skillSetRepository.findByProductFunctionId(productFunctionId);
        return skillSetMapper.toDto(byProductFunctionId);

    }


    /**
     * Get one skillSet by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<SkillSetDTO> findOne(String id) {
        log.debug("Request to get SkillSet : {}", id);
        return skillSetRepository.findById(id)
                .map(skillSetMapper::toDto);
    }

    /**
     * Delete the skillSet by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete SkillSet : {}", id);
        Optional<SkillSet> skillSetRepositoryById = skillSetRepository.findById(id);
        skillSetRepositoryById.ifPresent(skillSet -> skillSet.setActiveFlag(false));
    }
}
