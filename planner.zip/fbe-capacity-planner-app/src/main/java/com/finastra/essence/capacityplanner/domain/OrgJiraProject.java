package com.finastra.essence.capacityplanner.domain;


/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * A OrgJiraProject.
 */
@Entity
@Table(name = "org_jira_project")
public class OrgJiraProject extends AbstractAuditingEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "jira_project_id", columnDefinition = "char(36)", unique = true)
    private String jiraProjectId;

    @NotNull
    @Size(max = 36)
    @Column(name = "product_org_id", length = 36, nullable = false)
    private String productOrgId;

    @NotNull
    @Column(name = "jira_id", precision = 10, scale = 2, nullable = false)
    private BigDecimal jiraId;

    @NotNull
    @Size(max = 255)
    @Column(name = "jira_pkey", length = 255, nullable = false)
    private String jiraPkey;

    @NotNull
    @Size(max = 255)
    @Column(name = "jira_pname", length = 255, nullable = false)
    private String jiraPname;

    @Size(max = 255)
    @Column(name = "jira_lead", length = 255)
    private String jiraLead;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getJiraProjectId() {
        return jiraProjectId;
    }

    public void setJiraProjectId(String jiraProjectId) {
        this.jiraProjectId = jiraProjectId;
    }

    public String getProductOrgId() {
        return productOrgId;
    }

    public OrgJiraProject productOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
        return this;
    }

    public void setProductOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
    }

    public BigDecimal getJiraId() {
        return jiraId;
    }

    public OrgJiraProject jiraId(BigDecimal jiraId) {
        this.jiraId = jiraId;
        return this;
    }

    public void setJiraId(BigDecimal jiraId) {
        this.jiraId = jiraId;
    }

    public String getJiraPkey() {
        return jiraPkey;
    }

    public OrgJiraProject jiraPkey(String jiraPkey) {
        this.jiraPkey = jiraPkey;
        return this;
    }

    public void setJiraPkey(String jiraPkey) {
        this.jiraPkey = jiraPkey;
    }

    public String getJiraPname() {
        return jiraPname;
    }

    public OrgJiraProject jiraPname(String jiraPname) {
        this.jiraPname = jiraPname;
        return this;
    }

    public void setJiraPname(String jiraPname) {
        this.jiraPname = jiraPname;
    }

    public String getJiraLead() {
        return jiraLead;
    }

    public OrgJiraProject jiraLead(String jiraLead) {
        this.jiraLead = jiraLead;
        return this;
    }

    public void setJiraLead(String jiraLead) {
        this.jiraLead = jiraLead;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        OrgJiraProject that = (OrgJiraProject) o;
        return Objects.equals(jiraProjectId, that.jiraProjectId) &&
                Objects.equals(productOrgId, that.productOrgId) &&
                Objects.equals(jiraId, that.jiraId) &&
                Objects.equals(jiraPkey, that.jiraPkey) &&
                Objects.equals(jiraPname, that.jiraPname) &&
                Objects.equals(jiraLead, that.jiraLead);
    }

    @Override
    public int hashCode() {
        return Objects.hash(jiraProjectId, productOrgId, jiraId, jiraPkey, jiraPname, jiraLead);
    }

    @Override
    public String toString() {
        return "OrgJiraProject{" +
                "jiraProjectId='" + jiraProjectId + '\'' +
                ", productOrgId='" + productOrgId + '\'' +
                ", jiraId=" + jiraId +
                ", jiraPkey='" + jiraPkey + '\'' +
                ", jiraPname='" + jiraPname + '\'' +
                ", jiraLead='" + jiraLead + '\'' +
                '}';
    }
}
