package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.AppRoleService;
import com.finastra.essence.capacityplanner.service.dto.AppRoleDTO;
import com.finastra.essence.capacityplanner.web.rest.errors.BadRequestAlertException;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing AppRole.
 */
@RestController
@RequestMapping("/api")
public class AppRoleResource {

    private final Logger log = LoggerFactory.getLogger(AppRoleResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppAppRole";

    private final AppRoleService appRoleService;

    public AppRoleResource(AppRoleService appRoleService) {
        this.appRoleService = appRoleService;
    }

    /**
     * POST  /app-roles : Create a new appRole.
     *
     * @param appRoleDTO the appRoleDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new appRoleDTO, or with status 400 (Bad Request) if the appRole has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/app-roles")
    public ResponseEntity<AppRoleDTO> createAppRole(@Valid @RequestBody AppRoleDTO appRoleDTO) throws URISyntaxException {
        log.debug("REST request to save AppRole : {}", appRoleDTO);
        AppRoleDTO result = appRoleService.save(appRoleDTO);
        return ResponseEntity.created(new URI("/api/app-roles/" + result.getRoleId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getRoleId().toString()))
                .body(result);
    }

    /**
     * PUT  /app-roles : Updates an existing appRole.
     *
     * @param appRoleDTO the appRoleDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated appRoleDTO,
     * or with status 400 (Bad Request) if the appRoleDTO is not valid,
     * or with status 500 (Internal Server Error) if the appRoleDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/app-roles")
    public ResponseEntity<AppRoleDTO> updateAppRole(@Valid @RequestBody AppRoleDTO appRoleDTO) throws URISyntaxException {
        log.debug("REST request to update AppRole : {}", appRoleDTO);
        AppRoleDTO result = appRoleService.update(appRoleDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, appRoleDTO.getRoleId().toString())).build();

    }

    /**
     * GET  /app-roles : get all the appRoles.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of appRoles in body
     */
    @GetMapping("/app-roles")
    public ResponseEntity<List<AppRoleDTO>> getAllAppRoles(Pageable pageable) {
        log.debug("REST request to get a page of AppRoles");
        Page<AppRoleDTO> page = appRoleService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/app-roles");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /app-roles/:id : get the "id" appRole.
     *
     * @param id the id of the appRoleDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the appRoleDTO, or with status 404 (Not Found)
     */
    @GetMapping("/app-roles/{id}")
    public ResponseEntity<AppRoleDTO> getAppRole(@PathVariable String id) {
        log.debug("REST request to get AppRole : {}", id);
        Optional<AppRoleDTO> appRoleDTO = appRoleService.findOne(id);
        return ResponseUtil.wrapOrNotFound(appRoleDTO);
    }

    /**
     * DELETE  /app-roles/:id : delete the "id" appRole.
     *
     * @param id the id of the appRoleDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/app-roles/{id}")
    public ResponseEntity<Void> deleteAppRole(@PathVariable String id) {
        log.debug("REST request to delete AppRole : {}", id);
        appRoleService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
