/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.finastra.essence.capacityplanner.common.exception;

import java.io.Serializable;

/**
 * This class holds the details about the reason of the exception.
 */
public class FieldError implements Serializable {

    /**
     * Serialization version identifier.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Application specific error code
     */
    private String code = "";

    /**
     * Detailed error message pertaining to the error code
     */
    private String message;

    /**
     * ERROR/WARN
     */
    private String severity;

    /**
     * Additional information that can help consumers to resolve the error reported
     */
    private String comment = "";

    /**
     * Attribute holding the field name in which constraints have been violated.
     */
    private String field;

    /**
     * Attribute value holding the field name in which constraints have been violated.
     */
    private String fieldValue;

    /**
     * Default Constructor
     */
    public FieldError(){
        //Default constructor
    }

    /**
     * Parametrised constructor
     * @param field the field which caused the error
     * @param fieldValue the value of the field
     * @param message the message to be displayed 
     * @param severity the error
     */
    public FieldError(String field, String fieldValue, String message, String severity){
        this.field = field;
        this.fieldValue = fieldValue;
        this.message = message;
        this.severity = severity;
    }

    /**
     * This is a getter method that returns the HTTP status code
     * @return the HTTP status code
     */
    public String getCode() {
        return code;
    }

    /**
     * This is a setter method that sets the HTTP status code
     * @param code the HTTP status code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * This is a getter method that returns the message of the error
     * @return the description of the error
     */
    public String getMessage() {
        return message;
    }

    /**
     * This is a setter method that sets the detailed error
     * @param message the description of the error
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * This is a getter method that returns the severity
     * @return the severity of error
     */
    public String getSeverity() {
        return severity;
    }

    /**
     * This is a setter method sets the severity
     * @param severity the severity of the error
     */
    public void setSeverity(String severity) {
        this.severity = severity;
    }

    /**
     * This is a getter method that returns the comment
     * @return the message of the field
     */
    public String getComment() {
        return comment;
    }

    /**
     * This is a setter method sets the comment
     * @param comment the message to be set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * This is a getter method that returns the field
     * @return the field which caused the error.
     */
    public String getField() {
        return field;
    }

    /**
     * This is a setter method that sets the field
     * @param field the field that caused the error
     */
    public void setField(String field) {
        this.field = field;
    }

    /**
     * This is a getter method that returns the field value
     * @return the value of the fields
     */
    public String getFieldValue() {
        return fieldValue;
    }

    /**
     * This is a setter method that sets the value of the field
     * @param fieldValue the value of the field
     */
    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }
}
