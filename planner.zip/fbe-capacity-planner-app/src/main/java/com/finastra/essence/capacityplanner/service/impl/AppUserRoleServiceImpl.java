package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.AppRole;
import com.finastra.essence.capacityplanner.domain.AppUser;
import com.finastra.essence.capacityplanner.domain.AppUserRole;
import com.finastra.essence.capacityplanner.repository.AppRoleRepository;
import com.finastra.essence.capacityplanner.repository.AppUserRepository;
import com.finastra.essence.capacityplanner.repository.AppUserRoleRepository;
import com.finastra.essence.capacityplanner.service.AppUserRoleService;
import com.finastra.essence.capacityplanner.service.dto.AppUserRoleDTO;
import com.finastra.essence.capacityplanner.service.mapper.AppUserRoleMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing AppUserRole.
 */
@Service
@Transactional
public class AppUserRoleServiceImpl implements AppUserRoleService {

    private final Logger log = LoggerFactory.getLogger(AppUserRoleServiceImpl.class);

    private final AppUserRoleRepository appUserRoleRepository;

    private final AppRoleRepository appRoleRepository;

    private final AppUserRepository appUserRepository;

    private final AppUserRoleMapper appUserRoleMapper;

    private final ErrorDetails errorDetails = new ErrorDetails();

    public AppUserRoleServiceImpl(AppUserRoleRepository appUserRoleRepository, AppRoleRepository appRoleRepository, AppUserRepository appUserRepository, AppUserRoleMapper appUserRoleMapper) {
        this.appUserRoleRepository = appUserRoleRepository;
        this.appRoleRepository = appRoleRepository;
        this.appUserRepository = appUserRepository;
        this.appUserRoleMapper = appUserRoleMapper;
    }

    @Override
    public List<AppUserRoleDTO> findByRoleId(String userRoleId) {
        if (!appUserRoleRepository.existsByRoleId(userRoleId)) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
        }
        return appUserRoleMapper.toDto(appUserRoleRepository.findByRoleId(userRoleId));

    }

    /**
     * Save a appUserRole.
     *
     * @param appUserRoleDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public AppUserRoleDTO save(AppUserRoleDTO appUserRoleDTO) {
        log.debug("Request to save AppUserRole : {}", appUserRoleDTO);
        validateIdDuringPostOperation(appUserRoleDTO);
        validateWhetherIdExists(appUserRoleDTO);
        try {
            AppUserRole appUserRole = appUserRoleMapper.toEntity(appUserRoleDTO);
            appUserRole = appUserRoleRepository.saveAndFlush(appUserRole);
            return appUserRoleMapper.toDto(appUserRole);
        }  catch (DataIntegrityViolationException e){
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails, e);
        }catch (Exception e){
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails,e);
        }
    }

    @Override
    public AppUserRoleDTO update(AppUserRoleDTO appUserRoleDTO) {
        validateIdDuringPutOperation(appUserRoleDTO);
        validateWhetherIdExists(appUserRoleDTO);
        try {
            Optional<AppUserRole> appUserRoleRepositoryById = appUserRoleRepository.findById(appUserRoleDTO.getUserRoleId());
            if (appUserRoleRepositoryById.isPresent()) {
                AppUserRole appUserRole = appUserRoleMapper.toEntity(appUserRoleDTO);
                if (appUserRole.equals(appUserRoleRepositoryById.get())) {
					log.debug("No Change Found");
				   //throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NO_CHANGE_FOUND));
                }
            } else {
                throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.USER_EXISTS));
            }
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);

        }
        AppUserRole appUserRole = appUserRoleRepository.save(appUserRoleMapper.toEntity(appUserRoleDTO));
        return appUserRoleMapper.toDto(appUserRole);

    }

    private void validateIdDuringPutOperation(AppUserRoleDTO appUserRoleDTO) {
        if (appUserRoleDTO.getUserRoleId().isEmpty() && null == appUserRoleDTO.getUserRoleId()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    private void validateWhetherIdExists(AppUserRoleDTO appUserRoleDTO) {
        List<String> errorMessage = new ArrayList<>();
        if (!appUserRepository.existsById(appUserRoleDTO.getUserId())) {
            errorMessage.add("UserId");
        }
        if (!appRoleRepository.existsById(appUserRoleDTO.getRoleId())) {
            errorMessage.add("roleId");
        }
        if (!errorMessage.isEmpty()) {
            errorDetails.setDetail("The dependency(s) doesn't exist :" + errorMessage);
            throw new UserDefinedException(errorDetails);
        }

    }

    /**
     * This method is used to validate user id during post operation.
     *
     * @param appUserRoleDTO the entity to validate.
     */

    private void validateIdDuringPostOperation(AppUserRoleDTO appUserRoleDTO) {
        if (null != appUserRoleDTO.getUserRoleId() && !appUserRoleDTO.getUserRoleId().isEmpty()) {
            errorDetails.setDetail("UserRoleId " + FBECapacityPlannerConstants.AUTOGEN_ID);
            throw new UserDefinedException(errorDetails);
        }

    }

    /**
     * Get all the appUserRoles.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<AppUserRoleDTO> findAll(Pageable pageable) {
        log.debug("Request to get all AppUserRoles");
        return appUserRoleRepository.findAll(pageable)
                .map(appUserRoleMapper::toDto);
    }


    /**
     * Get one appUserRole by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<AppUserRoleDTO> findOne(String id) {
        log.debug("Request to get AppUserRole : {}", id);
        return appUserRoleRepository.findById(id)
                .map(appUserRoleMapper::toDto);
    }

    /**
     * Delete the appUserRole by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete AppUserRole : {}", id);
        Optional<AppUserRole> appUserRoleRepositoryById = appUserRoleRepository.findById(id);
        appUserRoleRepositoryById.ifPresent(appUserRole -> appUserRole.setActiveFlag(false));
    }

    @Override
    public List<String> findByUserName(String username) {
        log.debug("Request to get AppUserRole by UserName : {}", username);
        AppUser appUser = appUserRepository.findByUserName(username);
        log.debug(" appUser : {} ",appUser);
        AppUserRole appUserRole = appUserRoleRepository.findByUserId(appUser.getUserId());
        log.debug(" appUserRole : {} ",appUserRole);
        Optional<AppRole> appRole = appRoleRepository.findById(appUserRole.getRoleId());
        log.debug(" appRole : {} ",appRole);
        return Collections.singletonList(appRole.get().getRoleName());
    }
}
