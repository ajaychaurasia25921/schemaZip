package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.JobFunctionService;
import com.finastra.essence.capacityplanner.service.dto.JobFunctionDTO;
import com.finastra.essence.capacityplanner.web.rest.errors.BadRequestAlertException;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing JobFunction.
 */
@RestController
@RequestMapping("/api")
public class JobFunctionResource {

    private final Logger log = LoggerFactory.getLogger(JobFunctionResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppJobFunction";

    private final JobFunctionService jobFunctionService;

    public JobFunctionResource(JobFunctionService jobFunctionService) {
        this.jobFunctionService = jobFunctionService;
    }

    /**
     * POST  /job-functions : Create a new jobFunction.
     *
     * @param jobFunctionDTO the jobFunctionDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new jobFunctionDTO, or with status 400 (Bad Request) if the jobFunction has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/job-functions")
    public ResponseEntity<JobFunctionDTO> createJobFunction(@Valid @RequestBody JobFunctionDTO jobFunctionDTO) throws URISyntaxException {
        log.debug("REST request to save JobFunction : {}", jobFunctionDTO);
        JobFunctionDTO result = jobFunctionService.save(jobFunctionDTO);
        return ResponseEntity.created(new URI("/api/job-functions/" + result.getJobFunctionId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getJobFunctionId().toString()))
                .body(result);
    }

    /**
     * PUT  /job-functions : Updates an existing jobFunction.
     *
     * @param jobFunctionDTO the jobFunctionDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated jobFunctionDTO,
     * or with status 400 (Bad Request) if the jobFunctionDTO is not valid,
     * or with status 500 (Internal Server Error) if the jobFunctionDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/job-functions")
    public ResponseEntity<JobFunctionDTO> updateJobFunction(@Valid @RequestBody JobFunctionDTO jobFunctionDTO) throws URISyntaxException {
        log.debug("REST request to update JobFunction : {}", jobFunctionDTO);
        if (jobFunctionDTO.getJobFunctionId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        JobFunctionDTO result = jobFunctionService.save(jobFunctionDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, jobFunctionDTO.getJobFunctionId().toString()))
                .body(result);
    }

    /**
     * GET  /job-functions : get all the jobFunctions.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of jobFunctions in body
     */
    @GetMapping("/job-functions/")
    public ResponseEntity<List<JobFunctionDTO>> getAllJobFunctions(@RequestParam(required = false) String productFunctionId, Pageable pageable) {
        if (null != productFunctionId && !productFunctionId.isEmpty()) {
            return ResponseEntity.ok().body(jobFunctionService.findByProductFunctionId(productFunctionId));
        }
        Page<JobFunctionDTO> page = jobFunctionService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/job-functions");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /job-functions/:id : get the "id" jobFunction.
     *
     * @param id the id of the jobFunctionDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the jobFunctionDTO, or with status 404 (Not Found)
     */
    @GetMapping("/job-functions/{id}")
    public ResponseEntity<JobFunctionDTO> getJobFunction(@PathVariable String id) {
        log.debug("REST request to get JobFunction : {}", id);
        Optional<JobFunctionDTO> jobFunctionDTO = jobFunctionService.findOne(id);
        return ResponseUtil.wrapOrNotFound(jobFunctionDTO);
    }

    /**
     * DELETE  /job-functions/:id : delete the "id" jobFunction.
     *
     * @param id the id of the jobFunctionDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/job-functions/{id}")
    public ResponseEntity<Void> deleteJobFunction(@PathVariable String id) {
        log.debug("REST request to delete JobFunction : {}", id);
        jobFunctionService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
