/**
 * Spring Security configuration.
 */
package com.finastra.essence.capacityplanner.security;
