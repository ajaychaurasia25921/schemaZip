package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.SkillSetService;
import com.finastra.essence.capacityplanner.service.dto.SkillSetDTO;
import com.finastra.essence.capacityplanner.web.rest.errors.BadRequestAlertException;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing SkillSet.
 */
@RestController
@RequestMapping("/api")
public class SkillSetResource {

    private final Logger log = LoggerFactory.getLogger(SkillSetResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppSkillSet";

    private final SkillSetService skillSetService;

    public SkillSetResource(SkillSetService skillSetService) {
        this.skillSetService = skillSetService;
    }

    /**
     * POST  /skill-sets : Create a new skillSet.
     *
     * @param skillSetDTO the skillSetDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new skillSetDTO, or with status 400 (Bad Request) if the skillSet has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/skill-sets")
    public ResponseEntity<SkillSetDTO> createSkillSet(@Valid @RequestBody SkillSetDTO skillSetDTO) throws URISyntaxException {
        log.debug("REST request to save SkillSet : {}", skillSetDTO);
        SkillSetDTO result = skillSetService.save(skillSetDTO);
        return ResponseEntity.created(new URI("/api/skill-sets/" + result.getSkillSetId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getSkillSetId().toString()))
                .body(result);
    }

    /**
     * PUT  /skill-sets : Updates an existing skillSet.
     *
     * @param skillSetDTO the skillSetDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated skillSetDTO,
     * or with status 400 (Bad Request) if the skillSetDTO is not valid,
     * or with status 500 (Internal Server Error) if the skillSetDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/skill-sets")
    public ResponseEntity<SkillSetDTO> updateSkillSet(@Valid @RequestBody SkillSetDTO skillSetDTO) throws URISyntaxException {
        log.debug("REST request to update SkillSet : {}", skillSetDTO);
        if (skillSetDTO.getSkillSetId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        SkillSetDTO result = skillSetService.save(skillSetDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, skillSetDTO.getSkillSetId().toString()))
                .body(result);
    }

    /**
     * GET  /skill-sets : get all the skillSets.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of skillSets in body
     */
    @GetMapping("/skill-sets")
    public ResponseEntity<List<SkillSetDTO>> getAllSkillSets(@RequestParam(required = false) String productFunctionId, Pageable pageable) {
        log.debug("REST request to get a page of SkillSets");
        if (null != productFunctionId && !productFunctionId.isEmpty()) {
            return ResponseEntity.ok().body(skillSetService.findByProductFunctionId(productFunctionId));
        }
        Page<SkillSetDTO> page = skillSetService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/skill-sets");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /skill-sets/:id : get the "id" skillSet.
     *
     * @param id the id of the skillSetDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the skillSetDTO, or with status 404 (Not Found)
     */
    @GetMapping("/skill-sets/{id}")
    public ResponseEntity<SkillSetDTO> getSkillSet(@PathVariable String id) {
        log.debug("REST request to get SkillSet : {}", id);
        Optional<SkillSetDTO> skillSetDTO = skillSetService.findOne(id);
        return ResponseUtil.wrapOrNotFound(skillSetDTO);
    }

    /**
     * DELETE  /skill-sets/:id : delete the "id" skillSet.
     *
     * @param id the id of the skillSetDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/skill-sets/{id}")
    public ResponseEntity<Void> deleteSkillSet(@PathVariable String id) {
        log.debug("REST request to delete SkillSet : {}", id);
        skillSetService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }
}
