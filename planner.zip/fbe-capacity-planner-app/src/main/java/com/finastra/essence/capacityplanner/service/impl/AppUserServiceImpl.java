package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.exception.UserDefinedException;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.AppUser;
import com.finastra.essence.capacityplanner.repository.*;
import com.finastra.essence.capacityplanner.service.AppUserService;
import com.finastra.essence.capacityplanner.service.dto.AppUserDTO;
import com.finastra.essence.capacityplanner.service.mapper.AppUserMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing AppUser.
 */
@Service
@Transactional
public class AppUserServiceImpl implements AppUserService {

    private final Logger log = LoggerFactory.getLogger(AppUserServiceImpl.class);
    /**
     * Attribute holding the reference of app users repository.
     */
    private final AppUserRepository appUserRepository;
    /**
     * Attribute holding the reference of product org repository.
     */
    private final ProductOrgRepository productOrgRepository;
    /**
     * Attribute holding the reference of product function repository.
     */
    private final ProductFunctionRepository productFunctionRepository;
    /**
     * Attribute holding the reference of product category repository.
     */
    private final ProductCategoryRepository productCategoryRepository;
    /**
     * Attribute holding the reference of skill level repository.
     */
    private final SkillLevelRepository skillLevelRepository;
    /**
     * Attribute holding the reference of skill set repository.
     */
    private final SkillSetRepository skillSetRepository;
    /**
     * Attribute holding the reference of job function repository.
     */
    private final JobFunctionRepository jobFunctionRepository;
    /**
     * Attribute holding the reference of application user mapper.
     */
    private final AppUserMapper appUserMapper;

    /**
     * Created ErrorDetails instance for storing error details.
     */
    private final ErrorDetails errorDetails = new ErrorDetails();

    /**
     * This is used to initialize all the repositories.
     *
     * @param appUserRepository         application user repository.
     * @param appUserMapper             acts as a mapper for application user.
     * @param productOrgRepository      product organization repository.
     * @param productFunctionRepository product function repository.
     * @param productCategoryRepository product category repository.
     * @param skillSetRepository        skill set repository.
     * @param skillLevelRepository      skill level repository.
     * @param jobFunctionRepository     job function repository.
     */
    public AppUserServiceImpl(AppUserRepository appUserRepository, AppUserMapper appUserMapper, ProductOrgRepository productOrgRepository, ProductFunctionRepository productFunctionRepository, ProductCategoryRepository productCategoryRepository, SkillSetRepository skillSetRepository, SkillLevelRepository skillLevelRepository, JobFunctionRepository jobFunctionRepository) {
        this.appUserRepository = appUserRepository;
        this.appUserMapper = appUserMapper;
        this.productOrgRepository = productOrgRepository;
        this.productCategoryRepository = productCategoryRepository;
        this.productFunctionRepository = productFunctionRepository;
        this.jobFunctionRepository = jobFunctionRepository;
        this.skillLevelRepository = skillLevelRepository;
        this.skillSetRepository = skillSetRepository;
    }

    /**
     * Save a appUser.
     *
     * @param appUserDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public AppUserDTO save(AppUserDTO appUserDTO) {
        log.debug("Request to save AppUser : {}", appUserDTO);
        validateUserId(appUserDTO);
        validateWhetherIdExists(appUserDTO);
        AppUser appUser = appUserMapper.toEntity(appUserDTO);
        try {
            appUser = appUserRepository.saveAndFlush(appUser);
            return appUserMapper.toDto(appUser);
        } catch (DataIntegrityViolationException e) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.DATA_EXISTS));
            throw new UserDefinedException(errorDetails, e);
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);
        }


    }

    /**
     * This method is used to validate the referential id provided by the user
     *
     * @param appUserDTO the application user.
     */
    private void validateWhetherIdExists(AppUserDTO appUserDTO) {
        List<String> errorMessage = new ArrayList<>();
        if (!(skillSetRepository.existsById(appUserDTO.getSkillSetId()))) {
            errorMessage.add("skill Set Id");
        }
        if (!skillLevelRepository.existsById(appUserDTO.getSkillLevelId())) {
            errorMessage.add("skill Level Id");
        }
        if (!productOrgRepository.existsById(appUserDTO.getProductOrgId())) {
            errorMessage.add("product Org Id");
        }
        if (!productFunctionRepository.existsById(appUserDTO.getProductFunctionId())) {
            errorMessage.add("product Function Id");
        }
        if (!productCategoryRepository.existsById(appUserDTO.getProductCategoryId())) {
            errorMessage.add("product Category Id");
        }
        if (!jobFunctionRepository.existsById(appUserDTO.getJobFunctionId())) {
            errorMessage.add("job Function Id");
        }
        if (!errorMessage.isEmpty()) {
            errorDetails.setDetail("The dependency(s) doesn't exist :" + errorMessage);
            throw new UserDefinedException(errorDetails);
        }

    }


    /**
     * This method is used to update the application user
     *
     * @param appUserDTO the entity to update.
     * @return updated application user.
     */
    @Override
    public AppUserDTO update(AppUserDTO appUserDTO) {
        validateUserIdToUpdateUser(appUserDTO);
        validateWhetherIdExists(appUserDTO);
        AppUser appUser;
        try {
            Optional<AppUser> appUserRepositoryById = appUserRepository.findById(appUserDTO.getUserId());
            if (appUserRepositoryById.isPresent()) {
                appUser = appUserMapper.toEntity(appUserDTO);
                if (appUser.equals(appUserRepositoryById.get())) {
                    throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.NO_CHANGE_FOUND));
                } else {
                    appUserRepository.save(appUserMapper.toEntity(appUserDTO));
                }
            } else {
                throw new DataIntegrityViolationException(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
            }
        } catch (Exception e) {
            errorDetails.setDetail(e.getMessage());
            throw new UserDefinedException(errorDetails, e);

        }
        return appUserMapper.toDto(appUser);
    }

    /**
     * This method is used to validate the id given by the user during update operation.
     *
     * @param appUserDTO the entity to validate
     */
    private void validateUserIdToUpdateUser(AppUserDTO appUserDTO) {

        if (appUserDTO.getUserId().isEmpty() && null == appUserDTO.getUserId()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.PROVIDE_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * This method is used to validate user id during post operation.
     *
     * @param appUserDTO the entity to validate.
     */
    private void validateUserId(AppUserDTO appUserDTO) {
        if (null != appUserDTO.getUserId() && !appUserDTO.getUserId().isEmpty()) {
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.AUTOGEN_ID));
            throw new UserDefinedException(errorDetails);
        }
    }

    /**
     * This method is used to fetch user details by jiraUserName.
     *
     * @param jiraUserName the jira user name of the application user.
     * @return list of application users fetched by jira User Name.
     */
    @Override
    public Optional<AppUserDTO> findByJiraUserName(String jiraUserName) {
        return appUserRepository.findByJiraUserName(jiraUserName).map(appUserMapper::toDto);
    }

	@Override
    public List<Object> getJiraUserNames() {
        return appUserRepository.getJiraUserNames();
    }
    /**
     * Get all the appUsers.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<AppUserDTO> findAll(Pageable pageable) {
        log.debug("Request to get all AppUsers");
        return appUserRepository.findAll(pageable)
                .map(appUserMapper::toDto);
    }

    /**
     * This method is used to fetch details of appUser by activeFlag
     *
     * @param activeFlag application users who are active.
     * @return fetches the list of application users by activeFlag.
     */
    @Override
    public List<AppUserDTO> findByActiveFlag(boolean activeFlag) {
        return appUserMapper.toDto(appUserRepository.findByActiveFlag(activeFlag));
    }


    /**
     * Get one appUser by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<AppUserDTO> findOne(String id) {
        log.debug("Request to get AppUser : {}", id);
        return appUserRepository.findById(id)
                .map(appUserMapper::toDto);
    }

    /**
     * Get one appUser by id.
     *
     * @param jiraid the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<AppUserDTO> findbyJiraId(BigDecimal jiraid) {
        log.debug("Request to get AppUser : {}", jiraid);
        return appUserRepository.findByJiraId(jiraid)
                .map(appUserMapper::toDto);
    }

    /**
     * Delete the appUser by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete AppUser : {}", id);
        Optional<AppUser> appUser = appUserRepository.findById(id);
        appUser.ifPresent(user -> user.setActiveFlag(false));
    }
}
