package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.LocationHolidayService;
import com.finastra.essence.capacityplanner.service.dto.LocationHolidayDTO;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.finastra.essence.capacityplanner.domain.LocationHoliday}.
 */
@RestController
@RequestMapping("/api")
public class LocationHolidayResource {

    private final Logger log = LoggerFactory.getLogger(LocationHolidayResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppLocationHoliday";


    private final LocationHolidayService locationHolidayService;

    public LocationHolidayResource(LocationHolidayService locationHolidayService) {
        this.locationHolidayService = locationHolidayService;
    }

    /**
     * {@code POST  /location-holidays} : Create a new locationHoliday.
     *
     * @param locationHolidayDTO the locationHolidayDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new locationHolidayDTO, or with status {@code 400 (Bad Request)} if the locationHoliday has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/location-holidays")
    public ResponseEntity<LocationHolidayDTO> createLocationHoliday(@Valid @RequestBody LocationHolidayDTO locationHolidayDTO) throws URISyntaxException {
        log.debug("REST request to save LocationHoliday : {}", locationHolidayDTO);
        LocationHolidayDTO result = locationHolidayService.save(locationHolidayDTO);
        return ResponseEntity.created(new URI("/api/location-holidays/" + result.getHolidayId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getHolidayId()))
                .body(result);
    }

    /**
     * {@code PUT  /location-holidays} : Updates an existing locationHoliday.
     *
     * @param locationHolidayDTO the locationHolidayDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated locationHolidayDTO,
     * or with status {@code 400 (Bad Request)} if the locationHolidayDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the locationHolidayDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/location-holidays")
    public ResponseEntity<LocationHolidayDTO> updateLocationHoliday(@Valid @RequestBody LocationHolidayDTO locationHolidayDTO) throws URISyntaxException {
        log.debug("REST request to update LocationHoliday : {}", locationHolidayDTO);
        LocationHolidayDTO result = locationHolidayService.save(locationHolidayDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, locationHolidayDTO.getHolidayId()))
                .body(result);
    }

    /**
     * {@code GET  /location-holidays} : get all the locationHolidays.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of locationHolidays in body.
     */
    @GetMapping("/location-holidays")
    public ResponseEntity<List<LocationHolidayDTO>> getAllLocationHolidays(@RequestParam(required = false) String locationId, Pageable pageable) {
        log.debug("REST request to get a page of LocationHolidays");
        if (null != locationId && !locationId.isEmpty()) {
            return ResponseEntity.ok().body(locationHolidayService.findByLocationId(locationId));
        }
        Page<LocationHolidayDTO> page = locationHolidayService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/location-holidays");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /location-holidays/:id} : get the "id" locationHoliday.
     *
     * @param id the id of the locationHolidayDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the locationHolidayDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/location-holidays/{id}")
    public ResponseEntity<LocationHolidayDTO> getLocationHoliday(@PathVariable String id) {
        log.debug("REST request to get LocationHoliday : {}", id);
        Optional<LocationHolidayDTO> locationHolidayDTO = locationHolidayService.findOne(id);
        return ResponseUtil.wrapOrNotFound(locationHolidayDTO);
    }

    /**
     * {@code DELETE  /location-holidays/:id} : delete the "id" locationHoliday.
     *
     * @param id the id of the locationHolidayDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/location-holidays/{id}")
    public ResponseEntity<Void> deleteLocationHoliday(@PathVariable String id) {
        log.debug("REST request to delete LocationHoliday : {}", id);
        locationHolidayService.delete(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
