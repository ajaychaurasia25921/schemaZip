package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.TaskComplexityService;
import com.finastra.essence.capacityplanner.service.dto.TaskComplexityDTO;
import com.finastra.essence.capacityplanner.web.rest.errors.BadRequestAlertException;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.finastra.essence.capacityplanner.domain.TaskComplexity}.
 */
@RestController
@RequestMapping("/api")
public class TaskComplexityResource {

    private final Logger log = LoggerFactory.getLogger(TaskComplexityResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppTaskComplexity";

    private final TaskComplexityService taskComplexityService;

    public TaskComplexityResource(TaskComplexityService taskComplexityService) {
        this.taskComplexityService = taskComplexityService;
    }

    /**
     * {@code POST  /task-complexities} : Create a new taskComplexity.
     *
     * @param taskComplexityDTO the taskComplexityDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new taskComplexityDTO, or with status {@code 400 (Bad Request)} if the taskComplexity has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/task-complexities")
    public ResponseEntity<TaskComplexityDTO> createTaskComplexity(@Valid @RequestBody TaskComplexityDTO taskComplexityDTO) throws URISyntaxException {
        log.debug("REST request to save TaskComplexity : {}", taskComplexityDTO);
        if (taskComplexityDTO.getComplexityId() != null) {
            throw new BadRequestAlertException("A new taskComplexity cannot already have an ID", ENTITY_NAME, "idexists");
        }
        TaskComplexityDTO result = taskComplexityService.save(taskComplexityDTO);
        return ResponseEntity.created(new URI("/api/task-complexities/" + result.getComplexityId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getComplexityId()))
                .body(result);
    }

    /**
     * {@code PUT  /task-complexities} : Updates an existing taskComplexity.
     *
     * @param taskComplexityDTO the taskComplexityDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated taskComplexityDTO,
     * or with status {@code 400 (Bad Request)} if the taskComplexityDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the taskComplexityDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/task-complexities")
    public ResponseEntity<TaskComplexityDTO> updateTaskComplexity(@Valid @RequestBody TaskComplexityDTO taskComplexityDTO) throws URISyntaxException {
        log.debug("REST request to update TaskComplexity : {}", taskComplexityDTO);
        TaskComplexityDTO result = taskComplexityService.save(taskComplexityDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, taskComplexityDTO.getComplexityId()))
                .body(result);
    }

    /**
     * {@code GET  /task-complexities} : get all the taskComplexities.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of taskComplexities in body.
     */
    @GetMapping("/task-complexities")
    public ResponseEntity<List<TaskComplexityDTO>> getAllTaskComplexities(Pageable pageable) {
        log.debug("REST request to get a page of TaskComplexities");
        Page<TaskComplexityDTO> page = taskComplexityService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/task-complexities");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /task-complexities/:id} : get the "id" taskComplexity.
     *
     * @param id the id of the taskComplexityDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the taskComplexityDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/task-complexities/{id}")
    public ResponseEntity<TaskComplexityDTO> getTaskComplexity(@PathVariable String id) {
        log.debug("REST request to get TaskComplexity : {}", id);
        Optional<TaskComplexityDTO> taskComplexityDTO = taskComplexityService.findOne(id);
        return ResponseUtil.wrapOrNotFound(taskComplexityDTO);
    }

    /**
     * {@code DELETE  /task-complexities/:id} : delete the "id" taskComplexity.
     *
     * @param id the id of the taskComplexityDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/task-complexities/{id}")
    public ResponseEntity<Void> deleteTaskComplexity(@PathVariable String id) {
        log.debug("REST request to delete TaskComplexity : {}", id);
        taskComplexityService.delete(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
