package com.finastra.essence.capacityplanner.common;

import java.util.Objects;

public class KeycloakResponse {
    private String access_token;

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        KeycloakResponse that = (KeycloakResponse) o;
        return Objects.equals(access_token, that.access_token);
    }

    @Override
    public int hashCode() {
        return Objects.hash(access_token);
    }

    @Override
    public String toString() {
        return "KeycloakResponse{" +
            "access_token='" + access_token + '\'' +
            '}';
    }
}
