package com.finastra.essence.capacityplanner;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

public class CapacityPlannerJobProcessor extends QuartzJobBean {

	@Autowired
	JIRAReportScheduler jiraReportScheduler;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		jiraReportScheduler.processJiraReport();
	}
}