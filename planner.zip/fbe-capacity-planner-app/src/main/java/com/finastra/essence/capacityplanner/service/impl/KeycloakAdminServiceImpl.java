package com.finastra.essence.capacityplanner.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.finastra.essence.capacityplanner.common.KeycloakDomainResponse;
import com.finastra.essence.capacityplanner.common.KeycloakResponse;
import com.finastra.essence.capacityplanner.service.KeycloakAdminService;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

@Service
public class KeycloakAdminServiceImpl implements KeycloakAdminService {

    private RestTemplate restTemplate = new RestTemplate();

    private HttpHeaders headers = new HttpHeaders();

    @Override
    public void update(KeycloakDomainResponse keycloakDomain) {
        headers.set("Authorization", getAccess_token());
        headers.set("Content-Type","application/json");
        HttpEntity<KeycloakDomainResponse> request = new HttpEntity<KeycloakDomainResponse>(keycloakDomain,headers);
        Object forObject = restTemplate.exchange("http://10.240.64.63:9080/auth/admin/realms/CapacityPlanner/users?username="+keycloakDomain.getUsername(),HttpMethod.GET,request, Object.class);
        ObjectMapper mapper = new ObjectMapper();
        try {
            String json = mapper.writeValueAsString(forObject);
            JsonNode jsonNode = mapper.readTree(json);
            restTemplate.put("http://10.240.64.63:9080/auth/admin/realms/CapacityPlanner/users/"+jsonNode.findPath("body").get(0).findPath("id").asText(),request, Object.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private String getAccess_token(){
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> mapForm = new LinkedMultiValueMap<>();
        mapForm.add("grant_type", "password");
        mapForm.add("client_id", "admin-cli");
        mapForm.add("username", "admin");
        mapForm.add("password", "admin");
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(mapForm, headers);
        ResponseEntity<KeycloakResponse> o = restTemplate.exchange("http://10.240.64.63:9080/auth/realms/master/protocol/openid-connect/token", HttpMethod.POST,request,KeycloakResponse.class);
     return "Bearer "+o.getBody().getAccess_token();
    }

}
