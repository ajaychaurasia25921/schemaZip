package com.finastra.essence.capacityplanner.service.dto;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.domain.AbstractAuditingEntity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A DTO for the OrgProject entity.
 */
public class OrgProjectDTO extends AbstractAuditingEntity implements Serializable {

    private String projectId;


    @NotNull
    @Size(max = 36)
    private String productOrgId;

    @NotNull
    @Size(max = 80)
    @Pattern(regexp = "^[[\\s]*[a-zA-Z][\\s]*]{3,80}$",message = "{projectName.pattern}")
    private String projectName;

    @Size(max = 240)
    @Pattern(regexp = "^[[\\s]*[a-zA-Z][\\s]*]{1,240}$",message = "{projectDesc.pattern}")
    private String projectDesc;

    @NotNull
    @Size(max = 36)
    private String projectOwnerId;

    private LocalDate estPmStartDate;

    private LocalDate estPmEndDate;

    private LocalDate estDevStartDate;

    private LocalDate estDevEndDate;

    private LocalDate estTestStartDate;

    private LocalDate estTestEndDate;

    private LocalDate estReleaseDate;

    private LocalDate actPmStartDate;

    private LocalDate actPmEndDate;

    private LocalDate actDevStartDate;

    private LocalDate actDevEndDate;

    private LocalDate actTestStartDate;

    private LocalDate actTestEndDate;

    private LocalDate actReleaseDate;


    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getProductOrgId() {
        return productOrgId;
    }

    public void setProductOrgId(String productOrgId) {
        this.productOrgId = productOrgId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectDesc() {
        return projectDesc;
    }

    public void setProjectDesc(String projectDesc) {
        this.projectDesc = projectDesc;
    }

    public String getProjectOwnerId() {
        return projectOwnerId;
    }

    public void setProjectOwnerId(String projectOwnerId) {
        this.projectOwnerId = projectOwnerId;
    }

    public LocalDate getEstPmStartDate() {
        return estPmStartDate;
    }

    public void setEstPmStartDate(LocalDate estPmStartDate) {
        this.estPmStartDate = estPmStartDate;
    }

    public LocalDate getEstPmEndDate() {
        return estPmEndDate;
    }

    public void setEstPmEndDate(LocalDate estPmEndDate) {
        this.estPmEndDate = estPmEndDate;
    }

    public LocalDate getEstDevStartDate() {
        return estDevStartDate;
    }

    public void setEstDevStartDate(LocalDate estDevStartDate) {
        this.estDevStartDate = estDevStartDate;
    }

    public LocalDate getEstDevEndDate() {
        return estDevEndDate;
    }

    public void setEstDevEndDate(LocalDate estDevEndDate) {
        this.estDevEndDate = estDevEndDate;
    }

    public LocalDate getEstTestStartDate() {
        return estTestStartDate;
    }

    public void setEstTestStartDate(LocalDate estTestStartDate) {
        this.estTestStartDate = estTestStartDate;
    }

    public LocalDate getEstTestEndDate() {
        return estTestEndDate;
    }

    public void setEstTestEndDate(LocalDate estTestEndDate) {
        this.estTestEndDate = estTestEndDate;
    }

    public LocalDate getEstReleaseDate() {
        return estReleaseDate;
    }

    public void setEstReleaseDate(LocalDate estReleaseDate) {
        this.estReleaseDate = estReleaseDate;
    }

    public LocalDate getActPmStartDate() {
        return actPmStartDate;
    }

    public void setActPmStartDate(LocalDate actPmStartDate) {
        this.actPmStartDate = actPmStartDate;
    }

    public LocalDate getActPmEndDate() {
        return actPmEndDate;
    }

    public void setActPmEndDate(LocalDate actPmEndDate) {
        this.actPmEndDate = actPmEndDate;
    }

    public LocalDate getActDevStartDate() {
        return actDevStartDate;
    }

    public void setActDevStartDate(LocalDate actDevStartDate) {
        this.actDevStartDate = actDevStartDate;
    }

    public LocalDate getActDevEndDate() {
        return actDevEndDate;
    }

    public void setActDevEndDate(LocalDate actDevEndDate) {
        this.actDevEndDate = actDevEndDate;
    }

    public LocalDate getActTestStartDate() {
        return actTestStartDate;
    }

    public void setActTestStartDate(LocalDate actTestStartDate) {
        this.actTestStartDate = actTestStartDate;
    }

    public LocalDate getActTestEndDate() {
        return actTestEndDate;
    }

    public void setActTestEndDate(LocalDate actTestEndDate) {
        this.actTestEndDate = actTestEndDate;
    }

    public LocalDate getActReleaseDate() {
        return actReleaseDate;
    }

    public void setActReleaseDate(LocalDate actReleaseDate) {
        this.actReleaseDate = actReleaseDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrgProjectDTO that = (OrgProjectDTO) o;
        return Objects.equals(projectId, that.projectId) &&
                Objects.equals(productOrgId, that.productOrgId) &&
                Objects.equals(projectName, that.projectName) &&
                Objects.equals(projectDesc, that.projectDesc) &&
                Objects.equals(projectOwnerId, that.projectOwnerId) &&
                Objects.equals(estPmStartDate, that.estPmStartDate) &&
                Objects.equals(estPmEndDate, that.estPmEndDate) &&
                Objects.equals(estDevStartDate, that.estDevStartDate) &&
                Objects.equals(estDevEndDate, that.estDevEndDate) &&
                Objects.equals(estTestStartDate, that.estTestStartDate) &&
                Objects.equals(estTestEndDate, that.estTestEndDate) &&
                Objects.equals(estReleaseDate, that.estReleaseDate) &&
                Objects.equals(actPmStartDate, that.actPmStartDate) &&
                Objects.equals(actPmEndDate, that.actPmEndDate) &&
                Objects.equals(actDevStartDate, that.actDevStartDate) &&
                Objects.equals(actDevEndDate, that.actDevEndDate) &&
                Objects.equals(actTestStartDate, that.actTestStartDate) &&
                Objects.equals(actTestEndDate, that.actTestEndDate) &&
                Objects.equals(actReleaseDate, that.actReleaseDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(projectId, productOrgId, projectName, projectDesc, projectOwnerId, estPmStartDate, estPmEndDate, estDevStartDate, estDevEndDate, estTestStartDate, estTestEndDate, estReleaseDate, actPmStartDate, actPmEndDate, actDevStartDate, actDevEndDate, actTestStartDate, actTestEndDate, actReleaseDate);
    }

    @Override
    public String toString() {
        return "OrgProjectDTO{" +
                "projectId='" + projectId + '\'' +
                ", productOrgId='" + productOrgId + '\'' +
                ", projectName='" + projectName + '\'' +
                ", projectDesc='" + projectDesc + '\'' +
                ", projectOwnerId='" + projectOwnerId + '\'' +
                ", estPmStartDate=" + estPmStartDate +
                ", estPmEndDate=" + estPmEndDate +
                ", estDevStartDate=" + estDevStartDate +
                ", estDevEndDate=" + estDevEndDate +
                ", estTestStartDate=" + estTestStartDate +
                ", estTestEndDate=" + estTestEndDate +
                ", estReleaseDate=" + estReleaseDate +
                ", actPmStartDate=" + actPmStartDate +
                ", actPmEndDate=" + actPmEndDate +
                ", actDevStartDate=" + actDevStartDate +
                ", actDevEndDate=" + actDevEndDate +
                ", actTestStartDate=" + actTestStartDate +
                ", actTestEndDate=" + actTestEndDate +
                ", actReleaseDate=" + actReleaseDate +
                '}';
    }
}
