package com.finastra.essence.capacityplanner;

import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.finastra.essence.capacityplanner.common.util.CapacityPlannerUtils;
import com.finastra.essence.capacityplanner.config.ApplicationConfig;
import com.finastra.essence.capacityplanner.service.AppPropertyService;
import com.finastra.essence.capacityplanner.service.dto.AppPropertyDTO;

@Component
public class JIRAReportScheduler {

	private static final String COLON = ":";

	private static final Logger LOG = LoggerFactory.getLogger(JIRAReportScheduler.class);

	private static final String JQL = "issuetype in (Story, defect, Improvement) AND project in ('Fusion SSO', 'FB UX Modernization') and status not in (Closed, Verified) and assignee!=null";

	private static final String BASIC = "Basic ";

	private static final String AUTHORIZATION = "Authorization";

	@Autowired
	CapacityPlannerUtils plannerUtils;

	@Autowired
	private ApplicationConfig quartzConfig;

	@Autowired
	public AppPropertyService appPropertyService;

	@Autowired
	public JIRADataProcessor service;

	public void processJiraReport() {
		service.processData(getJiraData());
	}

	private ResponseEntity<String> getJiraData() {
		ResponseEntity<String> response = null;
		try {
			JIRAJQLBuilder request = new JIRAJQLBuilder();
			request.setJql(JQL);
			request.setStartAt(quartzConfig.getStartAt());
			request.setMaxResults(quartzConfig.getMaxResults());
			request.setFields(Arrays.asList(quartzConfig.getRequstFileds().split(",")));
			HttpEntity<JIRAJQLBuilder> jqlRequestEntity = setHeadersCredentials(request, setUserBase64Credentials());
			String jiraUrl = thisMethodWillbeRemovedLater();
			AppPropertyDTO jiraUrlFromDB = appPropertyService.findByPropertyName("JIRA_API_BASE_URL");
			if (jiraUrlFromDB != null)
				jiraUrl = jiraUrlFromDB.getPropertyValueText();
			LOG.info("Jira URL is >>>>>>>>>>> " + jiraUrl);
			response = plannerUtils.getRestTemplate().exchange(jiraUrl, HttpMethod.POST, jqlRequestEntity,
					String.class);
			LOG.info("Response recevied from Jira Application" + response.getBody());
		} catch (HttpClientErrorException e) {
			if (e.getRawStatusCode() == 403) {
				LOG.error("****************Status code received: " + e.getRawStatusCode()
						+ ". You do not have access to the requested resource.************************");
			} else if (e.getRawStatusCode() == 404) {
				LOG.error("****************Status code received: " + e.getRawStatusCode()
						+ ". Resource does not exist(or) the service is not up.************************");
			} else if (e.getRawStatusCode() == 400) {
				LOG.error("****************Status code received: " + e.getRawStatusCode()
						+ ". Bad Request.************************");
			} else {
				LOG.error(
						"****************Status code received: " + e.getRawStatusCode() + ".************************");
			}
		}
		return response;
	}

	// This will be removed once DB data is Stable
	private String thisMethodWillbeRemovedLater() {
		return quartzConfig.getUrl();
	}

	private HttpEntity<JIRAJQLBuilder> setHeadersCredentials(JIRAJQLBuilder request, String userBase64Credentials) {
		HttpHeaders headers = new HttpHeaders();
		headers.add(AUTHORIZATION, BASIC + userBase64Credentials);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		return new HttpEntity<>(request, headers);
	}

	private String setUserBase64Credentials() {
		StringBuffer plainCreds = new StringBuffer();
		plainCreds.append(quartzConfig.getUsername());
		plainCreds.append(COLON);
		plainCreds.append(quartzConfig.getPassword());
		byte[] plainCredsBytes = plainCreds.toString().getBytes();
		byte[] base64CredsBytes = Base64.getEncoder().encode(plainCredsBytes);
		return new String(base64CredsBytes);

	}
}
