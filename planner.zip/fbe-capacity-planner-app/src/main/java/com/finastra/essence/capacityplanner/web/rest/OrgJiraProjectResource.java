package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.OrgJiraProjectService;
import com.finastra.essence.capacityplanner.service.dto.OrgJiraProjectDTO;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing OrgJiraProject.
 */
@RestController
@RequestMapping("/api")
public class OrgJiraProjectResource {

    private final Logger log = LoggerFactory.getLogger(OrgJiraProjectResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppOrgJiraProject";

    private final OrgJiraProjectService orgJiraProjectService;

    public OrgJiraProjectResource(OrgJiraProjectService orgJiraProjectService) {
        this.orgJiraProjectService = orgJiraProjectService;
    }

    /**
     * POST  /org-jira-projects : Create a new orgJiraProject.
     *
     * @param orgJiraProjectDTO the orgJiraProjectDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new orgJiraProjectDTO, or with status 400 (Bad Request) if the orgJiraProject has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/org-jira-projects")
    public ResponseEntity<OrgJiraProjectDTO> createOrgJiraProject(@Valid @RequestBody OrgJiraProjectDTO orgJiraProjectDTO) throws URISyntaxException {
        log.debug("REST request to save OrgJiraProject : {}", orgJiraProjectDTO);
        OrgJiraProjectDTO result = orgJiraProjectService.save(orgJiraProjectDTO);
        return ResponseEntity.created(new URI("/api/org-jira-projects/" + result.getJiraProjectId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getJiraProjectId()))
                .body(result);
    }

    /**
     * PUT  /org-jira-projects : Updates an existing orgJiraProject.
     *
     * @param orgJiraProjectDTO the orgJiraProjectDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated orgJiraProjectDTO,
     * or with status 400 (Bad Request) if the orgJiraProjectDTO is not valid,
     * or with status 500 (Internal Server Error) if the orgJiraProjectDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/org-jira-projects")
    public ResponseEntity<OrgJiraProjectDTO> updateOrgJiraProject(@Valid @RequestBody OrgJiraProjectDTO orgJiraProjectDTO) throws URISyntaxException {
        log.debug("REST request to update OrgJiraProject : {}", orgJiraProjectDTO);
        OrgJiraProjectDTO result = orgJiraProjectService.update(orgJiraProjectDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, orgJiraProjectDTO.getJiraProjectId())).build();

    }

    /**
     * GET  /org-jira-projects : get all the orgJiraProjects.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of orgJiraProjects in body
     */
    @GetMapping("/org-jira-projects")
    public ResponseEntity<List<OrgJiraProjectDTO>> getAllOrgJiraProjects(@RequestParam(required = false) String productOrgId, Pageable pageable) {
        log.debug("REST request to get a page of OrgJiraProjects");
        if (null != productOrgId && !productOrgId.isEmpty()) {
            return ResponseEntity.ok().body(orgJiraProjectService.findByProductOrgId(productOrgId));
        }
        Page<OrgJiraProjectDTO> page = orgJiraProjectService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/org-jira-projects");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /org-jira-projects/:id : get the "id" orgJiraProject.
     *
     * @param id the id of the orgJiraProjectDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the orgJiraProjectDTO, or with status 404 (Not Found)
     */
    @GetMapping("/org-jira-projects/{id}")
    public ResponseEntity<OrgJiraProjectDTO> getOrgJiraProject(@PathVariable String id) {
        log.debug("REST request to get OrgJiraProject : {}", id);
        Optional<OrgJiraProjectDTO> orgJiraProjectDTO = orgJiraProjectService.findOne(id);
        return ResponseUtil.wrapOrNotFound(orgJiraProjectDTO);
    }

    /**
     * DELETE  /org-jira-projects/:id : delete the "id" orgJiraProject.
     *
     * @param id the id of the orgJiraProjectDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/org-jira-projects/{id}")
    public ResponseEntity<Void> deleteOrgJiraProject(@PathVariable String id) {
        log.debug("REST request to delete OrgJiraProject : {}", id);
        orgJiraProjectService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
