package com.finastra.essence.capacityplanner.service.impl;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.common.exception.ErrorDetails;
import com.finastra.essence.capacityplanner.common.util.FBECapacityPlannerConstants;
import com.finastra.essence.capacityplanner.domain.OrgLocation;
import com.finastra.essence.capacityplanner.repository.OrgLocationRepository;
import com.finastra.essence.capacityplanner.service.OrgLocationService;
import com.finastra.essence.capacityplanner.service.dto.OrgLocationDTO;
import com.finastra.essence.capacityplanner.service.mapper.OrgLocationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service Implementation for managing OrgLocation.
 */
@Service
@Transactional
public class OrgLocationServiceImpl implements OrgLocationService {

    private final Logger log = LoggerFactory.getLogger(OrgLocationServiceImpl.class);
    /**
     * Attribute holding the reference for the org location repository.
     */
    private final OrgLocationRepository orgLocationRepository;
    /**
     * Attribute holding the reference for the org location mapper.
     */
    private final OrgLocationMapper orgLocationMapper;

    /**
     * This is used to initialize the repository and mapper.
     * @param orgLocationRepository org location repository.
     * @param orgLocationMapper org location mapper.
     */
    public OrgLocationServiceImpl(OrgLocationRepository orgLocationRepository, OrgLocationMapper orgLocationMapper) {
        this.orgLocationRepository = orgLocationRepository;
        this.orgLocationMapper = orgLocationMapper;
    }

    /**
     * Save a orgLocation.
     *
     * @param orgLocationDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public OrgLocationDTO save(OrgLocationDTO orgLocationDTO) {
        log.debug("Request to save OrgLocation : {}", orgLocationDTO);
        OrgLocation orgLocation = orgLocationMapper.toEntity(orgLocationDTO);
        orgLocation = orgLocationRepository.save(orgLocation);
        return orgLocationMapper.toDto(orgLocation);
    }
    /**
     * This method is used to check whether Product Org Id exists or not
     *
     * @param productOrgId the id of the product Organization
     * @return true if Product Organization exists
     * false if Product Organization does not exists.
     */
    @Override
    public boolean existsByProductOrgId(String productOrgId) {
        return orgLocationRepository.existsByProductOrgId(productOrgId);
    }

    /**
     * Get all the orgLocations.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    @Transactional(readOnly = true)
    public Page<OrgLocationDTO> findAll(Pageable pageable) {
        log.debug("Request to get all OrgLocations");
        return orgLocationRepository.findAll(pageable)
                .map(orgLocationMapper::toDto);
    }
    /**
     * This method is used to fetch a list of Product Organizations by Product Org Id.
     *
     * @param productOrgId the id of the Product Organization.
     * @return fetches the list of job functions by Product Org Id.
     */
    @Override
    public List<OrgLocationDTO> findByProductOrgId(String productOrgId) {
        if (!orgLocationRepository.existsByProductOrgId(productOrgId)) {
            ErrorDetails errorDetails = new ErrorDetails();
            errorDetails.setDetail(String.valueOf(FBECapacityPlannerConstants.INVALID_ID));
        }
        return orgLocationMapper.toDto(orgLocationRepository.findByProductOrgId(productOrgId));

    }


    /**
     * Get one orgLocation by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<OrgLocationDTO> findOne(String id) {
        log.debug("Request to get OrgLocation : {}", id);
        return orgLocationRepository.findById(id)
                .map(orgLocationMapper::toDto);
    }

    /**
     * Delete the orgLocation by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete OrgLocation : {}", id);
        Optional<OrgLocation> orgLocationRepositoryById = orgLocationRepository.findById(id);
        orgLocationRepositoryById.ifPresent(location -> location.setActiveFlag(false));

    }
}
