package com.finastra.essence.capacityplanner.web.rest;
/*
 * Copyright (c) 2019, Finastra Software Solutions Ltd ("Finastra")
 * and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 *  - Neither the name of Finastra or the names of its contributors
 *    may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

import com.finastra.essence.capacityplanner.service.JobComplexityScoreService;
import com.finastra.essence.capacityplanner.service.dto.JobComplexityScoreDTO;
import com.finastra.essence.capacityplanner.web.rest.util.HeaderUtil;
import com.finastra.essence.capacityplanner.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.finastra.essence.capacityplanner.domain.JobComplexityScore}.
 */
@RestController
@RequestMapping("/api")
public class JobComplexityScoreResource {

    private final Logger log = LoggerFactory.getLogger(JobComplexityScoreResource.class);

    private static final String ENTITY_NAME = "fbeCapacityPlannerAppJobComplexityScore";


    private final JobComplexityScoreService jobComplexityScoreService;

    public JobComplexityScoreResource(JobComplexityScoreService jobComplexityScoreService) {
        this.jobComplexityScoreService = jobComplexityScoreService;
    }

    /**
     * {@code POST  /job-complexity-scores} : Create a new jobComplexityScore.
     *
     * @param jobComplexityScoreDTO the jobComplexityScoreDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new jobComplexityScoreDTO, or with status {@code 400 (Bad Request)} if the jobComplexityScore has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/job-complexity-scores")
    public ResponseEntity<JobComplexityScoreDTO> createJobComplexityScore(@Valid @RequestBody JobComplexityScoreDTO jobComplexityScoreDTO) throws URISyntaxException {
        log.debug("REST request to save JobComplexityScore : {}", jobComplexityScoreDTO);
        JobComplexityScoreDTO result = jobComplexityScoreService.save(jobComplexityScoreDTO);
        return ResponseEntity.created(new URI("/api/job-complexity-scores/" + result.getComplexityScoreId()))
                .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getComplexityScoreId()))
                .body(result);
    }

    /**
     * {@code PUT  /job-complexity-scores} : Updates an existing jobComplexityScore.
     *
     * @param jobComplexityScoreDTO the jobComplexityScoreDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated jobComplexityScoreDTO,
     * or with status {@code 400 (Bad Request)} if the jobComplexityScoreDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the jobComplexityScoreDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/job-complexity-scores")
    public ResponseEntity<JobComplexityScoreDTO> updateJobComplexityScore(@Valid @RequestBody JobComplexityScoreDTO jobComplexityScoreDTO) throws URISyntaxException {
        log.debug("REST request to update JobComplexityScore : {}", jobComplexityScoreDTO);
        JobComplexityScoreDTO result = jobComplexityScoreService.save(jobComplexityScoreDTO);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, jobComplexityScoreDTO.getComplexityScoreId()))
                .body(result);
    }

    /**
     * {@code GET  /job-complexity-scores} : get all the jobComplexityScores.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of jobComplexityScores in body.
     */
    @GetMapping("/job-complexity-scores")
    public ResponseEntity<List<JobComplexityScoreDTO>> getAllJobComplexityScores(@RequestParam(required = false) String jobFunctionId, Pageable pageable) {
        log.debug("REST request to get a page of JobComplexityScores");
        if (null != jobFunctionId && !jobFunctionId.isEmpty()) {
            return ResponseEntity.ok().body(jobComplexityScoreService.findByJobFunctionId(jobFunctionId));
        }
        Page<JobComplexityScoreDTO> page = jobComplexityScoreService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/job-complexity-scores");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /job-complexity-scores/:id} : get the "id" jobComplexityScore.
     *
     * @param id the id of the jobComplexityScoreDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the jobComplexityScoreDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/job-complexity-scores/{id}")
    public ResponseEntity<JobComplexityScoreDTO> getJobComplexityScore(@PathVariable String id) {
        log.debug("REST request to get JobComplexityScore : {}", id);
        Optional<JobComplexityScoreDTO> jobComplexityScoreDTO = jobComplexityScoreService.findOne(id);
        return ResponseUtil.wrapOrNotFound(jobComplexityScoreDTO);
    }

    /**
     * {@code DELETE  /job-complexity-scores/:id} : delete the "id" jobComplexityScore.
     *
     * @param id the id of the jobComplexityScoreDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/job-complexity-scores/{id}")
    public ResponseEntity<Void> deleteJobComplexityScore(@PathVariable String id) {
        log.debug("REST request to delete JobComplexityScore : {}", id);
        jobComplexityScoreService.delete(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
