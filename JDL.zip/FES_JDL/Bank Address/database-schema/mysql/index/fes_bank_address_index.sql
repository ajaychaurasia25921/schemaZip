create index FES_BANK_ADDRESS_IX1 on FES_BANK_ADDRESS (active_flag);
