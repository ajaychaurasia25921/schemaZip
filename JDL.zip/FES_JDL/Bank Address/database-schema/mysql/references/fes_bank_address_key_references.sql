 alter table FES_BANK_ADDRESS
        add constraint FES_BANK_ADDRESS_FK1
        foreign key (bank_id) 
        references FES_BANK(bank_id);
alter table FES_BANK_ADDRESS
        add constraint FES_BANK_ADDRESS_FK2
        foreign key (address_country_id) 
        references FES_BANK (address_country_id);