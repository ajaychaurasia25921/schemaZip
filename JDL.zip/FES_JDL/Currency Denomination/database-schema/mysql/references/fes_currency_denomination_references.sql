 alter table FES_CURR_DENOMINATION
        add constraint 	FES_CURR_DENOMINATION_FK1 
        foreign key (bank_id) 
        references FES_BANK (bank_id);
alter table FES_CURR_DENOMINATION
        add constraint FES_CURR_DENOMINATION_FK2 
        foreign key (currency_id) 
        references FES_CURRENCY (currency_id);