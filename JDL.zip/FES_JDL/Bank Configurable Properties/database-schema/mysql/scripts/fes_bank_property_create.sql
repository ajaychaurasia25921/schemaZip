create table fes_bank_property(
property_id varchar(36) not null,
bank_id	varchar(36) not null,
property_code varchar(80) not null,
property_value_type varchar(1) not null,
mandatory_flag varchar(1) not null,
read_only_flag varchar(1) not null,
active_flag varchar(1) not null,
active_from date not null,
active_till date not null,
system_flag varchar(1) not null,
version_number decimal not null,
created_by varchar(36) not null,
created_on datetime not null,
last_updated_by varchar(36) not null,
last_updated_on datetime not null,
primary_key(property_id)
)	
alter table fes_bank_property 
        add constraint FES_BANK_PROPERTY_UK1 unique (bank_id);