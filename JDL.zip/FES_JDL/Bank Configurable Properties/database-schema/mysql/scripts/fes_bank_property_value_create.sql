create table fes_bank_property_value(
property_value_id varchar(36) not null,
property_id varchar(36) not null,
value_string varchar(240) not null,
value_flag varchar(1) not null,
value_date date;
value_number int(10),
value_decimal decimal(18,4),
version_number decimal not null,
created_by varchar(36) not null,
created_on datetime not null,
last_updated_by varchar(36) not null,
last_updated_on datetime not null
)	
