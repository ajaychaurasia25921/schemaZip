 create index FES_CURRENCY_HIST_IX1 on FES_CURRENCY_HIST (active_flag);
