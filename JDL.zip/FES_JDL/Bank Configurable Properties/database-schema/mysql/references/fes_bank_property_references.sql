 alter table FES_BANK_PROPERTY
        add constraint FES_BANK_PROPERTY_FK1 
        foreign key (bank_id) 
        references FES_BANK (bank_id);
alter table FES_BANK_PROPERTY_TL
        add constraint FES_BANK_PROPERTY_TL_FK1 
        foreign key (parent_id) 
        references FES_BANK_PROPERTY (property_id);
alter table FES_BANK_PROPERTY_TL
        add constraint FES_BANK_PROPERTY_TL_FK2 
        foreign key (language_id) 
        references FES_LANGUAGE (language_id);
alter table FES_BANK_PROPERTY_HIST
        add constraint FES_BANK_PROPERTY_HIST_FK1 
        foreign key (property_id) 
        references FES_BANK_PROPERTY (property_id);
		
alter table FES_BANK_PROPERTY_HIST
        add constraint FES_BANK_PROPERTY_HIST_FK2 
        foreign key (bank_id) 
        references FES_BANK (bank_id);
		
alter table FES_BANK_PROPERTY_VALUE
        add constraint FES_BANK_PROPERTY_VALUE_FK1 
        foreign key (property_id) 
        references FES_BANK_PROPERTY (property_id);
		
 alter table FES_BANK_PROPERTY_VALUE_HIST
        add constraint FES_BANK_PROPERTY_VALUE_HIST_FK1 
        foreign key (property_value_id) 
        references FES_BANK_PROPERTY_VALUE (property_value_id);		
		
 alter table FES_BANK_PROPERTY_VALUE_HIST
        add constraint FES_BANK_PROPERTY_VALUE_HIST_FK2 
        foreign key (property_id) 
        references FES_BANK_PROPERTY(property_id);		