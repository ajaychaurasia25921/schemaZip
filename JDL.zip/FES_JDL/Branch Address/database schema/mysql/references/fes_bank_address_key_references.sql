 alter table FES_BRANCH_ADDRESS
        add constraint FES_BRANCH_ADDRESS_FK1
        foreign key (branch_id) 
        references FES_BRANCH(branch_id);
alter table FES_BRANCH_ADDRESS
        add constraint FES_BRANCH_ADDRESS_FK2
        foreign key (address_country_id) 
        references FES_COUNTRY (address_country_id);