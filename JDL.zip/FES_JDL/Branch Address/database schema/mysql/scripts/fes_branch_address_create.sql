create table fes_branch_address(
branch_address_id varchar(36) not null,
branch_id varchar(36) not null,
address_type_id varchar(36) not null,
default_flag varchar(1) not null,
address_line_1 varchar(80) not null;
address_line_2 varchar(80);
address_line_3 varchar(80);
address_city varchar(60) not null;
address_locality varchar(120);
address_zipcode varchar(30) not null;
address_state varchar(80) not null;
address_country_id varchar(36) not null,
gps_latitude decimal(12,6),
gps_longitude decimal(12,6),
active_flag varchar(1) not null,
active_from date not null,
active_till date not null,
system_flag varchar(1) not null,
version_number decimal(18,0) not null,
created_by varchar(120) not null,
created_on datetime not null,
last_updated_by varchar(120) not null,
last_updated_on datetime not null,
primary_key(branch_address_id)
)	
alter table FES_BRANCH_ADDRESS 
        add constraint FES_BRANCH_ADDRESS_UK1 unique (branch_id);