create index FES_BRANCH_ADDRESS_IX1 on FES_BRANCH_ADDRESS (active_flag);
