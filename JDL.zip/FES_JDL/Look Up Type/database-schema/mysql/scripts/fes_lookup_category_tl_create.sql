create table fes_lookup_category_tl(
translation_id varchar(36) not null,
parent_id varchar(36) not null,
language_id varchar(36) not null,
entity_name	varchar(100) not null,
entity_desc varchar(240) not null,
version_number decimal not null,
created_by varchar(36) not null,
created_on datetime not null,
last_updated_by varchar(36) not null,
last_updated_on datetime not null,
primary_key(translation_id)
)	
alter table fes_lookup_category_tl 
        add constraint FES_LOOKUP_CATEGORY_TL_UK1   unique (parent_id, language_id);