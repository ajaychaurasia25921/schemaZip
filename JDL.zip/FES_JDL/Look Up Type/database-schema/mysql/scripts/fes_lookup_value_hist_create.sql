create table fes_lookup_value_hist(
history_id varchar(36) not null,
lookup_value_id varchar(36) not null,
looup_type_id varchar(36) not null,
lookup_value_code varchar(120) not null,
display_sequence int not null,
active_flag varchar(1) not null,
active_from date not null,
active_till date not null,
system_flag varchar(1) not null,
version_number decimal not null,
created_by varchar(36) not null,
created_on datetime not null,
last_updated_by varchar(36) not null,
last_updated_on datetime not null
)	
