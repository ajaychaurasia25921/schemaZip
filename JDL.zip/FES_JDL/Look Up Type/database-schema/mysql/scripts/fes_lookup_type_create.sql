create table fes_lookup_type(
lookup_type_id varchar(36) not null,
bank_id	varchar(36) not null,
lookup_type_code varchar(120) not null,
read_only_flag varchar(1) not null,
active_flag varchar(1) not null,
active_from date not null,
active_till date not null,
system_flag varchar(1) not null,
version_number decimal not null,
created_by varchar(36) not null,
created_on datetime not null,
last_updated_by varchar(36) not null,
last_updated_on datetime not null,
primary_key(lookup_type_id)
)	
alter table fes_lookup_type
        add constraint FES_LOOKUP_TYPE_UK1  unique (lookup_type_code);