 create index FES_LOOKUP_CATEGORY_IX1 on FES_LOOKUP_VALUE_CATEGORY (active_flag);
 