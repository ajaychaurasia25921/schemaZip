create table fes_application(
appliaction_id varchar(36) not null,
application_code varchar(3) not null,     
application_name varchar(80) not null,
application_short_name varchar(30) not null,
major_version int(5) not null,
minor_version int(5) not null,
patch_number int(5) not null,
build_version int(5),
installed_on datetime not null ,
update_on datetime not null,
icon_image_file varchar(240)
active_flag varchar(1) not null,
active_from date not null,
active_till date not null,
system_flag varchar(1) not null,
version_number decimal(18,0) not null,
created_by varchar(120) not null,
created_on datetime not null,
last_updated_by varchar(120) not null,
last_updated_on datetime not null,
primary key(appliaction_id)
)	
alter table fes_application 
        add constraint FES_APPLICATION_UK1 unique (appliaction_code);

    alter table fes_application
        add constraint FES_APPLICATION_UK2  unique (appliaction_name);

	