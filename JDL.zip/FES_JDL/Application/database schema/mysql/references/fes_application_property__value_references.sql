 alter table FES_APP_PROPERTY_VALUE
        add constraint FES_APP_PROPERTY_VALUE_FK1  
        foreign key (property_id) 
        references FES_APP_PROPERTY (property_id);