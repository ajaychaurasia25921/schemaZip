 create index FES_COUNTRY_TL_IX1 on FES_COUNTRY_TL (parent_id);
  create index FES_COUNTRY_TL_IX2 on FES_COUNTRY_TL (language_id);