 create index FES_COUNTRY_HIST_IX1 on FES_COUNTRY_HIST (active_flag);
