 alter table FES_BANK
        add constraint FES_BANK_FK1
        foreign key (registered_country_id) 
        references FES_COUNTRY (country_id);
alter table FES_BANK_HIST
        add constraint FES_BANK_HIST_FK1 
        foreign key (bank_id) 
        references FES_BANK (bank_id);