create table fes_bank(
bank_id varchar(36) not null,
bank_code	varchar(20) not null,
bank_name	varchar(120) not null,
bank_short_name	varchar(20) not null,
registered_date date not null,
registered_country_id varchar(36) not null,
icon_image_file varchar(240),
active_flag varchar(1) not null,
active_from date not null,
active_till date not null,
system_flag varchar(1) not null,
version_number decimal not null,
created_by varchar(36) not null,
created_on datetime not null,
last_updated_by varchar(36) not null,
last_updated_on datetime not null,
primary key(bank_id)
)	
alter table fes_bank 
        add constraint FES_BANK_UK1 unique (bank_code);

    alter table fes_bank
        add constraint FES_BANK_UK2  unique (bank_name);

	   alter table fes_bank
        add constraint FES_BANK_UK3  unique (bank_short_name);
	