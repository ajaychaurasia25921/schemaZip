
    create table FES_CURRENCY (
	
        currency_id varchar(36) not null,
		currency_code varchar(4) not null,
        currency_iso_code varchar(4) not null,
		currency_numeric_code decimal(3,0) not null,
		currency_alternative_code varchar(10),
		icon_image_file varchar(240),
        active_flag varchar(1) not null,
        active_from date not null,
        active_till date not null,
		system_flag varchar(1),
		version_number number(18,0),
        application_identifier integer,
        created_by varchar(120) not null,
        created_on datetime not null,
        last_updated_by varchar(120),
        last_updated_on datetime,
		primary key (currency_id)
    );
	alter table FES_CURRENCY 
        add constraint FES_CURRENCY_UK1 unique (currency_code);

    alter table FES_CURRENCY
        add constraint FES_CURRENCY_UK2  unique (currency_iso_code);
	