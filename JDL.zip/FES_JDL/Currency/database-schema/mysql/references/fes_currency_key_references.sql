 alter table FES_CURRENCY_TL
        add constraint FES_CURRENCY_TL_FK1 
        foreign key (parent_id) 
        references FES_CURRENCY (currency_id);
alter table FES_CURRENCY_TL
        add constraint FES_CURRENCY_TL_FK2 
        foreign key (language_id) 
        references FES_LANGUAGE (language_id);